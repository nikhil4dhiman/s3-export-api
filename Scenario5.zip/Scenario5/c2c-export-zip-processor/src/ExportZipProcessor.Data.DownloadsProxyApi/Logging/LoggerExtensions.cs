using System;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Logging;

internal static partial class LoggerExtensions
{
    [LoggerMessage(
        Level = LogLevel.Error,
        Message = "An error occurred during downloads proxy api operation")]
    public static partial void LogDownloadsProxyApiOperationError(
        this ILogger<DownloadsProxyApiClient> logger,
        Exception exception);
}
