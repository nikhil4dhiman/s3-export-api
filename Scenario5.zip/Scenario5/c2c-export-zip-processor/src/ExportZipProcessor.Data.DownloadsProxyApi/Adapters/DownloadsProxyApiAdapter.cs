using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ApiClients.Api;
using ExportZipProcessor.Data.DownloadsProxyApi.Constants;
using ExportZipProcessor.Data.DownloadsProxyApi.Models;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Adapters;

internal class DownloadsProxyApiAdapter : IDownloadsProxyApiAdapter
{
    private readonly IApiClient _apiClient;

    public DownloadsProxyApiAdapter([FromKeyedServices(nameof(DownloadsProxyApiClient))] IApiClient apiClient)
    {
        _apiClient = apiClient;
    }

    public async Task<CreateFileAssociationResponse> PostCreateFileAssociationRequestAsync(
        CreateFileAssociationRequest request,
        CancellationToken cancellationToken)
    {
        return await _apiClient.PostAsync<CreateFileAssociationRequest, CreateFileAssociationResponse>(
            DownloadsProxyApiClientDefaults.CreateFileAssociationEndpoint,
            request,
            cancellationToken);
    }
}
