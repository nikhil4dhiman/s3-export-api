using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Data.DownloadsProxyApi.Models;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Adapters;

internal interface IDownloadsProxyApiAdapter
{
    Task<CreateFileAssociationResponse> PostCreateFileAssociationRequestAsync(
        CreateFileAssociationRequest request,
        CancellationToken cancellationToken);
}
