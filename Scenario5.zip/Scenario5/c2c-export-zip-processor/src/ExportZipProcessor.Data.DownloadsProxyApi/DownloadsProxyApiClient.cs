using System;
using System.Diagnostics;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Data.DownloadsProxyApi.Adapters;
using ExportZipProcessor.Data.DownloadsProxyApi.Exceptions;
using ExportZipProcessor.Data.DownloadsProxyApi.Logging;
using ExportZipProcessor.Data.DownloadsProxyApi.Models;
using ExportZipProcessor.Data.DownloadsProxyApi.Models.FieldValues;
using ExportZipProcessor.Data.DownloadsProxyApi.Options;
using ExportZipProcessor.Domain.ApiClients;
using ExportZipProcessor.Domain.Helpers;
using ExportZipProcessor.Domain.Metrics;
using ExportZipProcessor.Domain.Models;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.DownloadsProxyApi;

internal class DownloadsProxyApiClient : IDownloadsProxyApiClient
{
    private readonly IDownloadsProxyApiAdapter _apiClient;
    private readonly TimeProvider _timeProvider;
    private readonly IMetricsService _metricsService;
    private readonly FileDownloadOptions _fileDownloadOptions;
    private readonly ILogger<DownloadsProxyApiClient> _logger;

    public DownloadsProxyApiClient(
        IDownloadsProxyApiAdapter apiClient,
        TimeProvider timeProvider,
        IMetricsService metricsService,
        FileDownloadOptions fileDownloadOptions,
        ILogger<DownloadsProxyApiClient> logger)
    {
        _apiClient = apiClient;
        _timeProvider = timeProvider;
        _metricsService = metricsService;
        _fileDownloadOptions = fileDownloadOptions;
        _logger = logger;
    }

    public async Task<string> CreateFileAssociationAsync(
        Uri fileUrl,
        string zipFileName,
        ZipGenerationInfo zipGenerationInfo,
        CancellationToken cancellationToken)
    {
        var createFileAssociationRequest = BuildCreateFileAssociationRequest(zipGenerationInfo, zipFileName, fileUrl);

        try
        {
            var response = await _apiClient.PostCreateFileAssociationRequestAsync(
                createFileAssociationRequest,
                cancellationToken);

            Activity.Current?.SetTag("downloads-proxy-api.file.id", response.FileId);

            return response.FileId;
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogDownloadsProxyApiOperationError(e);

            _metricsService.IncreaseNumberOfDownloadsProxyApiErrors("create_file_association");

            throw new DownloadsProxyException($"Failed to create file association in Downloads Proxy: {e.Message}");
        }
    }

    private CreateFileAssociationRequest BuildCreateFileAssociationRequest(
        ZipGenerationInfo zipGenerationInfo,
        string zipFileName,
        Uri fileUrl)
    {
        var expiresAt = _timeProvider.GetUtcNow().AddDays(_fileDownloadOptions.ExpirationInDays).UtcDateTime;

        return new CreateFileAssociationRequest
        {
            File = new CreateFileAssociationRequestFileInfo
            {
                Name = ZipFileHelper.BuildDownloadFileName(zipGenerationInfo.ExportId, zipFileName),
                ContentType = MediaTypeNames.Application.Zip,
                Url = fileUrl.AbsoluteUri,
                ExpiresAt = expiresAt
            },
            OwnerId = zipGenerationInfo.PartnerId,
            OwnerType = OwnerType.Partner,
            MaxDownloadsCount = _fileDownloadOptions.MaxDownloadsCount
        };
    }
}
