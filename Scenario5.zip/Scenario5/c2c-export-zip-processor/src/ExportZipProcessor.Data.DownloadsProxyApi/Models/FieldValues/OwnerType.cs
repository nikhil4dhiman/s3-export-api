namespace ExportZipProcessor.Data.DownloadsProxyApi.Models.FieldValues;

public static class OwnerType
{
    public const string Partner = "Partner";
}
