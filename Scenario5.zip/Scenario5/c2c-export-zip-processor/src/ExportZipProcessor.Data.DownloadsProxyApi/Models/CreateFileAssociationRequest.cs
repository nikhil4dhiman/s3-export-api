namespace ExportZipProcessor.Data.DownloadsProxyApi.Models;

internal class CreateFileAssociationRequest
{
    public required CreateFileAssociationRequestFileInfo File { get; init; }

    public required string OwnerId { get; init; }

    public required string OwnerType { get; init; }

    public required int MaxDownloadsCount { get; init; }
}
