namespace ExportZipProcessor.Data.DownloadsProxyApi.Models;

public class CreateFileAssociationResponse
{
    public required string FileId { get; init; }
}
