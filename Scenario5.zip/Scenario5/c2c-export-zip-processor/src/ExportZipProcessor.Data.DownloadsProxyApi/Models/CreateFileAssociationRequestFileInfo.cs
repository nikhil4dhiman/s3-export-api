using System;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Models;

public class CreateFileAssociationRequestFileInfo
{
    public required string Name { get; init; }

    public required string ContentType { get; init; }

    public required string Url { get; init; }

    public required DateTime ExpiresAt { get; init; }
}
