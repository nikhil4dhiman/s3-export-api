namespace ExportZipProcessor.Data.DownloadsProxyApi.Constants;

internal static class DownloadsProxyApiClientDefaults
{
    public const string CreateFileAssociationEndpoint = "file-associations";

    internal static class ApiVersion
    {
        public const string V2 = "2.0";
    }
}
