using System;
using Cove.Platform.Extensions.ApiClients;
using Cove.Platform.Extensions.Configuration;
using ExportZipProcessor.Data.DownloadsProxyApi.Adapters;
using ExportZipProcessor.Data.DownloadsProxyApi.Enrichers;
using ExportZipProcessor.Data.DownloadsProxyApi.Options;
using ExportZipProcessor.Domain.ApiClients;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.Data.DownloadsProxyApi;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddDownloadsProxyApiServices(this IServiceCollection services)
    {
        services
            .AddOptionsAndValidate<DownloadsProxyApiClientOptions>()
            .AddOptionsAndValidate<FileDownloadOptions>()
            .AddApiClientForDownloadsProxy()
            .AddScoped<IDownloadsProxyApiAdapter, DownloadsProxyApiAdapter>()
            .AddScoped<IDownloadsProxyApiClient, DownloadsProxyApiClient>();

        return services;
    }

    private static IServiceCollection AddApiClientForDownloadsProxy(this IServiceCollection services)
    {
        services
            .AddApiClientFor<DownloadsProxyApiClient>()
            .ConfigureOptions((options, sp) =>
            {
                var downloadsProxyApiOptions = sp.GetRequiredService<DownloadsProxyApiClientOptions>();

                options.BaseUrl = downloadsProxyApiOptions.BaseUrl;
                options.TotalRequestTimeout = TimeSpan.FromSeconds(downloadsProxyApiOptions.TimeoutInSeconds);
            })
            .WithInterceptor<DownloadsProxyApiRequestEnricher>();

        return services;
    }
}
