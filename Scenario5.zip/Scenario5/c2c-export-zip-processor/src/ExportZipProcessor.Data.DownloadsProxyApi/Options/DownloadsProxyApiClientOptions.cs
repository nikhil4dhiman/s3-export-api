using System;
using System.ComponentModel.DataAnnotations;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Options;

public class DownloadsProxyApiClientOptions
{
    [Required]
    public required Uri BaseUrl { get; init; }

    [Required]
    [Range(1, 600)]
    public required int TimeoutInSeconds { get; init; }
}
