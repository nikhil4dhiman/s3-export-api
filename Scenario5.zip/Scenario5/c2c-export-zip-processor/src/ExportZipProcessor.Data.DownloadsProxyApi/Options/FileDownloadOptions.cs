using System.ComponentModel.DataAnnotations;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Options;

internal class FileDownloadOptions
{
    [Range(3, 90)]
    public required int ExpirationInDays { get; init; }

    [Range(1, 10)]
    public required int MaxDownloadsCount { get; init; }
}
