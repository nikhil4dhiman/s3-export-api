using ExportZipProcessor.Domain.Exceptions;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Exceptions;

internal class DownloadsProxyException : ProcessingException
{
    public DownloadsProxyException(string errorMessage)
        : base(errorMessage)
    {
    }
}
