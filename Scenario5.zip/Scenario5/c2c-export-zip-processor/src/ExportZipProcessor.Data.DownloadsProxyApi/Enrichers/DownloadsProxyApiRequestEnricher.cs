using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ApiClients.Interceptors;
using Cove.Platform.Extensions.Communication.Constants.Http;
using ExportZipProcessor.Data.DownloadsProxyApi.Constants;

namespace ExportZipProcessor.Data.DownloadsProxyApi.Enrichers;

internal class DownloadsProxyApiRequestEnricher : IApiRequestInterceptor
{
    public Task OnRequestSendingAsync(RequestSendingContext context, CancellationToken cancellationToken)
    {
        context.RequestMessage.Headers.Add(KnownHttpHeaders.ApiVersion, DownloadsProxyApiClientDefaults.ApiVersion.V2);

        return Task.CompletedTask;
    }
}
