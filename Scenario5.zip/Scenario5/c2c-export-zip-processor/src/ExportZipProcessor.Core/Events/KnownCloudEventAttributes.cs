namespace ExportZipProcessor.Core.Events;

public static class KnownCloudEventAttributes
{
    public const string SsoUserId = "User.SsoUserId";

    public const string UserId = "User.UserId";
}
