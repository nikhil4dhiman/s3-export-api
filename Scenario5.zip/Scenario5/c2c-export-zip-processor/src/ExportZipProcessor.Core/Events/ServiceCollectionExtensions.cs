using ExportZipProcessor.Core.Events.Contexts;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace ExportZipProcessor.Core.Events;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddEventContextAccessor()
        {
            services.TryAddSingleton<EventProcessingContextStore>();
            services.TryAddSingleton<IEventProcessingContextAccessor>(
                sp => sp.GetRequiredService<EventProcessingContextStore>());
            services.TryAddSingleton<IEventProcessingContextSetter>(
                sp => sp.GetRequiredService<EventProcessingContextStore>());

            return services;
        }
    }
}
