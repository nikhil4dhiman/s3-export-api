using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;

namespace ExportZipProcessor.Core.Events.Contexts;

public class EventProcessingContext
{
    private readonly IDictionary<string, object?> _items;

    public EventProcessingContext(
        string eventId,
        string eventType,
        string eventSource,
        string? traceParent,
        IDictionary<string, object?> items)
    {
        EventId = eventId;
        EventType = eventType;
        EventSource = eventSource;
        TraceParent = traceParent;

        _items = items;
    }

    public string EventId { get; }
    public string EventType { get; }
    public string EventSource { get; }
    public string? TraceParent { get; }

    public bool TryGetItem<T>(string key, [NotNullWhen(true)] out T? value)
    {
        if (_items.TryGetValue(key, out var objectValue) && objectValue is T castedValue)
        {
            value = castedValue;
            return true;
        }

        value = default;
        return false;
    }
}
