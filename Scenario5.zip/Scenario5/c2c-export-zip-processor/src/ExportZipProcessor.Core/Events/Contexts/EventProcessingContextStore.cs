using System;
using System.Collections.Immutable;
using System.Threading;

namespace ExportZipProcessor.Core.Events.Contexts;

internal class EventProcessingContextStore : IEventProcessingContextAccessor, IEventProcessingContextSetter
{
    private static readonly EventProcessingContext EmptyContext = new(
        string.Empty,
        string.Empty,
        string.Empty,
        null,
        ImmutableDictionary<string, object?>.Empty);

    private static readonly AsyncLocal<ContextHolder> CurrentContext = new();

    public EventProcessingContext Context => CurrentContext.Value?.Context ?? EmptyContext;

    public IDisposable BeginProcessing(EventProcessingContext context)
    {
        return new ContextExecutionScope(this, context);
    }

    public void SetContext(EventProcessingContext context)
    {
        CurrentContext.Value = new ContextHolder { Context = context };
    }

    public void ClearContext()
    {
        SetContext(EmptyContext);
    }

    private class ContextHolder
    {
        public EventProcessingContext? Context { get; init; }
    }

    private sealed class ContextExecutionScope : IDisposable
    {
        private readonly EventProcessingContextStore _store;

        public ContextExecutionScope(EventProcessingContextStore store, EventProcessingContext context)
        {
            _store = store;
            _store.SetContext(context);
        }

        public void Dispose()
        {
            _store.ClearContext();
        }
    }
}
