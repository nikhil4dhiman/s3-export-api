using System;

namespace ExportZipProcessor.Core.Events.Contexts;

public interface IEventProcessingContextSetter
{
    IDisposable BeginProcessing(EventProcessingContext context);
}
