namespace ExportZipProcessor.Core.Events.Contexts.KnownItems;

public static class KnownEventProcessingContextItems
{
    public const string EventProperties = "EventProperties";
}
