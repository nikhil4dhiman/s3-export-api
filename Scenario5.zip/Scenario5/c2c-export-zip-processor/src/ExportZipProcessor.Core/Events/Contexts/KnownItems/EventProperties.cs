namespace ExportZipProcessor.Core.Events.Contexts.KnownItems;

public record EventProperties(int UserId, string? SsoUserId);
