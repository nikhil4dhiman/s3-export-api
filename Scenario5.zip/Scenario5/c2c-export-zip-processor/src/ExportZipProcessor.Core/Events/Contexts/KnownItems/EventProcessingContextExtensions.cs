namespace ExportZipProcessor.Core.Events.Contexts.KnownItems;

public static class EventProcessingContextExtensions
{
    extension(EventProcessingContext context)
    {
        public EventProperties? GetEventProperties()
        {
            return context.TryGetItem<EventProperties>(
                KnownEventProcessingContextItems.EventProperties,
                out var eventProperties)
                ? eventProperties
                : default;
        }
    }
}
