namespace ExportZipProcessor.Core.Events.Contexts;

public interface IEventProcessingContextAccessor
{
    EventProcessingContext Context { get; }
}
