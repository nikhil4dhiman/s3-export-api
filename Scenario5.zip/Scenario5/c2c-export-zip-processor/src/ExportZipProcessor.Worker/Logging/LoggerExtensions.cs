using System.Collections.Generic;
using ExportZipProcessor.ApplicationServices.Logging;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.EventHandling;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Worker.Logging;

internal static partial class LoggerExtensions
{
    public static void LogSendingSqsEventToDlq(
        this ILogger<ZipGenerationRequestedEventHandler> logger,
        ZipGenerationInfo zipGenerationInfo,
        string errorMessage)
    {
        var scope = new Dictionary<string, object?>
        {
            [nameof(ZipGenerationInfo)] = zipGenerationInfo.ToLoggingScope()
        };

        using var _ = logger.BeginScope(scope);

        logger.LogSendingSqsEventToDlq(errorMessage);
    }

    public static void LogRetryingSqsEventAfterTransientFailure(
        this ILogger<ZipGenerationRequestedEventHandler> logger,
        ZipGenerationInfo zipGenerationInfo,
        string errorMessage)
    {
        var scope = new Dictionary<string, object?>
        {
            [nameof(ZipGenerationInfo)] = zipGenerationInfo.ToLoggingScope()
        };

        using var _ = logger.BeginScope(scope);

        logger.LogRetryingSqsEventAfterTransientFailure(errorMessage);
    }

    [LoggerMessage(
        Level = LogLevel.Error,
        Message = "An error occurred during events processing. Sending event to DLQ. Error message: {ErrorMessage}")]
    private static partial void LogSendingSqsEventToDlq(
        this ILogger<ZipGenerationRequestedEventHandler> logger,
        string errorMessage);

    [LoggerMessage(
        Level = LogLevel.Warning,
        Message = "A transient error occurred during events processing. Scheduling the event for retry. "
                  + "Error message: {ErrorMessage}")]
    private static partial void LogRetryingSqsEventAfterTransientFailure(
        this ILogger<ZipGenerationRequestedEventHandler> logger,
        string errorMessage);
}
