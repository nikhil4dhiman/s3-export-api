using System;
using System.ComponentModel.DataAnnotations;
using ExportZipProcessor.Domain.Configuration;

namespace ExportZipProcessor.Worker.Configuration;

internal class EventsProcessingOptions : IEventQueueOptions
{
    [Required]
    public required string QueueUrl { get; init; }

    [Required]
    public required string DeadLetterQueueUrl { get; init; }

    [Required]
    [Range(1, 10)]
    public required int MaxNumberOfMessages { get; init; }

    [Required]
    public required TimeSpan MessageProcessingTimeout { get; init; }

    [Required]
    public required TimeSpan VisibilityTimeout { get; init; }

    [Required]
    public required TimeSpan TransientFailureRetryDelay { get; init; }
}
