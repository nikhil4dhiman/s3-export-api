using ExportZipProcessor.Domain.Constants;
using ExportZipProcessor.Domain.Metrics;
using Prometheus;

namespace ExportZipProcessor.Worker.Metrics;

internal class MetricsService : IMetricsService
{
    private const string ApplicationName = "c2c_export_zip_processor";

    // An export ranges from a handful of small files to hundreds of gigabytes streamed over
    // several hours, so both histograms need buckets spanning many orders of magnitude;
    // linear buckets would collapse almost every observation into one bucket. Doubling rather
    // than quadrupling keeps the resolution usable below 1 GiB, where most exports land -
    // histogram_quantile interpolates linearly inside a bucket, so a coarse bucket there
    // makes p50/p95 unreliable in exactly the range we care about most.
    private static readonly double[] DurationBuckets = Histogram.ExponentialBuckets(1, 2, 16);

    private static readonly double[] SizeBuckets = Histogram.ExponentialBuckets(SizeConstants.OneMegabyte, 2, 21);

    private readonly Counter _downloadsProxyApiErrorsCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_downloads_proxy_api_errors_total",
        "Number of downloads proxy api errors",
        MetricLabelNames.Result);

    private readonly Counter _zipGenerationEventsProcessedCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_zip_generation_events_processed_total",
        "Number of processed zip generation events",
        MetricLabelNames.Result);

    private readonly Counter _resultEventsPublishedCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_result_events_published_total",
        "Number of published result events",
        MetricLabelNames.Result,
        MetricLabelNames.State);

    private readonly Histogram _zipGenerationDurationHistogram = Prometheus.Metrics.CreateHistogram(
        $"{ApplicationName}_zip_generation_duration_seconds",
        "Time taken to build an export zip archive from its staged files",
        new HistogramConfiguration
        {
            LabelNames = [MetricLabelNames.Result],
            Buckets = DurationBuckets
        });

    private readonly Histogram _zipArchiveSizeHistogram = Prometheus.Metrics.CreateHistogram(
        $"{ApplicationName}_zip_archive_size_bytes",
        "Size of a generated export zip archive",
        new HistogramConfiguration { Buckets = SizeBuckets });

    private readonly Histogram _stagedFilesSizeHistogram = Prometheus.Metrics.CreateHistogram(
        $"{ApplicationName}_staged_files_size_bytes",
        "Total size of the staged files a generated export zip archive was built from",
        new HistogramConfiguration { Buckets = SizeBuckets });

    public void IncreaseNumberOfDownloadsProxyApiErrors(string result)
    {
        _downloadsProxyApiErrorsCounter.WithLabels(result).Inc();
    }

    public void IncreaseNumberOfZipGenerationEventsProcessed(string result)
    {
        _zipGenerationEventsProcessedCounter.WithLabels(result).Inc();
    }

    public void IncreaseNumberOfResultEventsPublished(string result, string state)
    {
        _resultEventsPublishedCounter.WithLabels(result, state).Inc();
    }

    public void ObserveZipGenerationDuration(string result, double durationInSeconds)
    {
        _zipGenerationDurationHistogram.WithLabels(result).Observe(durationInSeconds);
    }

    public void ObserveZipArchiveSize(long sizeInBytes)
    {
        _zipArchiveSizeHistogram.Observe(sizeInBytes);
    }

    public void ObserveStagedFilesSize(long sizeInBytes)
    {
        _stagedFilesSizeHistogram.Observe(sizeInBytes);
    }
}
