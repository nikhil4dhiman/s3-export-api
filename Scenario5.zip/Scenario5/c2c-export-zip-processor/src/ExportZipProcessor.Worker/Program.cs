using System;
using Cove.Platform.Extensions.Configuration;
using Cove.Platform.Extensions.Logging.AspNetCore.Serilog;
using ExportZipProcessor.Worker.IoC;
using ExportZipProcessor.Worker.RequestPipeline.HealthChecks;
using ExportZipProcessor.Worker.RequestPipeline.Metrics;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Hosting;
using Serilog;

namespace ExportZipProcessor.Worker;

#pragma warning disable CA1031 // catching a generic exception to write details in log properly and shut down the app

internal sealed class Program
{
    public static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        Log.Logger = SerilogLoggerFactory.Create(builder.Environment);

        var bootstrapLogger = Log.ForContext<Program>();

        try
        {
            bootstrapLogger.Information("Bootstrapping application");

            builder.Host.UseDefaultServiceProvider(options =>
            {
                options.ValidateScopes = true;
                options.ValidateOnBuild = true;
            });

            builder.Services.RegisterApplicationDependencies(builder.Environment, builder.Configuration);
            builder.Host.UseSerilog();

            var app = builder.Build();

            var managementPort = app.Configuration.GetManagementPort();

            app.UseHealthChecksPipeline(managementPort)
                .UseMetricsPipeline(managementPort);

            bootstrapLogger.Information("Starting application");

            app.Run();
        }
        catch (Exception e)
        {
            bootstrapLogger.Fatal(e, "Application terminated unexpectedly");
        }
        finally
        {
            Log.CloseAndFlush();
        }
    }
}
