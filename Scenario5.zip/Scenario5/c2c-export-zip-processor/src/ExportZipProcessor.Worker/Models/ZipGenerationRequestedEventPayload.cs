using System;
using System.Text.Json.Serialization;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Worker.Models;

internal class ZipGenerationRequestedEventPayload
{
    public required string ExportId { get; init; }

    public required string PartnerId { get; init; }

    public required string SourceName { get; init; }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public required SourceType SourceType { get; init; }

    public required DateTimeOffset ZipRequestedAt { get; init; }
}
