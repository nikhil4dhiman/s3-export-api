using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.Models;
using Riok.Mapperly.Abstractions;

namespace ExportZipProcessor.Worker.Mapping;

[Mapper(RequiredMappingStrategy = RequiredMappingStrategy.Target)]
internal static partial class MapperExtensions
{
    public static partial ZipGenerationInfo ToDomainModel(this ZipGenerationRequestedEventPayload payload);
}
