using ExportZipProcessor.Core.HealthChecks;
using ExportZipProcessor.Data.S3.HealthChecks;
using ExportZipProcessor.Data.SqsPublisher.HealthChecks;
using ExportZipProcessor.Worker.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Prometheus;

namespace ExportZipProcessor.Worker.RequestPipeline.HealthChecks;

internal static class HealthChecksServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddApplicationHealthChecks()
        {
            services
                .AddHealthChecks()
                .AddWorkerHealthCheck()
                .AddAmazonS3BucketHealthCheck(HealthCheckConstants.ReadinessTag)
                .AddAmazonSqsProcessingHealthCheck(HealthCheckConstants.ReadinessTag)
                .AddAmazonSqsPublisherHealthCheck(HealthCheckConstants.ReadinessTag)
                .ForwardToPrometheus();

            return services;
        }
    }

    extension(IHealthChecksBuilder healthChecksBuilder)
    {
        internal IHealthChecksBuilder AddWorkerHealthCheck()
        {
            return healthChecksBuilder.AddCheck(
                "Application is alive",
                () => HealthCheckResult.Healthy("Application is alive"),
                [HealthCheckConstants.LivenessTag]);
        }

        internal IHealthChecksBuilder AddAmazonSqsProcessingHealthCheck(params string[] tags)
        {
            return healthChecksBuilder.AddAmazonSqsHealthCheck(
                "SQS queue is available for processing",
                sp => sp.GetRequiredService<IOptions<EventsProcessingOptions>>().Value.QueueUrl,
                tags);
        }
    }
}
