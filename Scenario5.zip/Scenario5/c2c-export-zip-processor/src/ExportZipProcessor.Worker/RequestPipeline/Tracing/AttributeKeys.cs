namespace ExportZipProcessor.Worker.RequestPipeline.Tracing;

internal static class AttributeKeys
{
    // https://opentelemetry.io/docs/specs/semconv/registry/attributes/deployment/#deployment-environment-name
    public const string DeploymentEnvironmentName = "deployment.environment.name";

    // https://opentelemetry.io/docs/specs/semconv/registry/attributes/deployment/#deployment-environment
    // This is deprecated in favor of deployment.environment.name, but we set it for backward compatibility with
    // SigNoz that uses this attribute.
    public const string DeploymentEnvironment = "deployment.environment";
}
