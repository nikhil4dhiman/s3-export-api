using System;
using System.Diagnostics;
using System.Net.Http;
using Cove.Platform.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using OpenTelemetry.Exporter;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace ExportZipProcessor.Worker.RequestPipeline.Tracing;

internal static class OpenTelemetryServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddOpenTelemetryTracing(
            IHostEnvironment environment,
            IConfiguration configuration)
        {
            var managementPort = configuration.GetManagementPort();

            var tracingOptions = configuration.GetRequiredSection(TracingOptions.SectionName).Get<TracingOptions>()!;
            tracingOptions.Validate();

            services
                .AddOpenTelemetry()
                .ConfigureResource(resource => resource
                    .AddService(
                        serviceName: environment.ApplicationName,
                        serviceNamespace: "export-zip")
                    .AddAttributes(
                    [
                        new(AttributeKeys.DeploymentEnvironment, tracingOptions.EnvironmentName),
                        new(AttributeKeys.DeploymentEnvironmentName, tracingOptions.EnvironmentName)
                    ]))
                .WithTracing(tracing =>
                {
                    tracing
                        .AddAspNetCoreInstrumentation(options =>
                        {
                            options.Filter = httpContext => FilterIncomingHttpRequests(httpContext, managementPort);
                        })
                        .AddHttpClientInstrumentation(options =>
                        {
                            options.EnrichWithHttpRequestMessage = EnrichActivityWithHttpRequestMessage;

                            options.EnrichWithHttpResponseMessage = EnrichActivityWithHttpResponseMessage;

                            options.RecordException = true;
                        })
                        .AddAWSInstrumentation(options =>
                        {
                            options.SuppressDownstreamInstrumentation = true;
                        })
                        .AddSource("Cove.*")
                        .AddSource("ExportZipProcessor.*")
                        .SetErrorStatusOnException();

                    tracing.AddOtlpExporter(options =>
                    {
                        options.Endpoint = new Uri(tracingOptions.ExporterEndpoint);
                        options.Protocol = OtlpExportProtocol.Grpc;
                    });

                    if (environment.IsDevelopment())
                    {
                        tracing.AddConsoleExporter();
                    }
                });

            return services;
        }
    }

    private static bool FilterIncomingHttpRequests(HttpContext httpContext, int managementPort)
    {
        // don't instrument management port activities
        return httpContext.Request.Host.Port != managementPort;
    }

    private static void EnrichActivityWithHttpRequestMessage(
        Activity activity,
        HttpRequestMessage httpRequestMessage)
    {
        activity.DisplayName = $"{httpRequestMessage.Method} {httpRequestMessage.RequestUri?.AbsolutePath}";
    }

    private static void EnrichActivityWithHttpResponseMessage(
        Activity activity,
        HttpResponseMessage httpResponseMessage)
    {
        var activityStatus = httpResponseMessage.IsSuccessStatusCode
            ? ActivityStatusCode.Ok
            : ActivityStatusCode.Error;

        activity.SetStatus(activityStatus);
    }
}
