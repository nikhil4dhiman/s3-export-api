using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling.Results;
using Cove.Platform.Extensions.ProcessingPipeline.EventsHandling.CloudEvents;
using ExportZipProcessor.ApplicationServices;
using ExportZipProcessor.Domain.Exceptions;
using ExportZipProcessor.Domain.Metrics;
using ExportZipProcessor.Worker.Configuration;
using ExportZipProcessor.Worker.Logging;
using ExportZipProcessor.Worker.Mapping;
using ExportZipProcessor.Worker.Models;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Worker.EventHandling;

#pragma warning disable CA1711 // reserved naming of EventHandler is used here for better readability

internal class ZipGenerationRequestedEventHandler : ITypedCloudEventHandler<ZipGenerationRequestedEventPayload>
{
    private readonly ZipGenerationService _zipGenerationService;
    private readonly IMetricsService _metricsService;
    private readonly EventsProcessingOptions _options;
    private readonly ILogger<ZipGenerationRequestedEventHandler> _logger;

    public ZipGenerationRequestedEventHandler(
        ZipGenerationService zipGenerationService,
        IMetricsService metricsService,
        EventsProcessingOptions options,
        ILogger<ZipGenerationRequestedEventHandler> logger)
    {
        _zipGenerationService = zipGenerationService;
        _metricsService = metricsService;
        _options = options;
        _logger = logger;
    }

    public async Task HandleAsync(
        CloudEventContext<ZipGenerationRequestedEventPayload> context,
        CancellationToken cancellationToken)
    {
        var zipGenerationInfo = context.Payload.ToDomainModel();

        try
        {
            await _zipGenerationService.ProcessZipGeneration(
                zipGenerationInfo,
                cancellationToken);

            _metricsService.IncreaseNumberOfZipGenerationEventsProcessed(MetricLabelValues.Result.Processed);

            context.ProcessingContext.SetProcessingResult(SuccessResult.Create());
        }
        catch (ZipGenerationException e) when (e.IsTransient)
        {
            // Transient infrastructure failures are worth retrying before giving up: the
            // message goes back to the queue and only lands in the DLQ once the redrive
            // policies receive count is exhausted. A retried attempt reuses a previously
            // completed archive instead of regenerating it.
            _logger.LogRetryingSqsEventAfterTransientFailure(zipGenerationInfo, e.Message);

            _metricsService.IncreaseNumberOfZipGenerationEventsProcessed(MetricLabelValues.Result.Retried);

            context.ProcessingContext.SetProcessingResult(
                RetryableWithDelayErrorResult.Create(_options.TransientFailureRetryDelay, e));
        }
        catch (Exception e) when (e is not (InvalidOperationException or OperationCanceledException))
        {
            _logger.LogSendingSqsEventToDlq(zipGenerationInfo, e.Message);

            _metricsService.IncreaseNumberOfZipGenerationEventsProcessed(MetricLabelValues.Result.Failed);

            var attributes = new Dictionary<string, string> { ["ErrorMessage"] = e.Message };

            context.ProcessingContext.SetProcessingResult(
                SendEventToDlqResult.Create(nameof(ProcessingException), attributes));
        }
    }
}
