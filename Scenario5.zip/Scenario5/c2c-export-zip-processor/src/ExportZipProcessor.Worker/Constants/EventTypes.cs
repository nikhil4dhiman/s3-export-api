namespace ExportZipProcessor.Worker.Constants;

internal static class EventTypes
{
    public const string ZipGenerationRequested = "com.n-able.cove.events.c2c.export.zip.generation.requested";
}
