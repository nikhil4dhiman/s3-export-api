namespace ExportZipProcessor.Worker.Constants;

internal static class PipelineConstants
{
    public const string EventsProcessingPipeline = "SqsEventsProcessingPipeline";
}
