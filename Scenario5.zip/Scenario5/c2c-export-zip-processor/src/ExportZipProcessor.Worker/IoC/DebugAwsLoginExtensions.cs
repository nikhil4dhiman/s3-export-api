#if DEBUG
using Amazon;
using Amazon.Extensions.NETCore.Setup;
using Amazon.Runtime;
using Microsoft.Extensions.Configuration;
#endif

using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.Worker.IoC;

internal static class DebugAwsLoginExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddAutomaticAwsLoginInDebugMode()
        {
#if DEBUG
            services.AddDefaultAWSOptions(sp =>
            {
                var configuration = sp.GetRequiredService<IConfiguration>();
                var awsLoginCommand = configuration.GetValue<string?>("AwsCredentials:LoginCommand");
                if (string.IsNullOrWhiteSpace(awsLoginCommand))
                {
                    return null;
                }

                return new AWSOptions
                {
                    Region = RegionEndpoint.EUWest1,
                    Credentials = new ProcessAWSCredentials(awsLoginCommand)
                };
            });
#endif

            return services;
        }
    }
}
