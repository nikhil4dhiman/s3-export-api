using System;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Configuration;
using Cove.Platform.Extensions.ProcessingPipeline;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ProcessingStrategies;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling.Results;
using Cove.Platform.Extensions.ProcessingPipeline.EventsHandling.CloudEvents;
using ExportZipProcessor.ApplicationServices;
using ExportZipProcessor.Core.Events;
using ExportZipProcessor.Data.DownloadsProxyApi;
using ExportZipProcessor.Data.FooApi;
using ExportZipProcessor.Data.S3;
using ExportZipProcessor.Data.SqsPublisher;
using ExportZipProcessor.Domain.Metrics;
using ExportZipProcessor.Worker.Configuration;
using ExportZipProcessor.Worker.Constants;
using ExportZipProcessor.Worker.EventHandling;
using ExportZipProcessor.Worker.Metrics;
using ExportZipProcessor.Worker.Models;
using ExportZipProcessor.Worker.RequestPipeline.HealthChecks;
using ExportZipProcessor.Worker.RequestPipeline.Tracing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ExportZipProcessor.Worker.IoC;

internal static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection RegisterApplicationDependencies(
            IHostEnvironment environment,
            IConfiguration configuration)
        {
            return services
                .AddSharedServices(environment, configuration)
                .AddApplicationServices()
                .AddFooApiServices()
                .AddS3Services()
                .AddSqsEventsProcessingPipeline()
                .AddEventsPublishingServices()
                .AddDownloadsProxyApiServices()
                .AddApplicationHealthChecks();
        }

        private IServiceCollection AddSharedServices(
            IHostEnvironment environment,
            IConfiguration configuration)
        {
            return services
                .AddOpenTelemetryTracing(environment, configuration)
                .AddSingleton(TimeProvider.System)
                .AddSingleton<IMetricsService, MetricsService>()
                .AddEventContextAccessor();
        }

        private IServiceCollection AddSqsEventsProcessingPipeline()
        {
            services.AddScoped<ZipGenerationRequestedEventHandler>();

            services
                .AddOptionsAndValidate<EventsProcessingOptions>()
                .AddAutomaticAwsLoginInDebugMode()
                .AddProcessingPipelineServices(PipelineConstants.EventsProcessingPipeline)
                .AddAmazonSqs((options, sp) =>
                {
                    var processingOptions = sp.GetRequiredService<EventsProcessingOptions>();

                    options.QueueUrl = processingOptions.QueueUrl;
                    options.DeadLetterQueueUrl = processingOptions.DeadLetterQueueUrl;
                    options.MaxNumberOfMessages = processingOptions.MaxNumberOfMessages;
                    options.MessageProcessingTimeout = processingOptions.MessageProcessingTimeout;
                    options.VisibilityTimeout = processingOptions.VisibilityTimeout;
                    options.AutomaticallyExtendVisibilityTimeout = true;

                    options.MessageIsForwardedFromAmazonSns = false;
                    options.EventsProcessingStrategy = ParallelEventsProcessingStrategy.Instance;
                })
                .ConfigurePipeline(builder => builder
                    .UseDefaultPipelineMiddlewares()
                    .UseCloudEventHandling(mapping => mapping
                            .HandleEvent<ZipGenerationRequestedEventPayload>(
                                EventTypes.ZipGenerationRequested,
                                pipeline => pipeline.HandleUsing<ZipGenerationRequestedEventHandler>())
                            .DiscardUnmappedEventTypes(ctx =>
                            {
                                ctx.ProcessingContext.SetProcessingResult(
                                    DiscardEventResult.Create("EventTypeHandlerIsNotMapped"));

                                return Task.CompletedTask;
                            }),
                        options => options.UseDefaultAmazonSqsEventParser()));

            return services;
        }
    }
}
