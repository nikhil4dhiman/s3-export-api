using System;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Domain.ApiClients;

public interface IDownloadsProxyApiClient
{
    Task<string> CreateFileAssociationAsync(
        Uri fileUrl,
        string zipFileName,
        ZipGenerationInfo zipGenerationInfo,
        CancellationToken cancellationToken);
}
