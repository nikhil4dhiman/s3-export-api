using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Domain.ApiClients;

public interface IFooApiClient
{
    Task<string> PostAsync(FooInfo fooInfo, CancellationToken cancellationToken);
}
