namespace ExportZipProcessor.Domain.Configuration;

public interface IEventQueueOptions
{
    string QueueUrl { get; }
}
