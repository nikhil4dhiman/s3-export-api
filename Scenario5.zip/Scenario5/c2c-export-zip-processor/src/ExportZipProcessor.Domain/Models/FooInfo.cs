namespace ExportZipProcessor.Domain.Models;

public class FooInfo
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;
}
