namespace ExportZipProcessor.Domain.Models;

/// <summary>
/// A staged file to be included in the export zip. <paramref name="EntryName"/> is the
/// path of the file relative to the staging prefix, so nested staged files keep their
/// structure inside the archive and cannot collide with same-named files in other folders.
/// </summary>
public record StagedFile(string Key, long Size, string EntryName);
