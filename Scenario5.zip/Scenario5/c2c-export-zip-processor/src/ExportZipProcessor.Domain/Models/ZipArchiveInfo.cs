using System;

namespace ExportZipProcessor.Domain.Models;

public record ZipArchiveInfo(Uri Location, long SizeInBytes);
