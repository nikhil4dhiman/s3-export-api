namespace ExportZipProcessor.Domain.Models;

/// <summary>
/// The workload an export was taken from. Selects the suffix used in the archive name.
/// </summary>
public enum SourceType
{
    SharePoint,
    OneDrive
}
