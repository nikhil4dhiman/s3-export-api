using System;

namespace ExportZipProcessor.Domain.Models;

public class ZipGenerationInfo
{
    public required string ExportId { get; init; }

    public required string PartnerId { get; init; }

    public required string SourceName { get; init; }

    public required SourceType SourceType { get; init; }

    public required DateTimeOffset ZipRequestedAt { get; init; }
}
