using System.Collections.Generic;

namespace ExportZipProcessor.Domain.Models;

public class SampleEvent
{
    public string Id { get; set; } = null!;

    public string Type { get; set; } = null!;

    public IReadOnlyCollection<byte> Payload { get; set; } = [];
}
