namespace ExportZipProcessor.Domain.Constants;

/// <summary>
/// Byte-size units shared across the layers, so the storage layer and the metrics layer
/// agree on what a megabyte is rather than each defining its own.
/// </summary>
public static class SizeConstants
{
    public const int OneMegabyte = 1024 * 1024;
}
