using System;

namespace ExportZipProcessor.Domain.Exceptions;

public class DomainException : Exception
{
    protected DomainException(string message)
        : base(message)
    {
    }
}
