using System;

namespace ExportZipProcessor.Domain.Exceptions;

public class ProcessingException : Exception
{
    protected ProcessingException(string message)
        : base(message)
    {
    }

    protected ProcessingException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
