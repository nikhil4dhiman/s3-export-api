using System;

namespace ExportZipProcessor.Domain.Exceptions;

public class EventPublishingException : ProcessingException
{
    protected EventPublishingException(string message, Exception innerException)
        : base(message, innerException)
    {
    }
}
