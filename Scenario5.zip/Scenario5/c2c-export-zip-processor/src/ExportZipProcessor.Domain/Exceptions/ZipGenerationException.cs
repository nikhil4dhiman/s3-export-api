using System;

namespace ExportZipProcessor.Domain.Exceptions;

public class ZipGenerationException : ProcessingException
{
    public ZipGenerationException(string message)
        : base(message)
    {
    }

    public ZipGenerationException(string message, Exception innerException)
        : base(message, innerException)
    {
    }

    public ZipGenerationException(string message, Exception innerException, bool isTransient)
        : base(message, innerException)
    {
        IsTransient = isTransient;
    }

    /// <summary>
    /// Whether the failure is transient (network fault, throttling, service error) and the
    /// zip generation is worth retrying, as opposed to a permanent failure that would fail
    /// again on every attempt.
    /// </summary>
    public bool IsTransient { get; }
}
