using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Domain.Storage;

public interface IStagedFilesStorage
{
    /// <summary>
    /// Lists the staged files under <paramref name="stagingPrefix"/>. Returns an empty list
    /// when nothing is staged, which the caller must handle (a redelivered message may arrive
    /// after a previous attempt already cleaned the staging area up).
    /// </summary>
    Task<IReadOnlyList<StagedFile>> ListStagedFilesAsync(
        string stagingPrefix,
        CancellationToken cancellationToken);

    Task DeleteStagedFilesAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        CancellationToken cancellationToken);
}
