using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Domain.Storage;

public interface IZipArchiveWriter
{
    /// <summary>
    /// Returns the location of an already-written zip archive at <paramref name="zipFileKey"/>
    /// that was built from the given staged files, or <c>null</c> when no such archive exists
    /// and it has to be generated. Lets a redelivered message reuse the result of a previous
    /// attempt instead of regenerating a potentially very large archive.
    /// </summary>
    Task<Uri?> FindExistingArchiveAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        string zipFileKey,
        CancellationToken cancellationToken);

    /// <summary>
    /// Writes a zip archive built from the given staged files to the object identified by
    /// <paramref name="zipFileKey"/> and returns its location and size.
    /// </summary>
    Task<ZipArchiveInfo> WriteAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        string zipFileKey,
        CancellationToken cancellationToken);
}
