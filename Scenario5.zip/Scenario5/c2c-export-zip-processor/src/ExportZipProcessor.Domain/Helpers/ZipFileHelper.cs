using System;
using System.Buffers;
using System.Globalization;
using System.Text;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Domain.Helpers;

/// <summary>
/// Builds the archive name from the exported source, as
/// <c>&lt;source name&gt;_&lt;export type&gt;_&lt;yyyy-MM-dd&gt;_&lt;HHmmss&gt;.zip</c>. Underscores
/// separate the three components. A SharePoint source name is free text, so it keeps only
/// letters and digits, with every other character becoming a word boundary that capitalises
/// what follows. A OneDrive source name is a user identifier (an email or UPN), so it keeps its
/// case, letters, digits and "._-+", turns "@" into "_at_", and replaces anything else a file
/// name cannot carry safely with "_".
/// </summary>
public static class ZipFileHelper
{
    private const string Extension = ".zip";
    private const char ComponentSeparator = '_';
    private const string DateTimeFormat = "yyyy-MM-dd_HHmmss";
    private const int SourceNameMaxLength = 128;
    private const char At = '@';
    private const string AtReplacement = "_at_";
    private const char Underscore = '_';

    private static readonly SearchValues<char> SafeUserIdentifierPunctuation =
        SearchValues.Create(".-_+");

    public const string FallbackZipFileName = "final.zip";

    /// <summary>
    /// Returns the archive file name, or <see cref="FallbackZipFileName"/> when the sanitised
    /// source name is empty.
    /// </summary>
    public static string BuildZipFileName(ZipGenerationInfo zipGenerationInfo)
    {
        var sanitisedSourceName = zipGenerationInfo.SourceType switch
        {
            SourceType.OneDrive => SanitiseUserIdentifier(zipGenerationInfo.SourceName),
            _ => Sanitise(zipGenerationInfo.SourceName)
        };

        if (sanitisedSourceName.Length == 0)
        {
            return FallbackZipFileName;
        }

        var timestamp = zipGenerationInfo.ZipRequestedAt.UtcDateTime
            .ToString(DateTimeFormat, CultureInfo.InvariantCulture);

        return string.Join(
            ComponentSeparator,
            sanitisedSourceName,
            BuildSourceType(zipGenerationInfo.SourceType),
            timestamp) + Extension;
    }

    public static string BuildStagingPrefix(string exportId)
    {
        return $"exports/{exportId}/staging/";
    }

    public static string BuildZipFileKey(string exportId, string zipFileName)
    {
        return $"exports/{exportId}/{zipFileName}";
    }

    /// <summary>
    /// What the end user sees when downloading. Every unnameable export would otherwise share
    /// the one fallback name, so those fall back to the export id instead.
    /// </summary>
    public static string BuildDownloadFileName(string exportId, string zipFileName)
    {
        return zipFileName == FallbackZipFileName ? exportId : zipFileName;
    }

    private static string BuildSourceType(SourceType sourceType)
    {
        return sourceType switch
        {
            SourceType.SharePoint => "SharePointExport",
            SourceType.OneDrive => "OneDriveExport",
            _ => throw new InvalidOperationException($"Unknown source type '{sourceType}'.")
        };
    }

    /// <summary>
    /// Source names are free text, so keep only letters and digits: that leaves the underscores
    /// between components as the only separators in the name, and drops everything a file name
    /// or an S3 key cannot carry safely - path and wildcard characters, '%' and '#', and the
    /// invisible format characters that can reorder how a name renders. Anything dropped
    /// capitalises the letter that follows, so "Marketing Team Site" reads as
    /// "MarketingTeamSite". The length is capped to keep the key inside S3 limits.
    /// <para>
    /// Iterated by rune rather than by char so a letter outside the BMP - which is a surrogate
    /// pair, and neither half of a pair is a letter on its own - is kept whole. Non-ASCII
    /// letters survive the round trip through <c>AmazonS3Uri</c>, which percent-decodes them.
    /// </para>
    /// </summary>
    private static string Sanitise(string sourceName)
    {
        var builder = new StringBuilder(sourceName.Length);
        var startOfWord = true;

        foreach (var rune in sourceName.EnumerateRunes())
        {
            if (!Rune.IsLetterOrDigit(rune))
            {
                // A whole run is one boundary, so "Site / Name" gives "SiteName".
                startOfWord = true;

                continue;
            }

            builder.Append((startOfWord ? Rune.ToUpperInvariant(rune) : rune).ToString());
            startOfWord = false;
        }

        return Truncate(builder.ToString());
    }

    private static string SanitiseUserIdentifier(string sourceName)
    {
        var builder = new StringBuilder(sourceName.Length);

        foreach (var rune in sourceName.EnumerateRunes())
        {
            if (rune.Value == At)
            {
                builder.Append(AtReplacement);

                continue;
            }

            var isSafe = Rune.IsLetterOrDigit(rune)
                || (rune.IsAscii && SafeUserIdentifierPunctuation.Contains((char)rune.Value));

            builder.Append(isSafe ? rune.ToString() : Underscore);
        }

        return Truncate(builder.ToString());
    }

    /// <summary>
    /// Caps the length without splitting a surrogate pair, since half a pair is not a valid
    /// string and would not survive the round trip through the S3 key.
    /// </summary>
    private static string Truncate(string sanitised)
    {
        if (sanitised.Length <= SourceNameMaxLength)
        {
            return sanitised;
        }

        // If the last char kept opens a pair, its other half is past the cut, so drop it too.
        var length = char.IsHighSurrogate(sanitised[SourceNameMaxLength - 1])
            ? SourceNameMaxLength - 1
            : SourceNameMaxLength;

        return sanitised[..length];
    }
}
