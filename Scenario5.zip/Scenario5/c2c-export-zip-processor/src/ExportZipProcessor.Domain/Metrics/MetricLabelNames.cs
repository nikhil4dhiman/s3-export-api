namespace ExportZipProcessor.Domain.Metrics;

public static class MetricLabelNames
{
    public const string Result = "result";
    public const string Type = "type";
    public const string State = "state";
    public const string ReportKind = "reportkind";
}
