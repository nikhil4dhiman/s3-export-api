namespace ExportZipProcessor.Domain.Metrics;

public interface IMetricsService
{
    void IncreaseNumberOfDownloadsProxyApiErrors(string result);

    void IncreaseNumberOfZipGenerationEventsProcessed(string result);

    void IncreaseNumberOfResultEventsPublished(string result, string state);

    void ObserveZipGenerationDuration(string result, double durationInSeconds);

    void ObserveZipArchiveSize(long sizeInBytes);

    void ObserveStagedFilesSize(long sizeInBytes);
}
