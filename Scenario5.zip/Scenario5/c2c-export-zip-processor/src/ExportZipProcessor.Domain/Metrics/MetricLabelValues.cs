namespace ExportZipProcessor.Domain.Metrics;

#pragma warning disable CA1034 // Nested types are ok here as they group related constants together

public static class MetricLabelValues
{
    public static class Result
    {
        public const string Processed = "processed";
        public const string Published = "published";
        public const string Failed = "failed";
        public const string Retried = "retried";
    }
}
