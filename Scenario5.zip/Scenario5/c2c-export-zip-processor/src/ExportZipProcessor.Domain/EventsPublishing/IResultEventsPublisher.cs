using System.Threading;
using System.Threading.Tasks;

namespace ExportZipProcessor.Domain.EventsPublishing;

public interface IResultEventsPublisher
{
    Task PublishCompletedEventAsync(
        string exportId,
        string fileId,
        CancellationToken cancellationToken);

    Task PublishFailedEventAsync(
        string exportId,
        string errorMessage,
        CancellationToken cancellationToken);
}
