using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Domain.Repositories;

public interface ISampleEventsRepository
{
    Task InsertEventAsync(SampleEvent @event, CancellationToken cancellationToken);
}
