using System.ComponentModel.DataAnnotations;
using ExportZipProcessor.Domain.Configuration;

namespace ExportZipProcessor.Data.SqsPublisher.Configuration;

public class EventsPublishingOptions : IEventQueueOptions
{
    [Required]
    public required string QueueUrl { get; init; }
}
