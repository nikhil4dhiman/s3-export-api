using System;
using ExportZipProcessor.Domain.Exceptions;

namespace ExportZipProcessor.Data.SqsPublisher.Exceptions;

public class SqsPublishingException : EventPublishingException
{
    public SqsPublishingException(string exportId, Exception innerException)
        : base(
            $"Failed to publish export result events to c2c export zip manager results SQS. ExportId: {exportId}",
            innerException)
    {
    }
}
