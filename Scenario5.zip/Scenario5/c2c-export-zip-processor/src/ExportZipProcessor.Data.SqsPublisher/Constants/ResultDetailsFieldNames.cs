namespace ExportZipProcessor.Data.SqsPublisher.Constants;

internal static class ResultDetailsFieldNames
{
    public const string FileId = "fileId";

    public const string ErrorMessage = "errorMessage";
}
