namespace ExportZipProcessor.Data.SqsPublisher.Constants;

internal static class ExportResultState
{
    public const string Completed = "Completed";

    public const string Failed = "Failed";
}
