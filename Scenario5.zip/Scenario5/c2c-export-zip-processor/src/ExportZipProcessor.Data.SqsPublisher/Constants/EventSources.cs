using System;

namespace ExportZipProcessor.Data.SqsPublisher.Constants;

internal static class EventSources
{
    public static readonly Uri ExportZipProcessor = new("com.n-able.cove.c2c.c2c-export-zip-processor", UriKind.Relative);
}
