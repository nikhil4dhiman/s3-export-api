namespace ExportZipProcessor.Data.SqsPublisher.Constants;

internal static class ExportResultEventTypes
{
    public const string ZipGenerationResult = "com.n-able.cove.events.c2c.export.zip.generation.result";
}
