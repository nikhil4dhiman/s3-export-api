using Amazon.SQS.Model;
using Cove.Platform.Extensions.Communication.Constants.Messaging;

namespace ExportZipProcessor.Data.SqsPublisher.Extensions;

internal static class SendMessageRequestExtensions
{
    public static SendMessageRequest SetTraceParentAttribute(this SendMessageRequest request, string value)
    {
        return request.SetStringAttribute(KnownAmazonMessageAttributes.TraceParent, value);
    }

    private static SendMessageRequest SetStringAttribute(this SendMessageRequest request, string name, string value)
    {
        var attribute = new MessageAttributeValue
        {
            DataType = "String",
            StringValue = value
        };

        request.MessageAttributes ??= [];

        request.MessageAttributes[name] = attribute;

        return request;
    }
}
