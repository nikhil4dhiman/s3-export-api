using ExportZipProcessor.Core.HealthChecks;
using ExportZipProcessor.Data.SqsPublisher.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ExportZipProcessor.Data.SqsPublisher.HealthChecks;

public static class HealthChecksServiceCollectionExtensions
{
    extension(IHealthChecksBuilder healthChecksBuilder)
    {
        public IHealthChecksBuilder AddAmazonSqsPublisherHealthCheck(params string[] tags)
        {
            return healthChecksBuilder.AddAmazonSqsHealthCheck(
                "SQS queue is available for publishing",
                sp => sp.GetRequiredService<IOptions<EventsPublishingOptions>>().Value.QueueUrl,
                tags);
        }
    }
}
