using System;
using System.Collections.Generic;
using System.Net.Mime;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS.Model;
using CloudNative.CloudEvents;
using Cove.Platform.Extensions.Identifiers.DataGeneration;
using ExportZipProcessor.Data.SqsPublisher.Adapters;
using ExportZipProcessor.Data.SqsPublisher.Configuration;
using ExportZipProcessor.Data.SqsPublisher.Constants;
using ExportZipProcessor.Data.SqsPublisher.Exceptions;
using ExportZipProcessor.Data.SqsPublisher.Extensions;
using ExportZipProcessor.Data.SqsPublisher.Logging;
using ExportZipProcessor.Data.SqsPublisher.Models;
using ExportZipProcessor.Domain.EventsPublishing;
using ExportZipProcessor.Domain.Metrics;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.SqsPublisher;

internal class ResultEventsSqsPublisher : IResultEventsPublisher
{
    private readonly IAmazonSqsPublishingAdapter _amazonSqsPublishing;
    private readonly IIdGenerator _idGenerator;
    private readonly IMetricsService _metricsService;
    private readonly TimeProvider _timeProvider;
    private readonly EventsPublishingOptions _options;
    private readonly ILogger<ResultEventsSqsPublisher> _logger;

    public ResultEventsSqsPublisher(
        IAmazonSqsPublishingAdapter amazonSqsPublishing,
        IIdGenerator idGenerator,
        IMetricsService metricsService,
        TimeProvider timeProvider,
        EventsPublishingOptions options,
        ILogger<ResultEventsSqsPublisher> logger)
    {
        _amazonSqsPublishing = amazonSqsPublishing;
        _idGenerator = idGenerator;
        _metricsService = metricsService;
        _timeProvider = timeProvider;
        _options = options;
        _logger = logger;
    }

    public async Task PublishCompletedEventAsync(string exportId, string fileId, CancellationToken cancellationToken)
    {
        var payload = new ResultEventPayload
        {
            Id = exportId,
            State = ExportResultState.Completed,
            ResultDetails = JsonSerializer.SerializeToNode(new Dictionary<string, string>
            {
                { ResultDetailsFieldNames.FileId, fileId }
            })
        };

        await PublishEventAsync(payload, cancellationToken);
    }

    public async Task PublishFailedEventAsync(string exportId, string errorMessage, CancellationToken cancellationToken)
    {
        var payload = new ResultEventPayload
        {
            Id = exportId,
            State = ExportResultState.Failed,
            ResultDetails = JsonSerializer.SerializeToNode(new Dictionary<string, string>
            {
                { ResultDetailsFieldNames.ErrorMessage, errorMessage }
            })
        };

        await PublishEventAsync(payload, cancellationToken);
    }

    private async Task PublishEventAsync(ResultEventPayload payload, CancellationToken cancellationToken)
    {
        var publishRequest = CreateRequest(payload);

        try
        {
            await _amazonSqsPublishing.SendMessageAsync(publishRequest, cancellationToken);

            _metricsService.IncreaseNumberOfResultEventsPublished(MetricLabelValues.Result.Published, payload.State);
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogSqsPublishingFailure(payload.Id, e.Message);

            _metricsService.IncreaseNumberOfResultEventsPublished(MetricLabelValues.Result.Failed, payload.State);

            throw new SqsPublishingException(payload.Id, e);
        }
    }

    private SendMessageRequest CreateRequest(ResultEventPayload payload)
    {
        var cloudEvent = new CloudEvent(CloudEventsSpecVersion.V1_0)
        {
            Id = _idGenerator.GenerateId(),
            Type = ExportResultEventTypes.ZipGenerationResult,
            Source = EventSources.ExportZipProcessor,
            Time = _timeProvider.GetUtcNow(),
            DataContentType = MediaTypeNames.Application.Json,
            Data = payload
        };

        var publishRequest = new SendMessageRequest
        {
            QueueUrl = _options.QueueUrl,
            MessageBody = cloudEvent.EncodeToJsonString(),
            MessageGroupId = payload.Id,
            MessageDeduplicationId = $"{payload.Id}-{payload.State}"
        };

        return publishRequest;
    }
}
