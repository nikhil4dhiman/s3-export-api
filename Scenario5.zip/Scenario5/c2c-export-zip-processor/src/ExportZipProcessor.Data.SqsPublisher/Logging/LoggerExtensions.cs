using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.SqsPublisher.Logging;

internal static partial class LoggerExtensions
{
    [LoggerMessage(
        Level = LogLevel.Error,
        Message = "Publishing to Amazon SQS failed. Export ID: {ExportId}, Error: {ErrorMessage}")]
    public static partial void LogSqsPublishingFailure(
        this ILogger<ResultEventsSqsPublisher> logger,
        string exportId,
        string errorMessage);
}
