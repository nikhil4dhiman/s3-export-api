using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace ExportZipProcessor.Data.SqsPublisher.Models;

internal class ResultEventPayload
{
    [JsonPropertyName("id")]
    public required string Id { get; init; }

    [JsonPropertyName("state")]
    public required string State { get; init; }

    [JsonPropertyName("resultDetails")]
    public JsonNode? ResultDetails { get; init; }
}
