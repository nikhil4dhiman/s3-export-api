using System;
using Amazon.SQS;
using Cove.Platform.Extensions.Configuration;
using Cove.Platform.Extensions.Identifiers;
using ExportZipProcessor.Data.SqsPublisher.Adapters;
using ExportZipProcessor.Data.SqsPublisher.Configuration;
using ExportZipProcessor.Domain.EventsPublishing;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace ExportZipProcessor.Data.SqsPublisher;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddEventsPublishingServices()
        {
            services.TryAddSingleton<IAmazonSQS>(_ => new AmazonSQSClient());

            return services
                .AddIdGenerator()
                .AddOptionsAndValidate<EventsPublishingOptions>()
                .AddSingleton(TimeProvider.System)
                .AddScoped<IAmazonSqsPublishingAdapter, AmazonSqsPublishingAdapter>()
                .AddScoped<IResultEventsPublisher, ResultEventsSqsPublisher>();
        }
    }
}
