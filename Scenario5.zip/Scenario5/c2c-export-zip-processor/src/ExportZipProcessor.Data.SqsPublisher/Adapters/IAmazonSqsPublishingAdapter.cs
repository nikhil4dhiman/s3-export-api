using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS.Model;

namespace ExportZipProcessor.Data.SqsPublisher.Adapters;

public interface IAmazonSqsPublishingAdapter
{
    Task<SendMessageResponse> SendMessageAsync(SendMessageRequest request, CancellationToken cancellationToken);
}
