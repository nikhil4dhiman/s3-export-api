using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS;
using Amazon.SQS.Model;

namespace ExportZipProcessor.Data.SqsPublisher.Adapters;

internal class AmazonSqsPublishingAdapter : IAmazonSqsPublishingAdapter
{
    private readonly IAmazonSQS _amazonSqs;

    public AmazonSqsPublishingAdapter(IAmazonSQS amazonSqs)
    {
        _amazonSqs = amazonSqs;
    }

    public async Task<SendMessageResponse> SendMessageAsync(
        SendMessageRequest request,
        CancellationToken cancellationToken)
    {
        return await _amazonSqs.SendMessageAsync(request, cancellationToken);
    }
}
