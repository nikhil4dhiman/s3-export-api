using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.ApplicationServices.Logging;
using ExportZipProcessor.Domain.ApiClients;
using ExportZipProcessor.Domain.EventsPublishing;
using ExportZipProcessor.Domain.Exceptions;
using ExportZipProcessor.Domain.Helpers;
using ExportZipProcessor.Domain.Metrics;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Domain.Storage;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.ApplicationServices;

public class ZipGenerationService
{
    private readonly IDownloadsProxyApiClient _downloadsProxyApiClient;
    private readonly IStagedFilesStorage _stagedFilesStorage;
    private readonly IZipArchiveWriter _zipArchiveWriter;
    private readonly IResultEventsPublisher _resultEventsPublisher;
    private readonly IMetricsService _metricsService;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<ZipGenerationService> _logger;

    public ZipGenerationService(
        IDownloadsProxyApiClient downloadsProxyApiClient,
        IStagedFilesStorage stagedFilesStorage,
        IZipArchiveWriter zipArchiveWriter,
        IResultEventsPublisher resultEventsPublisher,
        IMetricsService metricsService,
        TimeProvider timeProvider,
        ILogger<ZipGenerationService> logger)
    {
        _downloadsProxyApiClient = downloadsProxyApiClient;
        _stagedFilesStorage = stagedFilesStorage;
        _zipArchiveWriter = zipArchiveWriter;
        _resultEventsPublisher = resultEventsPublisher;
        _metricsService = metricsService;
        _timeProvider = timeProvider;
        _logger = logger;
    }

    public async Task ProcessZipGeneration(ZipGenerationInfo zipGenerationInfo, CancellationToken cancellationToken)
    {
        var stagingPrefix = ZipFileHelper.BuildStagingPrefix(zipGenerationInfo.ExportId);
        var zipFileName = ZipFileHelper.BuildZipFileName(zipGenerationInfo);
        var zipFileKey = ZipFileHelper.BuildZipFileKey(zipGenerationInfo.ExportId, zipFileName);

        try
        {
            var stagedFiles = await _stagedFilesStorage.ListStagedFilesAsync(stagingPrefix, cancellationToken);

            // A redelivered message may arrive after a previous attempt already built the
            // archive (or even cleaned the staging area up); reuse that archive instead of
            // spending hours regenerating it.
            var s3Url = await _zipArchiveWriter.FindExistingArchiveAsync(stagedFiles, zipFileKey, cancellationToken);

            s3Url ??= await GenerateArchiveAsync(stagedFiles, zipFileKey, cancellationToken);

            var fileId = await _downloadsProxyApiClient.CreateFileAssociationAsync(
                s3Url,
                zipFileName,
                zipGenerationInfo,
                cancellationToken);

            if (stagedFiles.Count > 0)
            {
                await DeleteStagedFilesAsync(stagedFiles, zipGenerationInfo, cancellationToken);
            }

            await _resultEventsPublisher.PublishCompletedEventAsync(
                zipGenerationInfo.ExportId,
                fileId,
                cancellationToken);
        }
        catch (EventPublishingException e)
        {
            // ZIP generation itself succeeded; only publishing the completed event failed.
            // Publishing a Failed result event here would incorrectly mark the export as failed.
            _logger.LogZipGenerationTaskEventHandlingError(zipGenerationInfo, e);

            throw;
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogZipGenerationTaskEventHandlingError(zipGenerationInfo, e);

            await _resultEventsPublisher.PublishFailedEventAsync(
                zipGenerationInfo.ExportId,
                e.Message,
                cancellationToken);

            throw;
        }
    }

    /// <summary>
    /// Writes the archive while recording how long it took and how much it compressed. Only
    /// this path is measured: a reused archive did no generation work on this attempt, and
    /// observing it again would count the same export twice and skew every histogram.
    /// </summary>
    private async Task<Uri> GenerateArchiveAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        string zipFileKey,
        CancellationToken cancellationToken)
    {
        var startedAt = _timeProvider.GetTimestamp();

        try
        {
            var archive = await _zipArchiveWriter.WriteAsync(stagedFiles, zipFileKey, cancellationToken);

            _metricsService.ObserveZipGenerationDuration(
                MetricLabelValues.Result.Processed,
                _timeProvider.GetElapsedTime(startedAt).TotalSeconds);

            // Paired with the archive size, this is what makes the compression ratio
            // derivable in Grafana, so both have to be observed for the same set of exports.
            _metricsService.ObserveStagedFilesSize(stagedFiles.Sum(f => f.Size));
            _metricsService.ObserveZipArchiveSize(archive.SizeInBytes);

            return archive.Location;
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _metricsService.ObserveZipGenerationDuration(
                MetricLabelValues.Result.Failed,
                _timeProvider.GetElapsedTime(startedAt).TotalSeconds);

            throw;
        }
    }

    /// <summary>
    /// The zip has already been delivered at this point, so a cleanup failure
    /// must not fail the message; leftover staged files are removed by the bucket lifecycle policy.
    /// </summary>
    private async Task DeleteStagedFilesAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        ZipGenerationInfo zipGenerationInfo,
        CancellationToken cancellationToken)
    {
        try
        {
            await _stagedFilesStorage.DeleteStagedFilesAsync(stagedFiles, cancellationToken);
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogStagedFilesCleanupFailed(zipGenerationInfo, e);
        }
    }
}
