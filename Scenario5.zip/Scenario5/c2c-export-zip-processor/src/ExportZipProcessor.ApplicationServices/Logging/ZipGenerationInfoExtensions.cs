using System.Collections.Generic;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.ApplicationServices.Logging;

public static class ZipGenerationInfoExtensions
{
    public static Dictionary<string, object?> ToLoggingScope(this ZipGenerationInfo zipGenerationInfo)
    {
        return new Dictionary<string, object?>
        {
            [nameof(ZipGenerationInfo.ExportId)] = zipGenerationInfo.ExportId,
            [nameof(ZipGenerationInfo.PartnerId)] = zipGenerationInfo.PartnerId
        };
    }
}
