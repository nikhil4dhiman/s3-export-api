using System;
using System.Collections.Generic;
using ExportZipProcessor.Domain.Models;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.ApplicationServices.Logging;

internal static partial class LoggerExtensions
{
    public static void LogZipGenerationTaskEventHandlingError(
        this ILogger<ZipGenerationService> logger,
        ZipGenerationInfo zipGenerationInfo,
        Exception exception)
    {
        var scope = new Dictionary<string, object?>
        {
            [nameof(ZipGenerationInfo)] = zipGenerationInfo.ToLoggingScope()
        };

        using var _ = logger.BeginScope(scope);

        logger.LogZipGenerationTaskEventHandlingError(exception);
    }

    public static void LogStagedFilesCleanupFailed(
        this ILogger<ZipGenerationService> logger,
        ZipGenerationInfo zipGenerationInfo,
        Exception exception)
    {
        var scope = new Dictionary<string, object?>
        {
            [nameof(ZipGenerationInfo)] = zipGenerationInfo.ToLoggingScope()
        };

        using var _ = logger.BeginScope(scope);

        logger.LogStagedFilesCleanupFailed(exception);
    }

    [LoggerMessage(
        Level = LogLevel.Error,
        Message = "An unexpected error occurred while handling zip generation task event")]
    private static partial void LogZipGenerationTaskEventHandlingError(
        this ILogger<ZipGenerationService> logger,
        Exception exception);

    [LoggerMessage(
        Level = LogLevel.Warning,
        Message = "Failed to delete staged files after zip delivery; relying on bucket lifecycle policy for cleanup")]
    private static partial void LogStagedFilesCleanupFailed(
        this ILogger<ZipGenerationService> logger,
        Exception exception);
}
