using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.ApplicationServices;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddApplicationServices()
        {
            return services.AddScoped<ZipGenerationService>();
        }
    }
}
