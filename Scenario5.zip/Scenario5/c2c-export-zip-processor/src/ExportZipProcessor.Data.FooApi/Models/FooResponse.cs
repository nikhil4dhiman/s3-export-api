namespace ExportZipProcessor.Data.FooApi.Models;

internal class FooResponse
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;
}
