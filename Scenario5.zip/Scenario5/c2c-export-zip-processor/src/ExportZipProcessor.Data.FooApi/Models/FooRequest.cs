namespace ExportZipProcessor.Data.FooApi.Models;

internal class FooRequest
{
    public string Name { get; set; } = null!;
}
