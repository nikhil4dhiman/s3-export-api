using System;
using Cove.Platform.Extensions.ApiClients;
using Cove.Platform.Extensions.Communication.Constants.Http;
using Cove.Platform.Extensions.Configuration;
using ExportZipProcessor.Data.FooApi.Api;
using ExportZipProcessor.Data.FooApi.Configuration;
using ExportZipProcessor.Domain.ApiClients;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.Data.FooApi;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddFooApiServices()
        {
            return services
                .AddFooApiClient()
                .AddOptionsAndValidate<FooApiOptions>()
                .AddScoped<IFooApiClient, FooApiClient>();
        }

        private IServiceCollection AddFooApiClient()
        {
            services
                .AddApiClientFor(FooApiClientDefaults.ApiClientName)
                .ConfigureOptions((options, sp) =>
                {
                    var fooApiOptions = sp.GetRequiredService<FooApiOptions>();

                    options.BaseUrl = fooApiOptions.BaseUrl;
                    options.TotalRequestTimeout = TimeSpan.FromSeconds(fooApiOptions.TimeoutInSeconds);
                })
                .ConfigureForwardedHeadersOptions(options =>
                {
                    options.Headers.Add(KnownHttpHeaders.UserId);
                });

            return services;
        }
    }
}
