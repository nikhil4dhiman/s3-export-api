namespace ExportZipProcessor.Data.FooApi;

internal static class FooApiClientDefaults
{
    public const string ApiClientName = "FooApi";
}
