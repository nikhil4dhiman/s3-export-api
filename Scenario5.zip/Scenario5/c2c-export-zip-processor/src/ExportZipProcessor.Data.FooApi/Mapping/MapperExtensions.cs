using ExportZipProcessor.Data.FooApi.Models;
using ExportZipProcessor.Domain.Models;
using Riok.Mapperly.Abstractions;

namespace ExportZipProcessor.Data.FooApi.Mapping;

[Mapper(RequiredMappingStrategy = RequiredMappingStrategy.Target)]
internal static partial class MapperExtensions
{
    public static partial FooRequest ToRequestModel(this FooInfo source);
}
