using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ApiClients.Api;
using ExportZipProcessor.Data.FooApi.Mapping;
using ExportZipProcessor.Data.FooApi.Models;
using ExportZipProcessor.Domain.ApiClients;
using ExportZipProcessor.Domain.Models;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.Data.FooApi.Api;

internal class FooApiClient : IFooApiClient
{
    private readonly IApiClient _apiClient;

    public FooApiClient([FromKeyedServices(FooApiClientDefaults.ApiClientName)] IApiClient apiClient)
    {
        _apiClient = apiClient;
    }

    public async Task<string> PostAsync(FooInfo fooInfo, CancellationToken cancellationToken)
    {
        var request = fooInfo.ToRequestModel();

        var response = await _apiClient.PostAsync<FooRequest, FooResponse>(
            "foo",
            request,
            cancellationToken);

        return response.Id;
    }
}
