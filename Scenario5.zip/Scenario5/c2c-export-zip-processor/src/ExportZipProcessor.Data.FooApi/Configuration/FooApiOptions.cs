using System;
using System.ComponentModel.DataAnnotations;

namespace ExportZipProcessor.Data.FooApi.Configuration;

public class FooApiOptions
{
    [Required]
    public Uri BaseUrl { get; set; } = null!;

    [Range(1, 600)]
    public int TimeoutInSeconds { get; set; }
}
