using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.Data.S3.HealthChecks;

public static class HealthChecksServiceCollectionExtensions
{
    extension(IHealthChecksBuilder healthChecksBuilder)
    {
        public IHealthChecksBuilder AddAmazonS3BucketHealthCheck(params string[] tags)
        {
            return healthChecksBuilder.AddCheck<AmazonS3BucketHealthCheck>(
                "S3 bucket is available for consuming",
                tags: tags);
        }
    }
}
