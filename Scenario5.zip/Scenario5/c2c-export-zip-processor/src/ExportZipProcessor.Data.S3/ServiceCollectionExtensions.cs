using Amazon.Runtime;
using Amazon.S3;
using Cove.Platform.Extensions.Configuration;
using ExportZipProcessor.Data.S3.Configuration;
using ExportZipProcessor.Data.S3.Storage;
using ExportZipProcessor.Domain.Storage;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace ExportZipProcessor.Data.S3;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddS3Services()
        {
            services.TryAddSingleton<IAmazonS3>(_ => new AmazonS3Client(new AmazonS3Config
            {
                // The SDK's default flexible checksums CRC every uploaded part and every
                // downloaded body — two extra full passes over the export on a pod capped
                // at one core. Transport integrity is already covered by TLS and every zip
                // entry carries its own CRC32, so opt out unless the operation requires it.
                RequestChecksumCalculation = RequestChecksumCalculation.WHEN_REQUIRED,
                ResponseChecksumValidation = ResponseChecksumValidation.WHEN_REQUIRED
            }));

            return services
                .AddOptionsAndValidate<ZipStorageOptions>()
                .AddScoped<IStagedFilesStorage, StagedFilesStorage>()
                .AddScoped<StagedFileDownloader>()
                .AddScoped<IZipArchiveWriter, ZipArchiveWriter>();
        }
    }
}
