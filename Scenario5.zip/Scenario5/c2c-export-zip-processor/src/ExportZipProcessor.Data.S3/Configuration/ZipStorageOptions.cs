using System.ComponentModel.DataAnnotations;

namespace ExportZipProcessor.Data.S3.Configuration;

public class ZipStorageOptions
{
    [Required]
    public required string BucketName { get; init; }

    // 5 MB is the S3 minimum part size; the upper bound matches the derived-part-size cap
    // (ZipStorageConstants.MaxPartSizeBytes), which the pod's memory limit is sized for.
    [Range(5, 128)]
    public required int PartSizeInMegabytes { get; init; }

    [Range(1, 10)]
    public required int MaxDownloadAttempts { get; init; }

    [Range(1, 1000)]
    public required int ProgressLogPartInterval { get; init; }

    [Range(1, 1000)]
    public required int DeleteBatchSize { get; init; }
}
