using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using ExportZipProcessor.Data.S3.Configuration;
using ExportZipProcessor.Data.S3.Logging;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Domain.Storage;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.S3.Storage;

/// <summary>
/// Encapsulates operations against the staging area of the export bucket:
/// listing staged files and deleting them after processing.
/// </summary>
internal class StagedFilesStorage : IStagedFilesStorage
{
    private readonly IAmazonS3 _s3Client;
    private readonly ZipStorageOptions _options;
    private readonly ILogger<StagedFilesStorage> _logger;

    public StagedFilesStorage(
        IAmazonS3 s3Client,
        ZipStorageOptions options,
        ILogger<StagedFilesStorage> logger)
    {
        _s3Client = s3Client;
        _options = options;
        _logger = logger;
    }

    public async Task<IReadOnlyList<StagedFile>> ListStagedFilesAsync(
        string stagingPrefix,
        CancellationToken cancellationToken)
    {
        var stagedFiles = new List<StagedFile>();

        var request = new ListObjectsV2Request
        {
            BucketName = _options.BucketName,
            Prefix = stagingPrefix
        };

        ListObjectsV2Response response;

        do
        {
            response = await _s3Client.ListObjectsV2Async(request, cancellationToken);

            if (response.S3Objects is not null)
            {
                // Folder markers are excluded by key shape rather than by size, so that
                // legitimately empty staged files still make it into the archive.
                stagedFiles.AddRange(response.S3Objects
                    .Where(o => !o.Key.EndsWith('/'))
                    .Select(o => new StagedFile(o.Key, o.Size ?? 0, o.Key[stagingPrefix.Length..])));
            }

            request.ContinuationToken = response.NextContinuationToken;
        }
        while (response.IsTruncated == true);

        _logger.LogStagedFilesListed(stagedFiles.Count, stagedFiles.Sum(o => o.Size));

        return stagedFiles;
    }

    public async Task DeleteStagedFilesAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        CancellationToken cancellationToken)
    {
        foreach (var chunk in stagedFiles.Chunk(_options.DeleteBatchSize))
        {
            await _s3Client.DeleteObjectsAsync(
                new DeleteObjectsRequest
                {
                    BucketName = _options.BucketName,
                    Objects = [.. chunk.Select(o => new KeyVersion { Key = o.Key })]
                },
                cancellationToken);
        }

        _logger.LogStagedFilesDeleted(stagedFiles.Count);
    }
}
