using System;
using System.IO;
using System.Net;
using System.Net.Http;
using System.Net.Sockets;
using System.Threading.Tasks;
using Amazon.Runtime;

namespace ExportZipProcessor.Data.S3.Storage;

/// <summary>
/// Classifies failures of S3 operations as transient (worth retrying) or permanent.
/// Transient failures cover network faults, timeouts, throttling and S3 server errors;
/// everything else (access denied, missing bucket, precondition failures, bugs) is permanent.
/// </summary>
internal static class S3TransientErrors
{
    public static bool IsTransient(Exception exception)
    {
        for (var current = exception; current is not null; current = current.InnerException)
        {
            switch (current)
            {
                case AmazonServiceException serviceException:
                    return IsTransient(serviceException);

                // TaskCanceledException outside of caller cancellation is an HTTP client
                // timeout; callers handle caller cancellation before consulting this class.
                case IOException or SocketException or HttpRequestException
                    or TimeoutException or TaskCanceledException:
                    return true;
            }
        }

        return false;
    }

    private static bool IsTransient(AmazonServiceException exception)
    {
        return exception.Retryable is not null
               || exception.StatusCode is HttpStatusCode.RequestTimeout or HttpStatusCode.TooManyRequests
               || (int)exception.StatusCode >= 500;
    }
}
