using System;
using System.Collections.Generic;
using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Data.S3.Storage;

/// <summary>
/// A fixed-size fingerprint of the staging set (every key with its size, in listing
/// order), so an existing archive is only reused when it was built from exactly the same
/// files. S3 user metadata is limited to 2 KB, hence a hash rather than the file list.
/// </summary>
internal static class StagingSetFingerprint
{
    /// <summary>
    /// The hashed byte layout (key, newline, decimal size, newline, per file) is a
    /// persisted contract: archives already in S3 carry fingerprints of this exact shape,
    /// and changing it would make every redelivered message regenerate its archive.
    /// </summary>
    public static string Compute(IReadOnlyList<StagedFile> stagedFiles)
    {
        using var hash = IncrementalHash.CreateHash(HashAlgorithmName.SHA256);

        foreach (var stagedFile in stagedFiles)
        {
            AppendLine(hash, stagedFile.Key);
            AppendLine(hash, stagedFile.Size.ToString(CultureInfo.InvariantCulture));
        }

        return Convert.ToHexString(hash.GetHashAndReset());
    }

    private static void AppendLine(IncrementalHash hash, string value)
    {
        hash.AppendData(Encoding.UTF8.GetBytes(value));
        hash.AppendData("\n"u8);
    }
}
