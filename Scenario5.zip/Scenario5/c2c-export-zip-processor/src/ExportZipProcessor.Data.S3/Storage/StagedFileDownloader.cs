using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using ExportZipProcessor.Data.S3.Configuration;
using ExportZipProcessor.Data.S3.Logging;
using ExportZipProcessor.Domain.Exceptions;
using ExportZipProcessor.Domain.Models;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.S3.Storage;

/// <summary>
/// Streams staged files out of the export bucket into a destination stream. A transient
/// mid-body failure is resumed with a ranged GET from the last fully written byte; the ETag
/// pins the object version so the resumed range is consistent with what was already written.
/// Also supports prefetching the next file's GET so its first-byte latency is hidden behind
/// the current file's processing.
/// </summary>
internal class StagedFileDownloader
{
    private readonly IAmazonS3 _s3Client;
    private readonly ZipStorageOptions _options;
    private readonly ILogger<StagedFileDownloader> _logger;

    public StagedFileDownloader(
        IAmazonS3 s3Client,
        ZipStorageOptions options,
        ILogger<StagedFileDownloader> logger)
    {
        _s3Client = s3Client;
        _options = options;
        _logger = logger;
    }

    /// <summary>
    /// Starts a staged file's GET without consuming the body, so the request is in flight
    /// while the previous file is still being processed; memory stays flat because nothing
    /// is buffered. Returns null for empty files, which have no body worth a request.
    /// </summary>
    public Task<GetObjectResponse>? StartPrefetch(StagedFile stagedFile, CancellationToken cancellationToken)
    {
        return stagedFile.Size > 0
            ? _s3Client.GetObjectAsync(BuildGetRequest(stagedFile), cancellationToken)
            : null;
    }

    public async Task DownloadAsync(
        StagedFile stagedFile,
        Stream destination,
        byte[] copyBuffer,
        Task<GetObjectResponse>? prefetchedResponse,
        CancellationToken cancellationToken)
    {
        if (stagedFile.Size == 0)
        {
            await DisposePrefetchAsync(prefetchedResponse);

            return;
        }

        var bytesWritten = 0L;
        string? etag = null;
        var attempt = 0;

        while (true)
        {
            attempt++;

            // Only failures of the S3 read side may be retried here. A failure thrown while
            // writing to the destination (typically a failed part upload surfacing through
            // the zip entry stream) must propagate immediately: the destination may already
            // hold a compressed prefix of the current chunk, so re-sending those bytes on a
            // retry would corrupt the archive, and re-reading from S3 cannot fix an upload.
            var writingToDestination = false;

            try
            {
                GetObjectResponse response;

                // The prefetched GET is only valid for a fresh first attempt; retries need a
                // ranged, ETag-pinned request built from the resume state.
                if (prefetchedResponse is not null)
                {
                    // Clear before awaiting so a faulted prefetch is retried with a fresh
                    // request rather than re-awaiting the same failed task.
                    var pending = prefetchedResponse;
                    prefetchedResponse = null;
                    response = await pending;
                }
                else
                {
                    var request = BuildGetRequest(stagedFile);

                    request.EtagToMatch = etag;

                    if (bytesWritten > 0)
                    {
                        request.ByteRange = new ByteRange(bytesWritten, stagedFile.Size - 1);
                    }

                    response = await _s3Client.GetObjectAsync(request, cancellationToken);
                }

                using (response)
                {
                    etag ??= response.ETag;

                    int bytesRead;

                    while ((bytesRead = await response.ResponseStream.ReadAsync(copyBuffer, cancellationToken)) > 0)
                    {
                        writingToDestination = true;
                        await destination.WriteAsync(copyBuffer.AsMemory(0, bytesRead), cancellationToken);
                        writingToDestination = false;

                        bytesWritten += bytesRead;
                    }
                }

                if (bytesWritten != stagedFile.Size)
                {
                    throw new ZipGenerationException(
                        $"Staged file {stagedFile.Key} returned {bytesWritten} bytes "
                        + $"but was listed with size {stagedFile.Size}");
                }

                return;
            }
            catch (Exception e) when (
                !writingToDestination
                && attempt < _options.MaxDownloadAttempts
                && !cancellationToken.IsCancellationRequested
                && S3TransientErrors.IsTransient(e))
            {
                _logger.LogStagedFileDownloadRetrying(stagedFile.Key, attempt, _options.MaxDownloadAttempts, e);

                await Task.Delay(
                    ZipStorageConstants.DownloadRetryBaseDelay * (1 << (attempt - 1)),
                    cancellationToken);
            }
        }
    }

    /// <summary>
    /// A prefetch left in flight (on a failure path or for an empty file) must still be
    /// observed and disposed so its response stream is released and no
    /// UnobservedTaskException is raised.
    /// </summary>
    public async Task DisposePrefetchAsync(Task<GetObjectResponse>? prefetchedResponse)
    {
        if (prefetchedResponse is null)
        {
            return;
        }

        try
        {
            (await prefetchedResponse).Dispose();
        }
#pragma warning disable CA1031 // cleanup must not mask the propagating root cause
        catch (Exception e)
        {
            _logger.LogStagedFilePrefetchDisposeFailed(e);
        }
#pragma warning restore CA1031
    }

    private GetObjectRequest BuildGetRequest(StagedFile stagedFile)
    {
        return new GetObjectRequest
        {
            BucketName = _options.BucketName,
            Key = stagedFile.Key
        };
    }
}
