using System;
using System.Collections.Frozen;
using ExportZipProcessor.Domain.Constants;

namespace ExportZipProcessor.Data.S3.Storage;

/// <summary>
/// Fixed constants of the zip storage layer. These are protocol facts and implementation
/// details rather than tuning knobs; operational settings live in
/// <see cref="Configuration.ZipStorageOptions"/>.
/// </summary>
internal static class ZipStorageConstants
{
    /// <summary>Buffer size used when copying an S3 response stream into a zip entry.</summary>
    public const int CopyBufferSize = SizeConstants.OneMegabyte;

    /// <summary>
    /// Upper bound for the derived part size. Two part buffers of this size (plus runtime
    /// overhead) must fit the pod's 1 GiB memory limit.
    /// </summary>
    public const long MaxPartSizeBytes = 128L * SizeConstants.OneMegabyte;

    /// <summary>Headroom below the hard S3 limit of 10,000 parts per multipart upload.</summary>
    public const int TargetMaxPartCount = 9_000;

    /// <summary>
    /// Per-entry archive overhead (local + central directory headers, data descriptor,
    /// zip64 extra fields) used when overestimating the archive size.
    /// </summary>
    public const int ZipEntryOverheadBytes = 1_024;

    /// <summary>Metadata key holding the fingerprint of the staging set an archive was built from.</summary>
    public const string StagingSetHashMetadataKey = "staging-set-hash";

    /// <summary>Base delay for the exponential backoff between staged file download attempts.</summary>
    public static readonly TimeSpan DownloadRetryBaseDelay = TimeSpan.FromSeconds(1);

    /// <summary>
    /// File extensions whose content is already compressed (or encrypted), where deflate
    /// spends CPU for a negligible size reduction; such entries are stored uncompressed.
    /// </summary>
    public static readonly FrozenSet<string> IncompressibleExtensions = new[]
    {
        // archives
        ".zip", ".gz", ".tgz", ".bz2", ".xz", ".7z", ".rar", ".zst", ".br", ".lz4",
        // images
        ".jpg", ".jpeg", ".png", ".gif", ".webp", ".heic", ".heif", ".avif",
        // audio / video
        ".mp3", ".aac", ".m4a", ".ogg", ".opus", ".flac",
        ".mp4", ".m4v", ".mkv", ".webm", ".mov", ".avi", ".wmv",
        // office (zip containers)
        ".docx", ".xlsx", ".pptx", ".odt", ".ods", ".odp",
        // misc
        ".pdf", ".apk", ".jar", ".epub",
    }.ToFrozenSet(StringComparer.OrdinalIgnoreCase);
}
