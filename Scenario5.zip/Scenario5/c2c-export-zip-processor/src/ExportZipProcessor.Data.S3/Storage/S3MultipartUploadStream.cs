using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using ExportZipProcessor.Data.S3.Logging;
using ExportZipProcessor.Domain.Exceptions;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.S3.Storage;

/// <summary>
/// A write-only stream that buffers writes into fixed-size parts and uploads each full part
/// to S3 via the multipart upload API. Double-buffered: one part uploads on a background task
/// while the next part fills, overlapping CPU (zip compression) with network I/O. The two part
/// buffers live for the whole upload, so they are plain arrays rather than pooled ones.
/// </summary>
internal sealed class S3MultipartUploadStream : Stream
{
    private const int MaxPartCount = 10_000; // hard S3 limit per multipart upload

    private readonly IAmazonS3 _s3Client;
    private readonly string _bucketName;
    private readonly string _key;
    private readonly string _uploadId;
    private readonly int _partSize;
    private readonly int _progressLogPartInterval;
    private readonly ILogger _logger;
    private readonly List<PartETag> _partETags = [];

    private readonly byte[]?[] _buffers;
    private int _currentBufferIndex;
    private int _currentBufferPosition;
    private Task<UploadPartResponse>? _pendingUpload;
    private int _pendingUploadPartNumber;
    private long _length;

    public S3MultipartUploadStream(
        IAmazonS3 s3Client,
        string bucketName,
        string key,
        string uploadId,
        int partSize,
        int progressLogPartInterval,
        ILogger logger)
    {
        _s3Client = s3Client;
        _bucketName = bucketName;
        _key = key;
        _uploadId = uploadId;
        _partSize = partSize;
        _progressLogPartInterval = progressLogPartInterval;
        _logger = logger;
        // The second buffer is only allocated if the archive grows beyond one part.
        _buffers = new byte[2][];
        _buffers[0] = new byte[partSize];
    }

    public IReadOnlyList<PartETag> PartETags => _partETags;

    public int PartCount { get; private set; }

    public long BytesUploaded { get; private set; }

    public override bool CanRead => false;

    public override bool CanSeek => false;

    public override bool CanWrite => true;

    public override long Length => _length;

    public override long Position
    {
        get => _length;
        set => throw new NotSupportedException();
    }

    // Only a safety net: all traffic goes through WriteAsync (the archive is written with the
    // async ZipArchive APIs). Blocking a thread-pool thread on an upload is unacceptable on a
    // single-vCPU pod, so keep this path cold.
    public override void Write(byte[] buffer, int offset, int count)
    {
        WriteAsync(buffer.AsMemory(offset, count), CancellationToken.None)
            .AsTask()
            .GetAwaiter()
            .GetResult();
    }

    public override async ValueTask WriteAsync(
        ReadOnlyMemory<byte> buffer,
        CancellationToken cancellationToken = default)
    {
        while (!buffer.IsEmpty)
        {
            var bytesToCopy = Math.Min(buffer.Length, _partSize - _currentBufferPosition);

            buffer[..bytesToCopy].CopyTo(_buffers[_currentBufferIndex].AsMemory(_currentBufferPosition));

            _currentBufferPosition += bytesToCopy;
            _length += bytesToCopy;
            buffer = buffer[bytesToCopy..];

            if (_currentBufferPosition == _partSize)
            {
                await RotateBuffersAndUploadAsync(cancellationToken);
            }
        }
    }

    /// <summary>
    /// Uploads the final (possibly partial) buffered part and awaits all in-flight uploads.
    /// Must be called before completing the multipart upload.
    /// </summary>
    public async Task FlushFinalAsync(CancellationToken cancellationToken)
    {
        await AwaitPendingUploadAsync(cancellationToken);

        if (_currentBufferPosition > 0)
        {
            var partNumber = NextPartNumber();

            var response = await UploadPartAsync(
                _buffers[_currentBufferIndex]!,
                _currentBufferPosition,
                partNumber,
                cancellationToken);

            _partETags.Add(new PartETag(response.PartNumber ?? partNumber, response.ETag));
            BytesUploaded += _currentBufferPosition;
        }
    }

    public override Task FlushAsync(CancellationToken cancellationToken)
    {
        return Task.CompletedTask;
    }

    public override void Flush()
    {
    }

    public override int Read(byte[] buffer, int offset, int count)
    {
        throw new NotSupportedException();
    }

    public override long Seek(long offset, SeekOrigin origin)
    {
        throw new NotSupportedException();
    }

    public override void SetLength(long value)
    {
        throw new NotSupportedException();
    }

    public override async ValueTask DisposeAsync()
    {
        // If the writer failed mid-stream the in-flight part upload is never awaited by
        // FlushFinalAsync, so its exception has to be observed here to avoid tearing the
        // process down via UnobservedTaskException.
        await ObservePendingUploadAsync();

        await base.DisposeAsync();
    }

    private async Task ObservePendingUploadAsync()
    {
        var pendingUpload = _pendingUpload;

        if (pendingUpload is null)
        {
            return;
        }

        _pendingUpload = null;

        try
        {
            await pendingUpload;
        }
#pragma warning disable CA1031 // dispose must never replace the root cause already propagating
        catch (Exception e)
        {
            // The failure that aborted the upload is reported by the caller; any other failure
            // here (SDK, network, timeout) must not escape DisposeAsync and mask it.
            _logger.LogMultipartUploadPartFailedOnDispose(_key, e);
        }
#pragma warning restore CA1031
    }

    private async Task RotateBuffersAndUploadAsync(CancellationToken cancellationToken)
    {
        await AwaitPendingUploadAsync(cancellationToken);

        var fullBuffer = _buffers[_currentBufferIndex]!;

        _currentBufferIndex ^= 1;
        _currentBufferPosition = 0;
        _buffers[_currentBufferIndex] ??= new byte[_partSize];

        var partNumber = NextPartNumber();

        _pendingUploadPartNumber = partNumber;
        _pendingUpload = UploadPartAsync(fullBuffer, _partSize, partNumber, cancellationToken);
    }

    private int NextPartNumber()
    {
        if (PartCount == MaxPartCount)
        {
            throw new ZipGenerationException(
                $"Zip archive for {_key} exceeds the S3 limit of {MaxPartCount} multipart upload parts " +
                $"at a part size of {_partSize} bytes");
        }

        return ++PartCount;
    }

    private async Task AwaitPendingUploadAsync(CancellationToken cancellationToken)
    {
        var pendingUpload = _pendingUpload;

        if (pendingUpload is null)
        {
            return;
        }

        UploadPartResponse response;

        try
        {
            response = await pendingUpload.WaitAsync(cancellationToken);
        }
        catch
        {
            // A failed part upload is fatal for the whole multipart upload, so it must be
            // forgotten here rather than re-awaited (and rethrown) by every later write.
            // It is kept only when the wait itself was cancelled while the upload is still
            // in flight, so that DisposeAsync can observe the eventual outcome.
            if (pendingUpload.IsCompleted)
            {
                _pendingUpload = null;
            }

            throw;
        }

        _pendingUpload = null;
        _partETags.Add(new PartETag(response.PartNumber ?? _pendingUploadPartNumber, response.ETag));

        // Tracked here, on the writer's flow, rather than inside UploadPartAsync where the
        // increment would run on a background continuation and race the reads below.
        // Pending uploads are always full parts; the final short part is counted in
        // FlushFinalAsync.
        BytesUploaded += _partSize;

        // Multi-hour uploads need a heartbeat so operators can tell a slow job from a stuck one.
        if (_partETags.Count % _progressLogPartInterval == 0)
        {
            _logger.LogMultipartUploadProgress(_key, _partETags.Count, BytesUploaded);
        }
    }

    private async Task<UploadPartResponse> UploadPartAsync(
        byte[] buffer,
        int size,
        int partNumber,
        CancellationToken cancellationToken)
    {
        using var partStream = new MemoryStream(buffer, 0, size, writable: false);

        return await _s3Client.UploadPartAsync(
            new UploadPartRequest
            {
                BucketName = _bucketName,
                Key = _key,
                UploadId = _uploadId,
                PartNumber = partNumber,
                PartSize = size,
                InputStream = partStream
            },
            cancellationToken);
    }
}
