using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using ExportZipProcessor.Data.S3.Configuration;
using ExportZipProcessor.Data.S3.Logging;
using ExportZipProcessor.Domain.Constants;
using ExportZipProcessor.Domain.Exceptions;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Domain.Storage;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.S3.Storage;

/// <summary>
/// Builds a zip archive from staged files and streams it directly into the export bucket
/// via an S3 multipart upload, keeping memory usage constant regardless of the total size.
/// Downloading the staged files (with prefetch, retry and resume) is delegated to
/// <see cref="StagedFileDownloader"/>; this class owns the multipart upload lifecycle and
/// the archive structure.
/// </summary>
internal class ZipArchiveWriter : IZipArchiveWriter
{
    private readonly IAmazonS3 _s3Client;
    private readonly ZipStorageOptions _options;
    private readonly StagedFileDownloader _downloader;
    private readonly ILogger<ZipArchiveWriter> _logger;

    public ZipArchiveWriter(
        IAmazonS3 s3Client,
        ZipStorageOptions options,
        StagedFileDownloader downloader,
        ILogger<ZipArchiveWriter> logger)
    {
        _s3Client = s3Client;
        _options = options;
        _downloader = downloader;
        _logger = logger;
    }

    public async Task<Uri?> FindExistingArchiveAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        string zipFileKey,
        CancellationToken cancellationToken)
    {
        GetObjectMetadataResponse metadata;

        try
        {
            metadata = await _s3Client.GetObjectMetadataAsync(
                new GetObjectMetadataRequest
                {
                    BucketName = _options.BucketName,
                    Key = zipFileKey
                },
                cancellationToken);
        }
        catch (AmazonS3Exception e) when (e.StatusCode == HttpStatusCode.NotFound)
        {
            return null;
        }
        catch (Exception e)
        {
            throw new ZipGenerationException(
                $"Failed to check for an existing zip archive at s3://{_options.BucketName}/{zipFileKey}",
                e,
                S3TransientErrors.IsTransient(e));
        }

        // Completing a multipart upload is atomic, so the object existing means a previous
        // attempt finished writing it. Reuse it only when it was built from the same staging
        // set; an empty staging area means a previous attempt already cleaned up after itself.
        if (stagedFiles.Count > 0 && !MatchesStagingSet(metadata, stagedFiles))
        {
            return null;
        }

        _logger.LogExistingZipArchiveReused(zipFileKey);

        return ZipUri(zipFileKey);
    }

    public async Task<ZipArchiveInfo> WriteAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        string zipFileKey,
        CancellationToken cancellationToken)
    {
        var initiateRequest = new InitiateMultipartUploadRequest
        {
            BucketName = _options.BucketName,
            Key = zipFileKey,
            ContentType = "application/zip"
        };

        initiateRequest.Metadata.Add(
            ZipStorageConstants.StagingSetHashMetadataKey,
            StagingSetFingerprint.Compute(stagedFiles));

        var initiateResponse = await _s3Client.InitiateMultipartUploadAsync(initiateRequest, cancellationToken);

        _logger.LogMultipartUploadInitiated(zipFileKey);

        try
        {
            var uploadStream = new S3MultipartUploadStream(
                _s3Client,
                _options.BucketName,
                zipFileKey,
                initiateResponse.UploadId,
                CalculatePartSize(stagedFiles),
                _options.ProgressLogPartInterval,
                _logger);

            await using (uploadStream)
            {
                await WriteZipEntriesAsync(stagedFiles, uploadStream, cancellationToken);

                await uploadStream.FlushFinalAsync(cancellationToken);

                await _s3Client.CompleteMultipartUploadAsync(
                    new CompleteMultipartUploadRequest
                    {
                        BucketName = _options.BucketName,
                        Key = zipFileKey,
                        UploadId = initiateResponse.UploadId,
                        PartETags = [.. uploadStream.PartETags]
                    },
                    cancellationToken);

                _logger.LogMultipartUploadCompleted(zipFileKey, uploadStream.PartCount, uploadStream.BytesUploaded);

                return new ZipArchiveInfo(ZipUri(zipFileKey), uploadStream.BytesUploaded);
            }
        }
        catch (Exception e)
        {
            // Any parts that were already uploaded are orphaned once the upload is abandoned,
            // so always try to abort before letting the failure propagate.
            await AbortMultipartUploadAsync(zipFileKey, initiateResponse.UploadId);

            if (e is OperationCanceledException or ZipGenerationException)
            {
                throw;
            }

            throw new ZipGenerationException(
                $"Failed to write zip archive to s3://{_options.BucketName}/{zipFileKey}",
                e,
                S3TransientErrors.IsTransient(e));
        }
    }

    /// <summary>
    /// Derives the part size from the total staged size so the archive stays below the S3
    /// part-count limit no matter how large the export is; the configured value is the floor.
    /// </summary>
    private int CalculatePartSize(IReadOnlyList<StagedFile> stagedFiles)
    {
        // Deflate can slightly expand incompressible input and every entry adds header
        // overhead, so overestimate the archive size before dividing by the part budget.
        var estimatedArchiveBytes =
            stagedFiles.Sum(f => f.Size)
            + ((long)stagedFiles.Count * ZipStorageConstants.ZipEntryOverheadBytes);
        estimatedArchiveBytes += estimatedArchiveBytes / 100;

        var requiredPartSize =
            (estimatedArchiveBytes + ZipStorageConstants.TargetMaxPartCount - 1)
            / ZipStorageConstants.TargetMaxPartCount;
        var partSize = Math.Max(
            (long)_options.PartSizeInMegabytes * SizeConstants.OneMegabyte,
            requiredPartSize);

        // Round up to whole megabytes. The cap bounds the two in-memory part buffers so they
        // fit a 1 GiB pod with headroom for the runtime; at 9,000 parts it still allows
        // archives of roughly 1.1 TB before the runtime part-count guard trips.
        partSize = (partSize + SizeConstants.OneMegabyte - 1)
                   / SizeConstants.OneMegabyte
                   * SizeConstants.OneMegabyte;

        return (int)Math.Min(partSize, ZipStorageConstants.MaxPartSizeBytes);
    }

    private static bool MatchesStagingSet(
        GetObjectMetadataResponse metadata,
        IReadOnlyList<StagedFile> stagedFiles)
    {
        return metadata.Metadata[ZipStorageConstants.StagingSetHashMetadataKey]
               == StagingSetFingerprint.Compute(stagedFiles);
    }

    private Uri ZipUri(string zipFileKey)
    {
        return new Uri($"s3://{_options.BucketName}/{zipFileKey}");
    }

    private async Task WriteZipEntriesAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        S3MultipartUploadStream uploadStream,
        CancellationToken cancellationToken)
    {
        // The archive is always disposed in the finally block below; the non-standard shape
        // exists so a dispose failure cannot replace an exception already propagating.
#pragma warning disable CA2000
        var zipArchive = new ZipArchive(uploadStream, ZipArchiveMode.Create, leaveOpen: true);
#pragma warning restore CA2000
        var copyBuffer = new byte[ZipStorageConstants.CopyBufferSize];
        Exception? failure = null;
        Task<GetObjectResponse>? prefetchedResponse = null;

        try
        {
            for (var i = 0; i < stagedFiles.Count; i++)
            {
                var stagedFile = stagedFiles[i];
                var currentResponse = prefetchedResponse;

                // Start the next file's GET while the current entry is compressed and
                // uploaded, hiding the S3 first-byte latency between entries.
                prefetchedResponse = i + 1 < stagedFiles.Count
                    ? _downloader.StartPrefetch(stagedFiles[i + 1], cancellationToken)
                    : null;

                var entry = zipArchive.CreateEntry(stagedFile.EntryName, GetCompressionLevel(stagedFile.EntryName));
                var entryStream = await entry.OpenAsync(cancellationToken);

                await using (entryStream)
                {
                    await _downloader.DownloadAsync(
                        stagedFile,
                        entryStream,
                        copyBuffer,
                        currentResponse,
                        cancellationToken);
                }

                _logger.LogZipEntryWritten(stagedFile.EntryName, stagedFile.Size);
            }
        }
        catch (Exception e)
        {
            failure = e;

            throw;
        }
        finally
        {
            // A prefetch left in flight on the failure path must be observed and disposed
            // so its response stream is released and no UnobservedTaskException is raised.
            await _downloader.DisposePrefetchAsync(prefetchedResponse);

            // Disposing the archive writes the central directory into the upload stream. On
            // the failure path that write happens against a possibly broken stream, and its
            // exception must not replace the root cause that is already propagating.
            try
            {
                await zipArchive.DisposeAsync();
            }
#pragma warning disable CA1031 // a dispose failure must not mask the propagating root cause
            catch when (failure is not null)
            {
            }
#pragma warning restore CA1031
        }
    }

    /// <summary>
    /// Deflate burns a full CPU core for near-zero gain on content that is already
    /// compressed, so such entries are stored uncompressed and the job stays network-bound.
    /// </summary>
    private static CompressionLevel GetCompressionLevel(string entryName)
    {
        return ZipStorageConstants.IncompressibleExtensions.Contains(Path.GetExtension(entryName))
            ? CompressionLevel.NoCompression
            : CompressionLevel.Fastest;
    }

    private async Task AbortMultipartUploadAsync(string zipFileKey, string uploadId)
    {
        try
        {
            await _s3Client.AbortMultipartUploadAsync(
                new AbortMultipartUploadRequest
                {
                    BucketName = _options.BucketName,
                    Key = zipFileKey,
                    UploadId = uploadId
                },
                CancellationToken.None);
        }
#pragma warning disable CA1031 // best-effort cleanup must never replace the original exception
        catch (Exception e)
        {
            // Aborting is best-effort cleanup: a failure here (of any kind, not just an S3
            // error) must never replace the original exception that caused the upload to be
            // abandoned. Any parts left behind are removed by the bucket lifecycle policy.
            _logger.LogMultipartUploadAbortFailed(zipFileKey, e);
        }
#pragma warning restore CA1031
    }
}
