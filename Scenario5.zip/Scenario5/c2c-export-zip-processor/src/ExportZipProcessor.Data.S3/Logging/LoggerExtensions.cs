using System;
using ExportZipProcessor.Data.S3.Storage;
using Microsoft.Extensions.Logging;

namespace ExportZipProcessor.Data.S3.Logging;

internal static partial class LoggerExtensions
{
    [LoggerMessage(
        Level = LogLevel.Information,
        Message = "Listed {StagedFilesCount} staged files with total size {TotalSizeBytes} bytes")]
    public static partial void LogStagedFilesListed(
        this ILogger<StagedFilesStorage> logger,
        int stagedFilesCount,
        long totalSizeBytes);

    [LoggerMessage(
        Level = LogLevel.Information,
        Message = "Deleted {StagedFilesCount} staged files")]
    public static partial void LogStagedFilesDeleted(
        this ILogger<StagedFilesStorage> logger,
        int stagedFilesCount);

    [LoggerMessage(
        Level = LogLevel.Warning,
        Message = "Downloading staged file {StagedFileKey} failed transiently "
                  + "(attempt {Attempt} of {MaxAttempts}); resuming from the last written byte")]
    public static partial void LogStagedFileDownloadRetrying(
        this ILogger<StagedFileDownloader> logger,
        string stagedFileKey,
        int attempt,
        int maxAttempts,
        Exception exception);

    [LoggerMessage(
        Level = LogLevel.Warning,
        Message = "Failed to dispose a prefetched staged file download")]
    public static partial void LogStagedFilePrefetchDisposeFailed(
        this ILogger<StagedFileDownloader> logger,
        Exception exception);

    [LoggerMessage(
        Level = LogLevel.Information,
        Message = "Initiated multipart upload for {ZipFileKey}")]
    public static partial void LogMultipartUploadInitiated(
        this ILogger<ZipArchiveWriter> logger,
        string zipFileKey);

    [LoggerMessage(
        Level = LogLevel.Debug,
        Message = "Wrote zip entry {EntryName} ({ContentLengthBytes} bytes)")]
    public static partial void LogZipEntryWritten(
        this ILogger<ZipArchiveWriter> logger,
        string entryName,
        long contentLengthBytes);

    [LoggerMessage(
        Level = LogLevel.Information,
        Message = "Multipart upload progress for {ZipFileKey}: {PartCount} parts, {BytesUploaded} bytes")]
    public static partial void LogMultipartUploadProgress(
        this ILogger logger,
        string zipFileKey,
        int partCount,
        long bytesUploaded);

    [LoggerMessage(
        Level = LogLevel.Information,
        Message = "Completed multipart upload for {ZipFileKey}: {PartCount} parts, {BytesUploaded} bytes")]
    public static partial void LogMultipartUploadCompleted(
        this ILogger<ZipArchiveWriter> logger,
        string zipFileKey,
        int partCount,
        long bytesUploaded);

    [LoggerMessage(
        Level = LogLevel.Information,
        Message = "Found existing zip archive {ZipFileKey}; reusing it instead of regenerating")]
    public static partial void LogExistingZipArchiveReused(
        this ILogger<ZipArchiveWriter> logger,
        string zipFileKey);

    [LoggerMessage(
        Level = LogLevel.Warning,
        Message = "Failed to abort multipart upload for {ZipFileKey}")]
    public static partial void LogMultipartUploadAbortFailed(
        this ILogger<ZipArchiveWriter> logger,
        string zipFileKey,
        Exception exception);

    [LoggerMessage(
        Level = LogLevel.Debug,
        Message = "In-flight part upload for {ZipFileKey} failed while disposing the upload stream")]
    public static partial void LogMultipartUploadPartFailedOnDispose(
        this ILogger logger,
        string zipFileKey,
        Exception exception);
}
