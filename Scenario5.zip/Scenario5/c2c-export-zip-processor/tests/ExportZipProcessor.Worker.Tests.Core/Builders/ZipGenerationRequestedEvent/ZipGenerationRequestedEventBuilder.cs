using System;
using System.Net.Mime;
using System.Text;
using System.Text.Json;
using System.Text.Json.Serialization;
using Amazon.SQS.Model;
using CloudNative.CloudEvents;
using CloudNative.CloudEvents.SystemTextJson;
using ExportZipProcessor.Worker.Constants;
using ExportZipProcessor.Worker.Models;

namespace ExportZipProcessor.Worker.Tests.Core.Builders.ZipGenerationRequestedEvent;

internal class ZipGenerationRequestedEventBuilder
{
    private readonly JsonSerializerOptions _options = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Converters = { new JsonStringEnumConverter() }
    };

    private readonly CloudEvent _cloudEvent = new()
    {
        Type = EventTypes.ZipGenerationRequested,
        Time = DateTimeOffset.UtcNow,
        Id = Guid.NewGuid().ToString(),
        Source = new Uri("https://my-service.example.com/events"),
        DataContentType = MediaTypeNames.Application.Json
    };

    public ZipGenerationRequestedEventBuilder WithData(ZipGenerationRequestedEventPayload payload)
    {
        _cloudEvent.Data = JsonSerializer.SerializeToElement(payload, _options);

        return this;
    }

    public ZipGenerationRequestedEventBuilder WithInvalidData()
    {
        _cloudEvent.Data = JsonSerializer.SerializeToElement(new { InvalidDataBody = "true" }, _options);

        return this;
    }

    public Message Build()
    {
        var formatter = new JsonEventFormatter();
        var cloudEventJson =
            Encoding.UTF8.GetString(formatter.EncodeStructuredModeMessage(_cloudEvent, out _).ToArray());

        return new Message { Body = cloudEventJson };
    }
}
