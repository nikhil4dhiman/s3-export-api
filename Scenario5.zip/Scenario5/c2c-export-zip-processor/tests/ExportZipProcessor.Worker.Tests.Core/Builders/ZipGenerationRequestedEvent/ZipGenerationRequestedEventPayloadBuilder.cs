using System;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipProcessor.Worker.Models;

namespace ExportZipProcessor.Worker.Tests.Core.Builders.ZipGenerationRequestedEvent;

internal class ZipGenerationRequestedEventPayloadBuilder
    : BuilderBase<ZipGenerationRequestedEventPayloadBuilder, ZipGenerationRequestedEventPayload>
{
    public ZipGenerationRequestedEventPayloadBuilder WithRandomValues()
    {
        return WithAutoProperties()
            .With(x => x.ExportId, Guid.NewGuid().ToString());
    }
}
