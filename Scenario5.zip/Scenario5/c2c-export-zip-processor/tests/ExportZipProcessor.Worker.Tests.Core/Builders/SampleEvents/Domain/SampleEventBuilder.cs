using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Worker.Tests.Core.Builders.SampleEvents.Domain;

public class SampleEventBuilder : BuilderBase<SampleEventBuilder, SampleEvent>
{
    public SampleEventBuilder WithId(string id)
    {
        return With(x => x.Id, id);
    }

    public SampleEventBuilder WithType(string type)
    {
        return With(x => x.Type, type);
    }

    public SampleEventBuilder WithPayload(byte[] payload)
    {
        return With(x => x.Payload, payload);
    }
}
