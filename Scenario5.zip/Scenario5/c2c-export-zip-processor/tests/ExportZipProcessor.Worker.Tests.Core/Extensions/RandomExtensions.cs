using System;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;

namespace ExportZipProcessor.Worker.Tests.Core.Extensions;

public static class RandomExtensions
{
    public static Uri ZipFileUrl(this RandomExtensionPoint _)
    {
        return new Uri(Generate.Random.Url());
    }
}
