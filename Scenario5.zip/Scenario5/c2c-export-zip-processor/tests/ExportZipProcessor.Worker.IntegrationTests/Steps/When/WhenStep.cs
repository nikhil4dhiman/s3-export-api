using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.IntegrationTests.Framework;

namespace ExportZipProcessor.Worker.IntegrationTests.Steps.When;

internal class WhenStep : RootStep<WhenStep, Scenario>;
