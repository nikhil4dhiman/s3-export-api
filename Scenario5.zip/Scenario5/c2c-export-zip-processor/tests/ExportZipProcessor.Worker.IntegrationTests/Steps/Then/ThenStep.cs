using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.IntegrationTests.Framework;

namespace ExportZipProcessor.Worker.IntegrationTests.Steps.Then;

internal class ThenStep : RootStep<ThenStep, Scenario>;
