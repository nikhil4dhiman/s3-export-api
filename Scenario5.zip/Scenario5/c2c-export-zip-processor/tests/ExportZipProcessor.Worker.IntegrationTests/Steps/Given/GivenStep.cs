using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.IntegrationTests.Framework;

namespace ExportZipProcessor.Worker.IntegrationTests.Steps.Given;

internal class GivenStep : RootStep<GivenStep, Scenario>;
