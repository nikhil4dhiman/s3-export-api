using ExportZipProcessor.Worker.IntegrationTests.Framework;
using NUnit.Framework;

namespace ExportZipProcessor.Worker.IntegrationTests.Tests.Samples;

[TestFixture]
internal class SampleEventsProcessing_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
    }

    [Test]
    public void Test1()
    {
        Assert.Pass();
    }
}
