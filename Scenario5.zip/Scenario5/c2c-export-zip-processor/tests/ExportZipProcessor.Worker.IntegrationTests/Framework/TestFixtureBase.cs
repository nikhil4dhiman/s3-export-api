using System.IO;
using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration;
using Cove.Platform.Extensions.Testing.SharedHelpers.DependencyInjection;
using ExportZipProcessor.Worker.IntegrationTests.Steps.Given;
using ExportZipProcessor.Worker.IntegrationTests.Steps.Then;
using ExportZipProcessor.Worker.IntegrationTests.Steps.When;
using Microsoft.AspNetCore.Hosting;

namespace ExportZipProcessor.Worker.IntegrationTests.Framework;

internal class TestFixtureBase : ApplicationTestFixtureBase<Program, GivenStep, WhenStep, ThenStep, Scenario>
{
    protected override void ConfigureWebHostBuilder(IWebHostBuilder builder)
    {
        // https://github.com/dotnet/aspnetcore/issues/17707#issuecomment-609061917
        builder.UseContentRoot(Directory.GetCurrentDirectory());
    }

    protected override IApplicationConfigurationOverride BuildConfigurationOverride()
    {
        return new ApplicationConfigurationOverride();
    }

    protected override IApplicationServicesOverride<Scenario> BuildServicesOverride()
    {
        return new ApplicationServicesOverride();
    }
}
