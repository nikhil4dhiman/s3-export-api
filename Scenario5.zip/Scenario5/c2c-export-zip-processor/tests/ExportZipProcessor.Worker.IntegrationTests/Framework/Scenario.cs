using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using Cove.Platform.Extensions.Testing.SharedHelpers.DateTimeHandling;
using Microsoft.Extensions.Time.Testing;

namespace ExportZipProcessor.Worker.IntegrationTests.Framework;

/// <summary>
/// Holds shared data that is scoped to the currently running test.
/// </summary>
/// <remarks>
/// <see cref="Scenario"/> class is defined as internal as it may hold references to internal classes from the SUT.
/// </remarks>
internal class Scenario : DefaultApplicationScenarioBase<Program>
{
    public FakeTimeProvider TimeProvider => Extensions.GetTimeProviderMock();
}
