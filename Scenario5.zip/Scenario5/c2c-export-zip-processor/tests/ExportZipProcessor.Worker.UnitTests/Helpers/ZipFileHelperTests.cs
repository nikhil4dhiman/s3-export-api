using System;
using System.Globalization;
using System.Linq;
using System.Text;
using ExportZipProcessor.Domain.Helpers;
using ExportZipProcessor.Domain.Models;
using NUnit.Framework;

namespace ExportZipProcessor.Worker.UnitTests.Helpers;

/// <summary>Pins the archive naming convention with literal expectations.</summary>
[TestFixture]
internal class ZipFileHelperTests
{
    private static readonly DateTimeOffset CompletedAt = new(2026, 8, 28, 12, 34, 56, TimeSpan.Zero);

    [Test]
    public void NamesSharePointExportsAfterTheSite()
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("MarketingSite", SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo("MarketingSite_SharePointExport_2026-08-28_123456.zip"));
    }

    [Test]
    public void NamesOneDriveExportsAfterTheUser()
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("Harihara.Sudhan@sy01q.onmicrosoft.com", SourceType.OneDrive, CompletedAt));

        Assert.That(
            name,
            Is.EqualTo("Harihara.Sudhan_at_sy01q.onmicrosoft.com_OneDriveExport_2026-08-28_123456.zip"));
    }

    [Test]
    public void JoinsTheWordsOfASourceNameInPascalCase()
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("Marketing Team Site", SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo("MarketingTeamSite_SharePointExport_2026-08-28_123456.zip"));
    }

    [Test]
    public void CapitalisesASourceNameThatArrivesInLowerCase()
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("marketing team site", SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo("MarketingTeamSite_SharePointExport_2026-08-28_123456.zip"));
    }

    [Test]
    public void StampsTheTimestampInUtc()
    {
        var completedAt = new DateTimeOffset(2026, 8, 28, 14, 34, 56, TimeSpan.FromHours(2));

        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("Site", SourceType.SharePoint, completedAt));

        Assert.That(name, Is.EqualTo("Site_SharePointExport_2026-08-28_123456.zip"));
    }

    [TestCase("a/b", "AB")]
    [TestCase(@"a\b", "AB")]
    [TestCase("a:b", "AB")]
    [TestCase("a*b?c", "ABC")]
    [TestCase("a<b>c|d", "ABCD")]
    [TestCase("a\"b", "AB")]
    [TestCase("a%b", "AB")]
    [TestCase("a#b", "AB")]
    [TestCase("a\nb", "AB")]
    [TestCase("a.b", "AB")]
    [TestCase("a@b", "AB")]
    [TestCase("a&b (c) d!", "ABCD")]
    [TestCase("a+b=c", "ABC")]
    [TestCase("a'b", "AB")]
    [TestCase("Site 🎉 Name", "SiteName")]
    [TestCase("  padded  ", "Padded")]
    [TestCase("Ünïcodé Sïte", "ÜnïcodéSïte")]
    [TestCase("Site 42", "Site42")]
    public void KeepsOnlyLettersAndDigits(string sourceName, string expected)
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo($"{expected}_SharePointExport_2026-08-28_123456.zip"));
    }

    [TestCase("Site_Name", "SiteName")]
    [TestCase("Site-Name", "SiteName")]
    [TestCase("Site_-_Name", "SiteName")]
    public void DropsTheSeparatorsTheFileNameStructureReserves(string sourceName, string expected)
    {
        // '_' separates the three components and '-' belongs to the date, so a source name
        // contributing either would make the parts ambiguous to read back.
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo($"{expected}_SharePointExport_2026-08-28_123456.zip"));
    }

    [TestCase("Site///Name", "SiteName")]
    [TestCase("Site   Name", "SiteName")]
    [TestCase("Site / Name", "SiteName")]
    public void TreatsARunOfDroppedCharactersAsASingleWordBoundary(string sourceName, string expected)
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo($"{expected}_SharePointExport_2026-08-28_123456.zip"));
    }

    [TestCase("Site‮Name")]  // right-to-left override - reverses how the name renders
    [TestCase("Site​Name")]  // zero-width space - invisible padding
    [TestCase("Site⁦Name")]  // left-to-right isolate
    public void DropsInvisibleCharactersThatCouldDisguiseTheName(string sourceName)
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo("SiteName_SharePointExport_2026-08-28_123456.zip"));
        Assert.That(name.Any(c => char.GetUnicodeCategory(c) == UnicodeCategory.Format), Is.False);
    }

    [Test]
    public void CapsAnOverlongSourceName()
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(new string('x', 300), SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo($"X{new string('x', 127)}_SharePointExport_2026-08-28_123456.zip"));
    }

    [Test]
    public void CapsAnOverlongSourceNameWithoutSplittingASurrogatePair()
    {
        // U+10400 is a letter outside the BMP, so it is kept as a surrogate pair. The leading
        // 'x' puts the 128th char - where the cap cuts - inside the last pair, so the cap has
        // to stop a char short rather than leave half a pair behind.
        var sourceName = "x" + Repeat("\U00010400", 200);

        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo($"X{Repeat("\U00010400", 63)}_SharePointExport_2026-08-28_123456.zip"));

        // An unpaired surrogate does not survive a UTF-8 round trip - it becomes U+FFFD.
        Assert.That(Encoding.UTF8.GetString(Encoding.UTF8.GetBytes(name)), Is.EqualTo(name));
    }

    [TestCase("")]
    [TestCase("   ")]
    [TestCase("///")]
    [TestCase("...")]
    [TestCase("@@@")]
    [TestCase("🎉")]
    public void FallsBackWhenTheSourceNameIsUnusable(string sourceName)
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.SharePoint, CompletedAt));

        Assert.That(name, Is.EqualTo(ZipFileHelper.FallbackZipFileName));
    }

    [TestCase("user@example.com", "user_at_example.com")]
    [TestCase("john.doe@test.com", "john.doe_at_test.com")]
    [TestCase("Harihara.Sudhan@sy01q.onmicrosoft.com", "Harihara.Sudhan_at_sy01q.onmicrosoft.com")]
    public void ReplacesAtWithItsLiteralWordForOneDrive(string sourceName, string expected)
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.OneDrive, CompletedAt));

        Assert.That(name, Is.EqualTo($"{expected}_OneDriveExport_2026-08-28_123456.zip"));
    }

    [TestCase("us*er@exa:mple.com", "us_er_at_exa_mple.com")]
    [TestCase("a/b@c", "a_b_at_c")]
    public void ReplacesOtherInvalidCharactersWithAnUnderscoreForOneDrive(string sourceName, string expected)
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.OneDrive, CompletedAt));

        Assert.That(name, Is.EqualTo($"{expected}_OneDriveExport_2026-08-28_123456.zip"));
    }

    [Test]
    public void KeepsCaseForOneDrive()
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("john.DOE@Test.com", SourceType.OneDrive, CompletedAt));

        Assert.That(name, Is.EqualTo("john.DOE_at_Test.com_OneDriveExport_2026-08-28_123456.zip"));
    }

    [TestCase("@@@", "_at__at__at_")]
    [TestCase("...", "...")]
    public void DoesNotFallBackForOneDriveWhenTheSourceNameHasNoLetterOrDigit(string sourceName, string expected)
    {
        // Unlike SharePoint, a OneDrive identifier only sanitises to empty if it started empty,
        // so junk like "@@@" still produces a (nonsensical but non-fallback) name.
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(sourceName, SourceType.OneDrive, CompletedAt));

        Assert.That(name, Is.EqualTo($"{expected}_OneDriveExport_2026-08-28_123456.zip"));
    }

    [Test]
    public void FallsBackForOneDriveWhenTheSourceNameIsEmpty()
    {
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo(string.Empty, SourceType.OneDrive, CompletedAt));

        Assert.That(name, Is.EqualTo(ZipFileHelper.FallbackZipFileName));
    }

    [Test]
    public void KeepsUnicodeLettersDistinctForOneDrive()
    {
        // "jose" and "josé" must not collapse to the same archive name.
        var accented = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("josé@example.com", SourceType.OneDrive, CompletedAt));
        var plain = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("jose@example.com", SourceType.OneDrive, CompletedAt));

        Assert.That(accented, Is.EqualTo("josé_at_example.com_OneDriveExport_2026-08-28_123456.zip"));
        Assert.That(accented, Is.Not.EqualTo(plain));
    }

    [Test]
    public void KeepsAPlusSignDistinctForOneDrive()
    {
        // "user+tag" and "user_tag" must not collapse to the same archive name.
        var tagged = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("user+tag@example.com", SourceType.OneDrive, CompletedAt));
        var underscored = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("user_tag@example.com", SourceType.OneDrive, CompletedAt));

        Assert.That(tagged, Is.EqualTo("user+tag_at_example.com_OneDriveExport_2026-08-28_123456.zip"));
        Assert.That(tagged, Is.Not.EqualTo(underscored));
    }

    [Test]
    public void KeepsASurrogatePairWholeForOneDrive()
    {
        // U+10400 is a letter outside the BMP, so it is kept as a surrogate pair rather than
        // having each half matched - and replaced - independently.
        var name = ZipFileHelper.BuildZipFileName(BuildZipGenerationInfo("user\U00010400@example.com", SourceType.OneDrive, CompletedAt));

        Assert.That(name, Is.EqualTo("user\U00010400_at_example.com_OneDriveExport_2026-08-28_123456.zip"));
    }

    private static string Repeat(string value, int count)
    {
        return string.Concat(Enumerable.Repeat(value, count));
    }

    private static ZipGenerationInfo BuildZipGenerationInfo(
        string sourceName,
        SourceType sourceType,
        DateTimeOffset completedAt)
    {
        return new ZipGenerationInfo
        {
            ExportId = "src-bkp-46-run",
            PartnerId = "100200300",
            SourceName = sourceName,
            SourceType = sourceType,
            ZipRequestedAt = completedAt
        };
    }
}
