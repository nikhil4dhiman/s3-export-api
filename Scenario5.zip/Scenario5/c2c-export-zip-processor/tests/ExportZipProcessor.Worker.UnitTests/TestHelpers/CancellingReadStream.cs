using System;
using System.IO;
using System.Threading;

namespace ExportZipProcessor.Worker.UnitTests.TestHelpers;

/// <summary>
/// A read-only stream that serves the given content but cancels the supplied token source
/// once the given number of bytes has been read, simulating a shutdown (or visibility
/// timeout) arriving while a staged file body is still being streamed.
/// </summary>
internal sealed class CancellingReadStream : Stream
{
    private readonly byte[] _content;
    private readonly int _cancelAfterBytes;
    private readonly CancellationTokenSource _cancellationTokenSource;
    private int _position;

    public CancellingReadStream(
        byte[] content,
        int cancelAfterBytes,
        CancellationTokenSource cancellationTokenSource)
    {
        _content = content;
        _cancelAfterBytes = cancelAfterBytes;
        _cancellationTokenSource = cancellationTokenSource;
    }

    public override bool CanRead => true;

    public override bool CanSeek => false;

    public override bool CanWrite => false;

    public override long Length => _content.Length;

    public override long Position
    {
        get => _position;
        set => throw new NotSupportedException();
    }

    public override int Read(byte[] buffer, int offset, int count)
    {
        if (_position >= _content.Length)
        {
            return 0;
        }

        var bytesToRead = Math.Min(count, _content.Length - _position);

        Array.Copy(_content,
            _position,
            buffer,
            offset,
            bytesToRead);
        _position += bytesToRead;

        if (_position >= _cancelAfterBytes)
        {
            _cancellationTokenSource.Cancel();
        }

        return bytesToRead;
    }

    public override void Flush()
    {
    }

    public override long Seek(long offset, SeekOrigin origin)
    {
        throw new NotSupportedException();
    }

    public override void SetLength(long value)
    {
        throw new NotSupportedException();
    }

    public override void Write(byte[] buffer, int offset, int count)
    {
        throw new NotSupportedException();
    }
}
