using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Threading;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using Moq;

namespace ExportZipProcessor.Worker.UnitTests.TestHelpers;

/// <summary>
/// A Moq-backed in-memory stand-in for <see cref="IAmazonS3"/> covering the operations the
/// zip storage layer uses: GETs served from an object dictionary (honouring byte ranges and
/// ETag pinning) and a multipart upload that captures every part's bytes so tests can
/// reassemble and validate the uploaded archive.
/// </summary>
internal class InMemoryS3
{
    private readonly Dictionary<string, byte[]> _objects = [];
    private readonly Dictionary<string, Func<byte[], Stream>> _responseStreamFactories = [];

    public InMemoryS3()
    {
        Mock = new Mock<IAmazonS3>(MockBehavior.Strict);

        SetupGetObject();
        SetupMultipartUpload();
    }

    public Mock<IAmazonS3> Mock { get; }

    public IAmazonS3 Client => Mock.Object;

    public List<GetObjectRequest> GetRequests { get; } = [];

    public List<InitiateMultipartUploadRequest> InitiateRequests { get; } = [];

    public SortedDictionary<int, byte[]> UploadedParts { get; } = [];

    public List<CompleteMultipartUploadRequest> CompleteRequests { get; } = [];

    public List<AbortMultipartUploadRequest> AbortRequests { get; } = [];

    public Func<UploadPartRequest, Exception?> UploadPartFailure { get; set; } = _ => null;

    public void AddObject(string key, byte[] content)
    {
        _objects[key] = content;
    }

    /// <summary>
    /// Overrides how the response body stream for a key is produced, so tests can inject
    /// streams that fail mid-body. The factory receives the (already range-sliced) content.
    /// </summary>
    public void SetResponseStreamFactory(string key, Func<byte[], Stream> factory)
    {
        _responseStreamFactories[key] = factory;
    }

    public byte[] AssembleUploadedObject()
    {
        using var assembled = new MemoryStream();

        foreach (var part in UploadedParts.Values)
        {
            assembled.Write(part);
        }

        return assembled.ToArray();
    }

    public static string ETagFor(string key)
    {
        return $"etag-of-{key}";
    }

    private void SetupGetObject()
    {
        Mock
            .Setup(s => s.GetObjectAsync(It.IsAny<GetObjectRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((GetObjectRequest request, CancellationToken _) =>
            {
                GetRequests.Add(request);

                if (!_objects.TryGetValue(request.Key, out var content))
                {
                    throw new AmazonS3Exception(
                        $"No such key {request.Key}", ErrorType.Sender, "NoSuchKey", "req", HttpStatusCode.NotFound);
                }

                var body = request.ByteRange is null
                    ? content
                    : content[(int)request.ByteRange.Start..((int)request.ByteRange.End + 1)];

                var responseStream = _responseStreamFactories.TryGetValue(request.Key, out var factory)
                    ? factory(body)
                    : new MemoryStream(body, writable: false);

                return new GetObjectResponse
                {
                    Key = request.Key,
                    ETag = ETagFor(request.Key),
                    ResponseStream = responseStream
                };
            });
    }

    private void SetupMultipartUpload()
    {
        Mock
            .Setup(s => s.InitiateMultipartUploadAsync(
                It.IsAny<InitiateMultipartUploadRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((InitiateMultipartUploadRequest request, CancellationToken _) =>
            {
                InitiateRequests.Add(request);

                return new InitiateMultipartUploadResponse { UploadId = "test-upload-id" };
            });

        Mock
            .Setup(s => s.UploadPartAsync(It.IsAny<UploadPartRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((UploadPartRequest request, CancellationToken _) =>
            {
                var failure = UploadPartFailure(request);

                if (failure is not null)
                {
                    throw failure;
                }

                using var partContent = new MemoryStream();

                request.InputStream.CopyTo(partContent);
                UploadedParts[request.PartNumber!.Value] = partContent.ToArray();

                return new UploadPartResponse
                {
                    PartNumber = request.PartNumber,
                    ETag = $"part-etag-{request.PartNumber}"
                };
            });

        Mock
            .Setup(s => s.CompleteMultipartUploadAsync(
                It.IsAny<CompleteMultipartUploadRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((CompleteMultipartUploadRequest request, CancellationToken _) =>
            {
                CompleteRequests.Add(request);

                return new CompleteMultipartUploadResponse();
            });

        Mock
            .Setup(s => s.AbortMultipartUploadAsync(
                It.IsAny<AbortMultipartUploadRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync((AbortMultipartUploadRequest request, CancellationToken _) =>
            {
                AbortRequests.Add(request);

                return new AbortMultipartUploadResponse();
            });
    }
}
