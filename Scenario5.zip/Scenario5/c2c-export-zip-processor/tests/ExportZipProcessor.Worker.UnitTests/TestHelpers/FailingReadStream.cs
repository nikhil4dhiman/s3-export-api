using System;
using System.IO;

namespace ExportZipProcessor.Worker.UnitTests.TestHelpers;

/// <summary>
/// A read-only stream that serves the given content but throws an <see cref="IOException"/>
/// once the given number of bytes has been read, simulating a connection dropped mid-body.
/// </summary>
internal sealed class FailingReadStream : Stream
{
    private readonly byte[] _content;
    private readonly int _failAfterBytes;
    private int _position;

    public FailingReadStream(byte[] content, int failAfterBytes)
    {
        _content = content;
        _failAfterBytes = failAfterBytes;
    }

    public override bool CanRead => true;

    public override bool CanSeek => false;

    public override bool CanWrite => false;

    public override long Length => _content.Length;

    public override long Position
    {
        get => _position;
        set => throw new NotSupportedException();
    }

    public override int Read(byte[] buffer, int offset, int count)
    {
        if (_position >= _content.Length)
        {
            return 0;
        }

        if (_position >= _failAfterBytes)
        {
            throw new IOException("Simulated mid-body connection failure");
        }

        var bytesToRead = Math.Min(count, _failAfterBytes - _position);
        bytesToRead = Math.Min(bytesToRead, _content.Length - _position);

        Array.Copy(_content,
            _position,
            buffer,
            offset,
            bytesToRead);
        _position += bytesToRead;

        return bytesToRead;
    }

    public override void Flush()
    {
    }

    public override long Seek(long offset, SeekOrigin origin)
    {
        throw new NotSupportedException();
    }

    public override void SetLength(long value)
    {
        throw new NotSupportedException();
    }

    public override void Write(byte[] buffer, int offset, int count)
    {
        throw new NotSupportedException();
    }
}
