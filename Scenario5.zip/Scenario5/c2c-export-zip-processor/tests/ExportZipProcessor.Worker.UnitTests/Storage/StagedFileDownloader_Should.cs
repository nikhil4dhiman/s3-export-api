using System;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Data.S3.Configuration;
using ExportZipProcessor.Data.S3.Storage;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.UnitTests.TestHelpers;
using Microsoft.Extensions.Logging.Abstractions;
using NUnit.Framework;

namespace ExportZipProcessor.Worker.UnitTests.Storage;

[TestFixture]
internal class StagedFileDownloader_Should
{
    private const string BucketName = "unit-tests-bucket";
    private const string FileKey = "exports/export-1/staging/file.bin";

    private InMemoryS3 _s3 = null!;
    private StagedFileDownloader _downloader = null!;

    [SetUp]
    public void SetUp()
    {
        _s3 = new InMemoryS3();

        var options = new ZipStorageOptions
        {
            BucketName = BucketName,
            PartSizeInMegabytes = 5,
            MaxDownloadAttempts = 3,
            ProgressLogPartInterval = 100,
            DeleteBatchSize = 1000
        };

        _downloader = new StagedFileDownloader(_s3.Client, options, NullLogger<StagedFileDownloader>.Instance);
    }

    [Test]
    public async Task ResumeWithARangedEtagPinnedGet_AfterATransientMidBodyFailure()
    {
        const int FailAfterBytes = 100_000;

        var content = new byte[300_000];

        RandomNumberGenerator.Fill(content);
        _s3.AddObject(FileKey, content);

        // Only the first GET's body drops mid-stream; the resumed ranged GET succeeds.
        var served = 0;

        _s3.SetResponseStreamFactory(FileKey, body => ++served == 1
            ? new FailingReadStream(body, FailAfterBytes)
            : new MemoryStream(body, writable: false));

        var stagedFile = new StagedFile(FileKey, content.Length, "file.bin");
        using var destination = new MemoryStream();

        await _downloader.DownloadAsync(
            stagedFile,
            destination,
            new byte[64 * 1024],
            prefetchedResponse: null,
            CancellationToken.None);

        Assert.That(destination.ToArray(), Is.EqualTo(content));
        Assert.That(_s3.GetRequests, Has.Count.EqualTo(2));

        var resumedRequest = _s3.GetRequests[1];

        Assert.That(resumedRequest.ByteRange!.Start, Is.EqualTo(FailAfterBytes));
        Assert.That(resumedRequest.ByteRange.End, Is.EqualTo(content.Length - 1));
        Assert.That(resumedRequest.EtagToMatch, Is.EqualTo(InMemoryS3.ETagFor(FileKey)));
    }

    [Test]
    public void NotRetry_WhenWritingToTheDestinationFails()
    {
        var content = new byte[100_000];

        _s3.AddObject(FileKey, content);

        var stagedFile = new StagedFile(FileKey, content.Length, "file.bin");

        // The destination failing means bytes may already sit compressed in the part buffer,
        // so the downloader must propagate immediately even though an IOException would
        // normally be classified as transient and retried.
        Assert.ThrowsAsync<IOException>(() => _downloader.DownloadAsync(
            stagedFile,
            new FailingWriteStream(),
            new byte[64 * 1024],
            prefetchedResponse: null,
            CancellationToken.None));

        Assert.That(_s3.GetRequests.Count(r => r.Key == FileKey), Is.EqualTo(1));
    }

    [Test]
    public async Task StopTheDownload_WhenTheCancellationTokenIsCancelledMidBody()
    {
        const int CancelAfterBytes = 100_000;

        var content = new byte[300_000];

        RandomNumberGenerator.Fill(content);
        _s3.AddObject(FileKey, content);

        using var cancellationTokenSource = new CancellationTokenSource();

        _s3.SetResponseStreamFactory(
            FileKey,
            body => new CancellingReadStream(body, CancelAfterBytes, cancellationTokenSource));

        var stagedFile = new StagedFile(FileKey, content.Length, "file.bin");
        using var destination = new MemoryStream();

        OperationCanceledException? caught = null;

        try
        {
            await _downloader.DownloadAsync(
                stagedFile,
                destination,
                new byte[64 * 1024],
                prefetchedResponse: null,
                cancellationTokenSource.Token);
        }
        catch (OperationCanceledException exception)
        {
            caught = exception;
        }

        Assert.That(caught, Is.Not.Null);

        // Cancellation must abandon the transfer instead of retrying it to completion.
        Assert.That(destination.Length, Is.LessThan(content.Length));
        Assert.That(_s3.GetRequests.Count(r => r.Key == FileKey), Is.EqualTo(1));
    }

    [Test]
    public async Task NotRequestAnything_ForAnEmptyStagedFile()
    {
        var stagedFile = new StagedFile(FileKey, 0, "file.bin");
        using var destination = new MemoryStream();

        Assert.That(_downloader.StartPrefetch(stagedFile, CancellationToken.None), Is.Null);

        await _downloader.DownloadAsync(
            stagedFile,
            destination,
            new byte[64 * 1024],
            prefetchedResponse: null,
            CancellationToken.None);

        Assert.That(destination.Length, Is.Zero);
        Assert.That(_s3.GetRequests, Is.Empty);
    }

    private sealed class FailingWriteStream : Stream
    {
        public override bool CanRead => false;

        public override bool CanSeek => false;

        public override bool CanWrite => true;

        public override long Length => 0;

        public override long Position
        {
            get => 0;
            set => throw new NotSupportedException();
        }

        public override void Write(byte[] buffer, int offset, int count)
        {
            throw new IOException("Simulated destination failure");
        }

        public override void Flush()
        {
        }

        public override int Read(byte[] buffer, int offset, int count)
        {
            throw new NotSupportedException();
        }

        public override long Seek(long offset, SeekOrigin origin)
        {
            throw new NotSupportedException();
        }

        public override void SetLength(long value)
        {
            throw new NotSupportedException();
        }
    }
}
