using System;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Amazon.Runtime;
using Amazon.S3;
using Amazon.S3.Model;
using ExportZipProcessor.Data.S3.Configuration;
using ExportZipProcessor.Data.S3.Storage;
using ExportZipProcessor.Domain.Exceptions;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.UnitTests.TestHelpers;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using NUnit.Framework;

namespace ExportZipProcessor.Worker.UnitTests.Storage;

[TestFixture]
internal class ZipArchiveWriter_Should
{
    private const string BucketName = "unit-tests-bucket";
    private const string StagingPrefix = "exports/export-1/staging/";
    private const string ZipFileKey = "exports/export-1/final.zip";
    private const int PartSizeInMegabytes = 5;

    private static readonly string[] ExpectedEntryNames = ["big-blob.zip", "nested/empty.txt", "report.txt"];

    private InMemoryS3 _s3 = null!;
    private ZipArchiveWriter _writer = null!;

    [SetUp]
    public void SetUp()
    {
        _s3 = new InMemoryS3();

        var options = new ZipStorageOptions
        {
            BucketName = BucketName,
            PartSizeInMegabytes = PartSizeInMegabytes,
            MaxDownloadAttempts = 3,
            ProgressLogPartInterval = 100,
            DeleteBatchSize = 1000
        };

        _writer = new ZipArchiveWriter(
            _s3.Client,
            options,
            new StagedFileDownloader(_s3.Client, options, NullLogger<StagedFileDownloader>.Instance),
            NullLogger<ZipArchiveWriter>.Instance);
    }

    [Test]
    public async Task UploadValidMultipartZip_CoveringPartBoundariesAndEmptyFiles()
    {
        // An already-compressed (stored) payload larger than two parts forces the archive
        // across several part boundaries; random bytes keep deflate from shrinking anything.
        var largeContent = RandomBytes((2 * PartSizeInMegabytes * 1024 * 1024) + 12_345);
        var textContent = Encoding.UTF8.GetBytes(new string('a', 100_000));

        var stagedFiles = new[]
        {
            StageFile("big-blob.zip", largeContent),
            StageFile("nested/empty.txt", []),
            StageFile("report.txt", textContent)
        };

        var archive = await _writer.WriteAsync(stagedFiles, ZipFileKey, CancellationToken.None);

        Assert.That(archive.Location, Is.EqualTo(new Uri($"s3://{BucketName}/{ZipFileKey}")));
        Assert.That(archive.SizeInBytes, Is.EqualTo(_s3.AssembleUploadedObject().Length));
        Assert.That(_s3.CompleteRequests, Has.Count.EqualTo(1));
        Assert.That(_s3.UploadedParts.Count, Is.GreaterThanOrEqualTo(3));
        Assert.That(
            _s3.CompleteRequests[0].PartETags.Select(p => p.PartNumber),
            Is.EqualTo(_s3.UploadedParts.Keys));

        using var zip = new ZipArchive(new MemoryStream(_s3.AssembleUploadedObject()), ZipArchiveMode.Read);

        Assert.That(zip.Entries.Select(e => e.FullName), Is.EqualTo(ExpectedEntryNames));
        Assert.That(ReadEntry(zip, "big-blob.zip"), Is.EqualTo(largeContent));
        Assert.That(ReadEntry(zip, "nested/empty.txt"), Is.Empty);
        Assert.That(ReadEntry(zip, "report.txt"), Is.EqualTo(textContent));

        // The .zip payload must be stored, not deflated; the text must actually compress.
        Assert.That(zip.GetEntry("big-blob.zip")!.CompressedLength, Is.EqualTo(largeContent.Length));
        Assert.That(zip.GetEntry("report.txt")!.CompressedLength, Is.LessThan(textContent.Length / 2));
    }

    [Test]
    public async Task UploadValidEmptyZip_WhenThereAreNoStagedFiles()
    {
        var archive = await _writer.WriteAsync([], ZipFileKey, CancellationToken.None);

        Assert.That(archive.Location, Is.EqualTo(new Uri($"s3://{BucketName}/{ZipFileKey}")));
        Assert.That(archive.SizeInBytes, Is.EqualTo(_s3.AssembleUploadedObject().Length));
        Assert.That(_s3.CompleteRequests, Has.Count.EqualTo(1));

        using var zip = new ZipArchive(new MemoryStream(_s3.AssembleUploadedObject()), ZipArchiveMode.Read);

        Assert.That(zip.Entries, Is.Empty);
    }

    [Test]
    public async Task StampTheStagingSetFingerprint_OnTheInitiatedUpload()
    {
        var stagedFiles = new[] { StageFile("file.txt", Encoding.UTF8.GetBytes("content")) };

        await _writer.WriteAsync(stagedFiles, ZipFileKey, CancellationToken.None);

        Assert.That(
            _s3.InitiateRequests.Single().Metadata[ZipStorageConstants.StagingSetHashMetadataKey],
            Is.EqualTo(StagingSetFingerprint.Compute(stagedFiles)));
    }

    [Test]
    public async Task NotFindAnExistingArchive_WhenNoneWasUploaded()
    {
        _s3.Mock
            .Setup(s => s.GetObjectMetadataAsync(
                It.IsAny<GetObjectMetadataRequest>(), It.IsAny<CancellationToken>()))
            .ThrowsAsync(new AmazonS3Exception(
                "not found", ErrorType.Sender, "NotFound", "req", HttpStatusCode.NotFound));

        var uri = await _writer.FindExistingArchiveAsync(
            [StageFile("file.txt", [1])], ZipFileKey, CancellationToken.None);

        Assert.That(uri, Is.Null);
    }

    [Test]
    public async Task ReuseAnExistingArchive_OnlyWhenTheStagingSetMatches()
    {
        var stagedFiles = new[] { StageFile("file.txt", new byte[10]) };
        var metadataResponse = new GetObjectMetadataResponse();

        metadataResponse.Metadata.Add(
            ZipStorageConstants.StagingSetHashMetadataKey,
            StagingSetFingerprint.Compute(stagedFiles));

        _s3.Mock
            .Setup(s => s.GetObjectMetadataAsync(
                It.IsAny<GetObjectMetadataRequest>(), It.IsAny<CancellationToken>()))
            .ReturnsAsync(metadataResponse);

        var matchingUri = await _writer.FindExistingArchiveAsync(stagedFiles, ZipFileKey, CancellationToken.None);
        var differentSet = new[] { StageFile("file.txt", new byte[11]) };
        var mismatchUri = await _writer.FindExistingArchiveAsync(differentSet, ZipFileKey, CancellationToken.None);

        Assert.That(matchingUri, Is.EqualTo(new Uri($"s3://{BucketName}/{ZipFileKey}")));
        Assert.That(mismatchUri, Is.Null);
    }

    [Test]
    public void AbortTheUpload_AndNotRetryTheDownload_WhenAPartUploadFails()
    {
        // Big enough for the first part to fill (and its upload to start) mid-entry.
        var stagedFile = StageFile("big-blob.zip", RandomBytes(2 * PartSizeInMegabytes * 1024 * 1024));

        _s3.UploadPartFailure = _ => new AmazonS3Exception(
            "server error", ErrorType.Unknown, "InternalError", "req", HttpStatusCode.InternalServerError);

        var exception = Assert.ThrowsAsync<ZipGenerationException>(
            () => _writer.WriteAsync([stagedFile], ZipFileKey, CancellationToken.None));

        Assert.That(exception!.IsTransient, Is.True);
        Assert.That(_s3.AbortRequests, Has.Count.EqualTo(1));
        Assert.That(_s3.CompleteRequests, Is.Empty);

        // The failed part upload surfaces through the zip entry write; it must fail the
        // archive immediately rather than being retried as a staged file download.
        Assert.That(_s3.GetRequests.Count(r => r.Key == stagedFile.Key), Is.EqualTo(1));
    }

    [Test]
    public void AbortTheUpload_WhenAStagedFileIsSmallerThanListed()
    {
        var stagedFile = new StagedFile($"{StagingPrefix}file.txt", 100, "file.txt");

        _s3.AddObject(stagedFile.Key, new byte[50]);

        var exception = Assert.ThrowsAsync<ZipGenerationException>(
            () => _writer.WriteAsync([stagedFile], ZipFileKey, CancellationToken.None));

        Assert.That(exception!.IsTransient, Is.False);
        Assert.That(_s3.AbortRequests, Has.Count.EqualTo(1));
        Assert.That(_s3.CompleteRequests, Is.Empty);
    }

    [Test]
    public void AbortTheUpload_WhenTheCancellationTokenIsCancelledMidArchive()
    {
        var content = RandomBytes(2 * PartSizeInMegabytes * 1024 * 1024);
        var stagedFile = StageFile("big-blob.zip", content);

        using var cancellationTokenSource = new CancellationTokenSource();

        _s3.SetResponseStreamFactory(
            stagedFile.Key,
            body => new CancellingReadStream(body, body.Length / 4, cancellationTokenSource));

        Assert.CatchAsync<OperationCanceledException>(
            () => _writer.WriteAsync([stagedFile], ZipFileKey, cancellationTokenSource.Token));

        Assert.That(_s3.AbortRequests, Has.Count.EqualTo(1));
        Assert.That(_s3.CompleteRequests, Is.Empty);
    }

    private StagedFile StageFile(string entryName, byte[] content)
    {
        var key = $"{StagingPrefix}{entryName}";

        _s3.AddObject(key, content);

        return new StagedFile(key, content.Length, entryName);
    }

    private static byte[] RandomBytes(int count)
    {
        var bytes = new byte[count];

        RandomNumberGenerator.Fill(bytes);

        return bytes;
    }

    private static byte[] ReadEntry(ZipArchive zip, string entryName)
    {
        using var entryStream = zip.GetEntry(entryName)!.Open();
        using var content = new MemoryStream();

        entryStream.CopyTo(content);

        return content.ToArray();
    }
}
