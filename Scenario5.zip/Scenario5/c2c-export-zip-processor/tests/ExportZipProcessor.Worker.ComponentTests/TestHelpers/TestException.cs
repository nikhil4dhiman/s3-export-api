using ExportZipProcessor.Domain.Exceptions;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers;

internal class TestException : ProcessingException
{
    public TestException(string message)
        : base(message)
    {
    }
}
