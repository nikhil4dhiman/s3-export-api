using ExportZipProcessor.Domain.Helpers;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.Models;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers;

/// <summary>
/// The archive key and name a payload should produce. These tests cover the generation flow
/// rather than the naming convention itself, so they derive both the same way production does;
/// the convention is pinned by ZipFileHelperTests with literal expectations.
/// </summary>
internal static class TestZipFileNamer
{
    public static string BuildZipFileKey(ZipGenerationRequestedEventPayload payload)
    {
        return ZipFileHelper.BuildZipFileKey(payload.ExportId, BuildZipFileName(payload));
    }

    /// <summary>The name registered with Downloads Proxy, which the archive name feeds.</summary>
    public static string BuildDownloadFileName(ZipGenerationRequestedEventPayload payload)
    {
        return ZipFileHelper.BuildDownloadFileName(payload.ExportId, BuildZipFileName(payload));
    }

    private static string BuildZipFileName(ZipGenerationRequestedEventPayload payload)
    {
        var zipGenerationInfo = new ZipGenerationInfo
        {
            ExportId = payload.ExportId,
            PartnerId = payload.PartnerId,
            SourceName = payload.SourceName,
            SourceType = payload.SourceType,
            ZipRequestedAt = payload.ZipRequestedAt
        };

        return ZipFileHelper.BuildZipFileName(zipGenerationInfo);
    }
}
