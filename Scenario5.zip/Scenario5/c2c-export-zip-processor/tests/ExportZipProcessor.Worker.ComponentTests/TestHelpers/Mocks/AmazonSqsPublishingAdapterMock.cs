using System.Collections.Generic;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS.Model;
using ExportZipProcessor.Data.SqsPublisher.Adapters;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;

internal class AmazonSqsPublishingAdapterMock : IAmazonSqsPublishingAdapter
{
    private bool _shouldThrowException;

    public List<SendMessageRequest> SentRequests { get; } = [];

    public void WillThrowException()
    {
        _shouldThrowException = true;
    }

    Task<SendMessageResponse> IAmazonSqsPublishingAdapter.SendMessageAsync(
        SendMessageRequest request,
        CancellationToken cancellationToken)
    {
        if (_shouldThrowException)
        {
            throw new TestException("unexpected exception from results queue");
        }

        SentRequests.Add(request);

        return Task.FromResult(new SendMessageResponse { MessageId = "test-message-id" });
    }

    public static JsonNode GetEventData(SendMessageRequest request)
    {
        return JsonNode.Parse(request.MessageBody)!["data"]!;
    }
}
