namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;

internal class Mocks
{
    public FooApiClientMock FooApiClient { get; } = new();

    public DownloadsProxyApiAdapterMock DownloadsProxyApi { get; } = new();

    public StagedFilesStorageMock StagedFilesStorage { get; } = new();

    public ZipArchiveWriterMock ZipArchiveWriter { get; } = new();

    public AmazonSqsPublishingAdapterMock AmazonSqsPublishingAdapter { get; } = new();

    public MetricsServiceMock MetricsService { get; } = new();
}
