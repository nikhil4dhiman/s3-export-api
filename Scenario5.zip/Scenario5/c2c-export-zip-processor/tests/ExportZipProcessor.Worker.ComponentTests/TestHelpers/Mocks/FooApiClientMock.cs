using System;
using System.Collections.Generic;
using System.Net;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ApiClients.Exceptions;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipProcessor.Domain.ApiClients;
using ExportZipProcessor.Domain.Models;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;

internal class FooApiClientMock : IFooApiClient
{
    private readonly Dictionary<string, string> _requestToIdMap = [];

    private bool _shouldThrowAnError;

    public int TotalCallsCount { get; private set; }

    public void WillReturnIdForFooInfo(FooInfo fooInfo, string id)
    {
        _requestToIdMap[JsonSerializer.Serialize(fooInfo)] = id;
    }

    public void WillThrowAnError()
    {
        _shouldThrowAnError = true;
    }

    Task<string> IFooApiClient.PostAsync(FooInfo fooInfo, CancellationToken cancellationToken)
    {
        TotalCallsCount += 1;

        if (_shouldThrowAnError)
        {
            var exception = new ApiException(
                nameof(FooApiClientMock),
                new Uri("https://component-tests-foo-api.com"),
                HttpStatusCode.InternalServerError,
                "some error");

            return Task.FromException<string>(exception);
        }

        if (_requestToIdMap.TryGetValue(JsonSerializer.Serialize(fooInfo), out var taskId))
        {
            return Task.FromResult(taskId);
        }

        return Task.FromResult(Generate.RandomString());
    }
}
