using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Domain.Exceptions;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Domain.Storage;
using ExportZipProcessor.Worker.ComponentTests.Framework.Constants;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;

internal class ZipArchiveWriterMock : IZipArchiveWriter
{
    private readonly HashSet<string> _existingZipFileKeys = [];

    private Exception? _exceptionToThrow;

    public List<string> WrittenZipFileKeys { get; } = [];

    public void WillThrowException()
    {
        _exceptionToThrow = new TestException("unexpected exception from zip archive writer");
    }

    public void WillThrowTransientException()
    {
        _exceptionToThrow = new ZipGenerationException(
            "transient exception from zip archive writer",
            new TestException("connection reset"),
            isTransient: true);
    }

    public void WillThrowUnexpectedException()
    {
        _exceptionToThrow = new InvalidCastException("unexpected infrastructure failure");
    }

    public void WillHaveExistingArchive(string zipFileKey)
    {
        _existingZipFileKeys.Add(zipFileKey);
    }

    Task<Uri?> IZipArchiveWriter.FindExistingArchiveAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        string zipFileKey,
        CancellationToken cancellationToken)
    {
        return Task.FromResult(_existingZipFileKeys.Contains(zipFileKey)
            ? ZipUri(zipFileKey)
            : null);
    }

    Task<ZipArchiveInfo> IZipArchiveWriter.WriteAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        string zipFileKey,
        CancellationToken cancellationToken)
    {
        if (_exceptionToThrow is not null)
        {
            return Task.FromException<ZipArchiveInfo>(_exceptionToThrow);
        }

        WrittenZipFileKeys.Add(zipFileKey);

        return Task.FromResult(new ZipArchiveInfo(ZipUri(zipFileKey), ZipArchiveTestConstants.ZipArchiveSizeInBytes));
    }

    private static Uri ZipUri(string zipFileKey)
    {
        return new Uri($"s3://{ZipArchiveTestConstants.ZipBucketName}/{zipFileKey}");
    }
}
