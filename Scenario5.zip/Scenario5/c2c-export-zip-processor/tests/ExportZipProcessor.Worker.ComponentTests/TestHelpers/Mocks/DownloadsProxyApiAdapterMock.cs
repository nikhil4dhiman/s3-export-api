using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Data.DownloadsProxyApi.Adapters;
using ExportZipProcessor.Data.DownloadsProxyApi.Models;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;

internal class DownloadsProxyApiAdapterMock : IDownloadsProxyApiAdapter
{
    private readonly Dictionary<Uri, string> _fileIdByUrl = [];

    private bool _shouldThrowException;

    public List<CreateFileAssociationRequest> CreatedFileAssociations { get; } = [];

    public void WillReturnFileIdForUrl(Uri fileUrl, string fileId)
    {
        _fileIdByUrl.Add(fileUrl, fileId);
    }

    public void WillThrowException()
    {
        _shouldThrowException = true;
    }

    Task<CreateFileAssociationResponse> IDownloadsProxyApiAdapter.PostCreateFileAssociationRequestAsync(
        CreateFileAssociationRequest request,
        CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        CreatedFileAssociations.Add(request);

        var fileUrl = new Uri(request.File.Url);
        if (!_fileIdByUrl.TryGetValue(fileUrl, out var fileId))
        {
            throw new InvalidOperationException($"test helper not set up for {fileUrl}");
        }

        return Task.FromResult(new CreateFileAssociationResponse { FileId = fileId });
    }

    private void ThrowExceptionIfRequired()
    {
        if (_shouldThrowException)
        {
            throw new TestException("unexpected exception from DownloadsProxyApi");
        }
    }
}
