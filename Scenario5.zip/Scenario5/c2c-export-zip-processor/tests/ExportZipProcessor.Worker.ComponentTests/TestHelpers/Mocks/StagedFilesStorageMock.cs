using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Domain.Storage;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;

internal class StagedFilesStorageMock : IStagedFilesStorage
{
    private readonly Dictionary<string, List<StagedFile>> _stagedFilesByPrefix = [];

    public List<StagedFile> DeletedFiles { get; } = [];

    public void WillReturnStagedFilesForPrefix(string stagingPrefix, params StagedFile[] stagedFiles)
    {
        _stagedFilesByPrefix[stagingPrefix] = [.. stagedFiles];
    }

    Task<IReadOnlyList<StagedFile>> IStagedFilesStorage.ListStagedFilesAsync(
        string stagingPrefix,
        CancellationToken cancellationToken)
    {
        var stagedFiles = _stagedFilesByPrefix.GetValueOrDefault(stagingPrefix, []);

        return Task.FromResult<IReadOnlyList<StagedFile>>(stagedFiles);
    }

    Task IStagedFilesStorage.DeleteStagedFilesAsync(
        IReadOnlyList<StagedFile> stagedFiles,
        CancellationToken cancellationToken)
    {
        DeletedFiles.AddRange(stagedFiles);

        return Task.CompletedTask;
    }
}
