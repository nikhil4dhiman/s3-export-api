using System.Collections.Generic;
using ExportZipProcessor.Domain.Metrics;

namespace ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;

/// <summary>
/// Records the observations made during a scenario so tests can assert on them. Counters are
/// recorded too, so a test can state that nothing at all was measured on a given path.
/// </summary>
internal class MetricsServiceMock : IMetricsService
{
    public List<(string Result, double DurationInSeconds)> ObservedZipGenerationDurations { get; } = [];

    public List<long> ObservedZipArchiveSizes { get; } = [];

    public List<long> ObservedStagedFilesSizes { get; } = [];

    public List<string> ZipGenerationEventsProcessed { get; } = [];

    public List<string> DownloadsProxyApiErrors { get; } = [];

    public List<(string Result, string State)> ResultEventsPublished { get; } = [];

    void IMetricsService.IncreaseNumberOfDownloadsProxyApiErrors(string result)
    {
        DownloadsProxyApiErrors.Add(result);
    }

    void IMetricsService.IncreaseNumberOfZipGenerationEventsProcessed(string result)
    {
        ZipGenerationEventsProcessed.Add(result);
    }

    void IMetricsService.IncreaseNumberOfResultEventsPublished(string result, string state)
    {
        ResultEventsPublished.Add((result, state));
    }

    void IMetricsService.ObserveZipGenerationDuration(string result, double durationInSeconds)
    {
        ObservedZipGenerationDurations.Add((result, durationInSeconds));
    }

    void IMetricsService.ObserveZipArchiveSize(long sizeInBytes)
    {
        ObservedZipArchiveSizes.Add(sizeInBytes);
    }

    void IMetricsService.ObserveStagedFilesSize(long sizeInBytes)
    {
        ObservedStagedFilesSizes.Add(sizeInBytes);
    }
}
