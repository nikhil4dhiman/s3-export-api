using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.ComponentTests.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Given.FooApi;

internal class AFooApiStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> WillReturnIdForFooInfo(FooInfo fooInfo, string id)
    {
        Scenario.Mocks.FooApiClient.WillReturnIdForFooInfo(fooInfo, id);

        return AndStep;
    }

    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Mocks.FooApiClient.WillThrowAnError();

        return AndStep;
    }
}
