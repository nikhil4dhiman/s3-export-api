using System;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Given.DownloadsProxyApi;

internal class ADownloadsProxyApiStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> WillReturnFileIdForUrl(Uri uri, string fileId)
    {
        Scenario.Mocks.DownloadsProxyApi.WillReturnFileIdForUrl(uri, fileId);

        return AndStep;
    }

    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Mocks.DownloadsProxyApi.WillThrowException();

        return AndStep;
    }
}
