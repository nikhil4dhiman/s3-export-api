using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Given.EventsPublishing;

internal class AResultsQueueStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Mocks.AmazonSqsPublishingAdapter.WillThrowException();

        return AndStep;
    }
}
