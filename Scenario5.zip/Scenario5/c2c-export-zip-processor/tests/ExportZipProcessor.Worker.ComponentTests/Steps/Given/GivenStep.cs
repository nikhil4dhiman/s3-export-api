using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using ExportZipProcessor.Worker.ComponentTests.Steps.Given.DownloadsProxyApi;
using ExportZipProcessor.Worker.ComponentTests.Steps.Given.EventsPublishing;
using ExportZipProcessor.Worker.ComponentTests.Steps.Given.FooApi;
using ExportZipProcessor.Worker.ComponentTests.Steps.Given.Storage;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Given;

internal class GivenStep : RootStep<GivenStep, Scenario>
{
    public AFooApiStep AFooApi => StepFactory<AFooApiStep>();

    public ADownloadsProxyApiStep ADownloadsProxyApi => StepFactory<ADownloadsProxyApiStep>();

    public AStagingBucketStep AStagingBucket => StepFactory<AStagingBucketStep>();

    public AZipArchiveWriterStep AZipArchiveWriter => StepFactory<AZipArchiveWriterStep>();

    public AResultsQueueStep AResultsQueue => StepFactory<AResultsQueueStep>();
}
