using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Given.Storage;

internal class AZipArchiveWriterStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Mocks.ZipArchiveWriter.WillThrowException();

        return AndStep;
    }

    public IAnd<GivenStep> FailsTransiently()
    {
        Scenario.Mocks.ZipArchiveWriter.WillThrowTransientException();

        return AndStep;
    }

    public IAnd<GivenStep> HasAlreadyWrittenZip(string zipFileKey)
    {
        Scenario.Mocks.ZipArchiveWriter.WillHaveExistingArchive(zipFileKey);

        return AndStep;
    }

    public IAnd<GivenStep> FailsUnexpectedly()
    {
        Scenario.Mocks.ZipArchiveWriter.WillThrowUnexpectedException();

        return AndStep;
    }
}
