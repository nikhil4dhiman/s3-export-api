using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.ComponentTests.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Given.Storage;

internal class AStagingBucketStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> HasStagedFilesForPrefix(string stagingPrefix, params StagedFile[] stagedFiles)
    {
        Scenario.Mocks.StagedFilesStorage.WillReturnStagedFilesForPrefix(stagingPrefix, stagedFiles);

        return AndStep;
    }
}
