using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.When.Sqs;

internal class AnAmazonSqsStep : Step<WhenStep, Scenario>
{
    public GenerationRequestedMessagesStep GenerationRequestedMessages
        => StepFactory<GenerationRequestedMessagesStep>();
}
