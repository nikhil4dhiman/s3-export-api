using System;
using System.Threading.Tasks;
using Amazon.SQS.Model;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.When.Sqs;

internal class GenerationRequestedMessagesStep : Step<WhenStep, Scenario>
{
    public IAnd<WhenStep> AreProcessed(params Message[] messages)
    {
        Scenario.AmazonSqsTransport.WaitForProcessingAsync(messages).GetAwaiter().GetResult();

        var deadline = DateTimeOffset.UtcNow.AddSeconds(10);
        while (Scenario.AmazonSqsTransport.DeleteMessageRequests.Count < messages.Length
               && DateTimeOffset.UtcNow <= deadline)
        {
            Task.Delay(TimeSpan.FromMilliseconds(100)).GetAwaiter().GetResult();
        }

        return Scenario.AmazonSqsTransport.DeleteMessageRequests.Count < messages.Length
            ? throw new TimeoutException("Timed out waiting for SQS messages to be deleted.")
            : (IAnd<WhenStep>)AndStep;
    }

    /// <summary>
    /// Waits for the messages to be handled without expecting them to be deleted from the
    /// queue, for scenarios where processing schedules a retry instead of completing.
    /// </summary>
    public IAnd<WhenStep> AreAttempted(params Message[] messages)
    {
        Scenario.AmazonSqsTransport.WaitForProcessingAsync(messages).GetAwaiter().GetResult();

        return AndStep;
    }
}
