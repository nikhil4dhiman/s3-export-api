using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using ExportZipProcessor.Worker.ComponentTests.Steps.When.Sqs;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.When;

internal class WhenStep : RootStep<WhenStep, Scenario>
{
    public AnAmazonSqsStep AnAmazonSqs => StepFactory<AnAmazonSqsStep>();
}
