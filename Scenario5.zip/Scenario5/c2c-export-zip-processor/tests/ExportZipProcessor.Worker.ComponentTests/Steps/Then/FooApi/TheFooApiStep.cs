using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.FooApi;

internal class TheFooApiStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillNotBeCalled()
    {
        Scenario.Mocks.FooApiClient.TotalCallsCount.Should().Be(0);

        return AndStep;
    }
}
