using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.DownloadsProxyApi;

internal class TheDownloadsProxyApiStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHaveCreatedFileAssociationNamed(string fileName)
    {
        Scenario.Mocks.DownloadsProxyApi.CreatedFileAssociations.Should().ContainSingle()
            .Which.File.Name.Should().Be(fileName);

        return AndStep;
    }
}
