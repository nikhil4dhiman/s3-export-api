using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using Cove.Platform.Extensions.Testing.SharedHelpers.Logging;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then.DownloadsProxyApi;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then.EventProcessing;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then.EventsPublishing;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then.FooApi;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then.Metrics;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then.Sqs;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then.Storage;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then;

internal class ThenStep : RootStep<ThenStep, Scenario>
{
    public TheEventsProcessingStep TheEventsProcessing => StepFactory<TheEventsProcessingStep>();

    public ApplicationLogsStep<ThenStep, Scenario> ApplicationLogs
        => StepFactory<ApplicationLogsStep<ThenStep, Scenario>>();

    public TheFooApiStep TheFooApi => StepFactory<TheFooApiStep>();

    public TheAmazonSqsStep TheAmazonSqs => StepFactory<TheAmazonSqsStep>();

    public TheDownloadsProxyApiStep TheDownloadsProxyApi => StepFactory<TheDownloadsProxyApiStep>();

    public TheZipStorageStep TheZipStorage => StepFactory<TheZipStorageStep>();

    public TheResultEventsStep TheResultEvents => StepFactory<TheResultEventsStep>();

    public TheMetricsStep TheMetrics => StepFactory<TheMetricsStep>();
}
