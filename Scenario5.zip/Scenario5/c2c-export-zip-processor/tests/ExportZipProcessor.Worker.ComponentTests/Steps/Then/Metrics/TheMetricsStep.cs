using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Domain.Metrics;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.Metrics;

internal class TheMetricsStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHaveObservedSuccessfulZipGeneration(long stagedFilesSize, long zipArchiveSize)
    {
        Scenario.Mocks.MetricsService.ObservedZipGenerationDurations.Should().ContainSingle()
            .Which.Result.Should().Be(MetricLabelValues.Result.Processed);

        Scenario.Mocks.MetricsService.ObservedStagedFilesSizes.Should().ContainSingle()
            .Which.Should().Be(stagedFilesSize);

        Scenario.Mocks.MetricsService.ObservedZipArchiveSizes.Should().ContainSingle()
            .Which.Should().Be(zipArchiveSize);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveObservedFailedZipGeneration()
    {
        Scenario.Mocks.MetricsService.ObservedZipGenerationDurations.Should().ContainSingle()
            .Which.Result.Should().Be(MetricLabelValues.Result.Failed);

        // A failed attempt produced no archive, so there is nothing to size.
        Scenario.Mocks.MetricsService.ObservedStagedFilesSizes.Should().BeEmpty();
        Scenario.Mocks.MetricsService.ObservedZipArchiveSizes.Should().BeEmpty();

        return AndStep;
    }

    /// <summary>
    /// Asserts the de-duplication rule the business metrics depend on: an attempt that reused an
    /// archive a previous attempt already wrote did no generation work, so observing it would
    /// count the same export twice and skew every histogram.
    /// </summary>
    public IAnd<ThenStep> WillNotHaveObservedZipGeneration()
    {
        Scenario.Mocks.MetricsService.ObservedZipGenerationDurations.Should().BeEmpty();
        Scenario.Mocks.MetricsService.ObservedStagedFilesSizes.Should().BeEmpty();
        Scenario.Mocks.MetricsService.ObservedZipArchiveSizes.Should().BeEmpty();

        return AndStep;
    }
}
