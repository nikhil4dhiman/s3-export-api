using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.Storage;

internal class TheZipStorageStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHaveUploadedZip(string zipFileKey)
    {
        Scenario.Mocks.ZipArchiveWriter.WrittenZipFileKeys.Should().ContainSingle()
            .Which.Should().Be(zipFileKey);

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveUploadedZip()
    {
        Scenario.Mocks.ZipArchiveWriter.WrittenZipFileKeys.Should().BeEmpty();

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveDeletedStagedFiles()
    {
        Scenario.Mocks.StagedFilesStorage.DeletedFiles.Should().BeEmpty();

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveDeletedStagedFiles(params StagedFile[] stagedFiles)
    {
        Scenario.Mocks.StagedFilesStorage.DeletedFiles.Should().BeEquivalentTo(stagedFiles);

        return AndStep;
    }
}
