using System.Collections.Generic;
using System.Linq;
using System.Text.Json.Nodes;
using Amazon.SQS.Model;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using ExportZipProcessor.Worker.ComponentTests.Framework.Constants;
using ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.EventsPublishing;

internal class TheResultEventsStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHaveCompletedEvent(string exportId, string fileId)
    {
        var eventData = GetSingleEventData(exportId, expectedState: "Completed");

        eventData["resultDetails"]!["fileId"]!.GetValue<string>().Should().Be(fileId);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveFailedEventFor(string exportId)
    {
        var eventData = GetSingleEventData(exportId, expectedState: "Failed");

        eventData["resultDetails"]!["errorMessage"]!.GetValue<string>().Should().NotBeEmpty();

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveCompletedEvent()
    {
        AllEventStates().Should().NotContain("Completed");

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveFailedEvent()
    {
        AllEventStates().Should().NotContain("Failed");

        return AndStep;
    }

    private JsonNode GetSingleEventData(string exportId, string expectedState)
    {
        var request = Scenario.Mocks.AmazonSqsPublishingAdapter.SentRequests.Should().ContainSingle()
            .Which;

        AssertFifoRequestProperties(request, exportId, expectedState);

        var eventData = AmazonSqsPublishingAdapterMock.GetEventData(request);

        eventData["id"]!.GetValue<string>().Should().Be(exportId);
        eventData["state"]!.GetValue<string>().Should().Be(expectedState);

        return eventData;
    }

    private static void AssertFifoRequestProperties(SendMessageRequest request, string exportId, string expectedState)
    {
        request.QueueUrl.Should().Be(EventProcessingTestConstants.ResultsQueueUrl);
        request.MessageGroupId.Should().Be(exportId);
        request.MessageDeduplicationId.Should().Be($"{exportId}-{expectedState}");
    }

    private IEnumerable<string> AllEventStates()
    {
        return Scenario.Mocks.AmazonSqsPublishingAdapter.SentRequests
            .Select(r => AmazonSqsPublishingAdapterMock.GetEventData(r)["state"]!.GetValue<string>());
    }
}
