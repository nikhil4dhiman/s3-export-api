using Amazon.SQS.Model;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.Sqs;

internal class TheTaskStateDlqStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHave(params Message[] messages)
    {
        Scenario.AmazonSqsTransport.SendMessageRequests.Count.Should().Be(messages.Length);

        foreach (var message in messages)
        {
            Scenario.AmazonSqsTransport.SendMessageRequests.Should()
                .ContainSingle(x => x.MessageBody == message.Body);
        }

        return AndStep;
    }

    public IAnd<ThenStep> WillBeEmpty()
    {
        Scenario.AmazonSqsTransport.SendMessageRequests.Should().BeEmpty();

        return AndStep;
    }
}
