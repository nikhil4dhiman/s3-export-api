using System;
using System.Linq;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.Sqs;

internal class TheAmazonSqsStep : Step<ThenStep, Scenario>
{
    public TheTaskStateDlqStep TaskStateDlq => StepFactory<TheTaskStateDlqStep>();

    public IAnd<ThenStep> WillHaveScheduledMessageRetry(TimeSpan delay)
    {
        var deadline = DateTimeOffset.UtcNow.AddSeconds(10);
        while (Scenario.AmazonSqsTransport.ChangeMessageVisibilityRequests.All(r
                   => r.VisibilityTimeout != (int)delay.TotalSeconds)
               && DateTimeOffset.UtcNow <= deadline)
        {
            Task.Delay(TimeSpan.FromMilliseconds(100)).GetAwaiter().GetResult();
        }

        Scenario.AmazonSqsTransport.ChangeMessageVisibilityRequests.Should()
            .Contain(r => r.VisibilityTimeout == (int)delay.TotalSeconds);

        return AndStep;
    }
}
