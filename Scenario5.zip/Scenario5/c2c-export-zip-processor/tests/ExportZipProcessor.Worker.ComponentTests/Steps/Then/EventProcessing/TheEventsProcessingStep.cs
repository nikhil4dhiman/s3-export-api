using System;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipProcessor.Worker.ComponentTests.Steps.Then.EventProcessing;

internal class TheEventsProcessingStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillSucceed()
    {
        Scenario.ThrownException.Should().BeNull();

        return AndStep;
    }

    public IAnd<ThenStep> WillFailWithException(Exception exception)
    {
        Scenario.ThrownException.Should().NotBeNull();

        Scenario.ThrownException!.Message.Should().Be(exception.Message);
        Scenario.ThrownException!.GetType().Should().Be(exception.GetType());

        return AndStep;
    }
}
