using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using NUnit.Framework;

[assembly: FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
[assembly: Parallelizable(ParallelScope.Children)]

namespace ExportZipProcessor.Worker.ComponentTests.Tests;

[SetUpFixture]
internal class TestSuiteSetup : ApplicationTestSuiteSetupBase;
