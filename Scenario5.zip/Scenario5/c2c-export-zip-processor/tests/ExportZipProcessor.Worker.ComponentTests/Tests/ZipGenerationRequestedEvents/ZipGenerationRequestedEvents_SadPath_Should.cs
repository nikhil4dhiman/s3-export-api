using System;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using ExportZipProcessor.Worker.ComponentTests.Framework.Constants;
using ExportZipProcessor.Worker.ComponentTests.TestHelpers;
using ExportZipProcessor.Worker.Tests.Core.Builders.ZipGenerationRequestedEvent;
using NUnit.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Tests.ZipGenerationRequestedEvents;

[TestFixture]
internal class ZipGenerationRequestedEvents_SadPath_Should : TestFixtureBase
{
    [Test]
    public void SendMessageToDlqIfPayloadIsInvalid()
    {
        var message = new ZipGenerationRequestedEventBuilder()
            .WithInvalidData()
            .Build();

        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheAmazonSqs.TaskStateDlq.WillHave(message)
            .And.TheResultEvents.WillNotHaveCompletedEvent()
            .And.TheResultEvents.WillNotHaveFailedEvent();
    }

    [Test]
    public void SendMessageToDlqIfDownloadsProxyIsUnavailable()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var stagingPrefix = $"exports/{eventPayload.ExportId}/staging/";
        var stagedFileName = $"{Generate.RandomString()}.csv";

        Given.AStagingBucket.HasStagedFilesForPrefix(
                stagingPrefix,
                new StagedFile($"{stagingPrefix}{stagedFileName}", 1024, stagedFileName))
            .And.ADownloadsProxyApi.IsUnavailable();
        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheAmazonSqs.TaskStateDlq.WillHave(message)
            .And.TheResultEvents.WillHaveFailedEventFor(eventPayload.ExportId);
    }

    [Test]
    public void SendMessageToDlqIfZipUploadFails()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var stagingPrefix = $"exports/{eventPayload.ExportId}/staging/";
        var stagedFileName = $"{Generate.RandomString()}.csv";

        Given.AStagingBucket.HasStagedFilesForPrefix(
                stagingPrefix,
                new StagedFile($"{stagingPrefix}{stagedFileName}", 1024, stagedFileName))
            .And.AZipArchiveWriter.IsUnavailable();
        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheAmazonSqs.TaskStateDlq.WillHave(message)
            .And.TheZipStorage.WillNotHaveUploadedZip()
            .And.TheZipStorage.WillNotHaveDeletedStagedFiles()
            .And.TheResultEvents.WillHaveFailedEventFor(eventPayload.ExportId)
            .And.TheMetrics.WillHaveObservedFailedZipGeneration();
    }

    [Test]
    public void SendMessageToDlqIfZipUploadFailsUnexpectedly()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var stagingPrefix = $"exports/{eventPayload.ExportId}/staging/";
        var stagedFileName = $"{Generate.RandomString()}.csv";

        Given.AStagingBucket.HasStagedFilesForPrefix(
                stagingPrefix,
                new StagedFile($"{stagingPrefix}{stagedFileName}", 1024, stagedFileName))
            .And.AZipArchiveWriter.FailsUnexpectedly();
        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheAmazonSqs.TaskStateDlq.WillHave(message)
            .And.TheZipStorage.WillNotHaveUploadedZip()
            .And.TheZipStorage.WillNotHaveDeletedStagedFiles()
            .And.TheResultEvents.WillHaveFailedEventFor(eventPayload.ExportId);
    }

    [Test]
    public void RetryInsteadOfSendingToDlqIfZipUploadFailsTransiently()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var stagingPrefix = $"exports/{eventPayload.ExportId}/staging/";
        var stagedFileName = $"{Generate.RandomString()}.csv";

        Given.AStagingBucket.HasStagedFilesForPrefix(
                stagingPrefix,
                new StagedFile($"{stagingPrefix}{stagedFileName}", 1024, stagedFileName))
            .And.AZipArchiveWriter.FailsTransiently();
        When.AnAmazonSqs.GenerationRequestedMessages.AreAttempted(message);
        Then.TheAmazonSqs.TaskStateDlq.WillBeEmpty()
            .And.TheAmazonSqs.WillHaveScheduledMessageRetry(TimeSpan.FromMinutes(1))
            .And.TheZipStorage.WillNotHaveDeletedStagedFiles()
            .And.TheResultEvents.WillHaveFailedEventFor(eventPayload.ExportId)
            .And.TheMetrics.WillHaveObservedFailedZipGeneration();
    }

    [Test]
    public void SendMessageToDlqWithoutPublishingFailedEventIfResultsQueueIsUnavailable()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var stagingPrefix = $"exports/{eventPayload.ExportId}/staging/";
        var zipFileKey = TestZipFileNamer.BuildZipFileKey(eventPayload);
        var fileUrl = new Uri($"s3://{ZipArchiveTestConstants.ZipBucketName}/{zipFileKey}");

        var stagedFileName = $"{Generate.RandomString()}.csv";
        var stagedFile = new StagedFile($"{stagingPrefix}{stagedFileName}", 1024, stagedFileName);
        var fileId = Generate.RandomString();

        Given.AStagingBucket.HasStagedFilesForPrefix(stagingPrefix, stagedFile)
            .And.ADownloadsProxyApi.WillReturnFileIdForUrl(fileUrl, fileId)
            .And.AResultsQueue.IsUnavailable();
        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheAmazonSqs.TaskStateDlq.WillHave(message)
            .And.TheZipStorage.WillHaveUploadedZip(zipFileKey)
            .And.TheResultEvents.WillNotHaveCompletedEvent()
            .And.TheResultEvents.WillNotHaveFailedEvent();
    }
}
