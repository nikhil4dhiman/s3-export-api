using System;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipProcessor.Domain.Models;
using ExportZipProcessor.Worker.ComponentTests.Framework;
using ExportZipProcessor.Worker.ComponentTests.Framework.Constants;
using ExportZipProcessor.Worker.ComponentTests.TestHelpers;
using ExportZipProcessor.Worker.Tests.Core.Builders.ZipGenerationRequestedEvent;
using NUnit.Framework;

namespace ExportZipProcessor.Worker.ComponentTests.Tests.ZipGenerationRequestedEvents;

[TestFixture]
internal class ZipGenerationRequestedEvents_HappyPath_Should : TestFixtureBase
{
    [Test]
    public void ProcessEvent()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var stagingPrefix = $"exports/{eventPayload.ExportId}/staging/";
        var zipFileKey = TestZipFileNamer.BuildZipFileKey(eventPayload);
        var fileUrl = new Uri($"s3://{ZipArchiveTestConstants.ZipBucketName}/{zipFileKey}");

        var stagedFileName = $"{Generate.RandomString()}.csv";
        var stagedFile = new StagedFile($"{stagingPrefix}{stagedFileName}", 1024, stagedFileName);
        var fileId = Generate.RandomString();

        Given.AStagingBucket.HasStagedFilesForPrefix(stagingPrefix, stagedFile)
            .And.ADownloadsProxyApi.WillReturnFileIdForUrl(fileUrl, fileId);
        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheEventsProcessing.WillSucceed()
            .And.TheZipStorage.WillHaveUploadedZip(zipFileKey)
            .And.TheZipStorage.WillHaveDeletedStagedFiles(stagedFile)
            .And.TheDownloadsProxyApi.WillHaveCreatedFileAssociationNamed(TestZipFileNamer.BuildDownloadFileName(eventPayload))
            .And.TheResultEvents.WillHaveCompletedEvent(eventPayload.ExportId, fileId)
            .And.TheMetrics.WillHaveObservedSuccessfulZipGeneration(
                stagedFilesSize: stagedFile.Size,
                zipArchiveSize: ZipArchiveTestConstants.ZipArchiveSizeInBytes);
    }

    [Test]
    public void ProcessEventWithNoStagedFiles()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var zipFileKey = TestZipFileNamer.BuildZipFileKey(eventPayload);
        var fileUrl = new Uri($"s3://{ZipArchiveTestConstants.ZipBucketName}/{zipFileKey}");
        var fileId = Generate.RandomString();

        Given.ADownloadsProxyApi.WillReturnFileIdForUrl(fileUrl, fileId);
        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheEventsProcessing.WillSucceed()
            .And.TheZipStorage.WillHaveUploadedZip(zipFileKey)
            .And.TheZipStorage.WillNotHaveDeletedStagedFiles()
            .And.TheDownloadsProxyApi.WillHaveCreatedFileAssociationNamed(TestZipFileNamer.BuildDownloadFileName(eventPayload))
            .And.TheResultEvents.WillHaveCompletedEvent(eventPayload.ExportId, fileId)
            .And.TheMetrics.WillHaveObservedSuccessfulZipGeneration(
                stagedFilesSize: 0,
                zipArchiveSize: ZipArchiveTestConstants.ZipArchiveSizeInBytes);
    }

    [Test]
    public void ReuseExistingZipWithoutRegeneratingIt()
    {
        var eventPayload = new ZipGenerationRequestedEventPayloadBuilder()
            .WithRandomValues()
            .Build();

        var message = new ZipGenerationRequestedEventBuilder()
            .WithData(eventPayload)
            .Build();

        var stagingPrefix = $"exports/{eventPayload.ExportId}/staging/";
        var zipFileKey = TestZipFileNamer.BuildZipFileKey(eventPayload);
        var fileUrl = new Uri($"s3://{ZipArchiveTestConstants.ZipBucketName}/{zipFileKey}");

        var stagedFileName = $"{Generate.RandomString()}.csv";
        var stagedFile = new StagedFile($"{stagingPrefix}{stagedFileName}", 1024, stagedFileName);
        var fileId = Generate.RandomString();

        Given.AStagingBucket.HasStagedFilesForPrefix(stagingPrefix, stagedFile)
            .And.AZipArchiveWriter.HasAlreadyWrittenZip(zipFileKey)
            .And.ADownloadsProxyApi.WillReturnFileIdForUrl(fileUrl, fileId);
        When.AnAmazonSqs.GenerationRequestedMessages.AreProcessed(message);
        Then.TheEventsProcessing.WillSucceed()
            .And.TheZipStorage.WillNotHaveUploadedZip()
            .And.TheZipStorage.WillHaveDeletedStagedFiles(stagedFile)
            .And.TheResultEvents.WillHaveCompletedEvent(eventPayload.ExportId, fileId)
            .And.TheMetrics.WillNotHaveObservedZipGeneration();
    }
}
