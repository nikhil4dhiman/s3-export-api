using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration;
using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration.Builders;
using ExportZipProcessor.Data.SqsPublisher.Configuration;
using ExportZipProcessor.Worker.ComponentTests.Framework.Constants;
using ExportZipProcessor.Worker.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace ExportZipProcessor.Worker.ComponentTests.Framework;

internal class ApplicationConfigurationOverride : IApplicationConfigurationOverride
{
    public void Apply(IConfigurationBuilder builder, IHostEnvironment environment)
    {
        var configuration = new InMemoryConfigurationBuilder()
            .ForOptions<EventsProcessingOptions>(configure => configure
                .WithValue(o => o.QueueUrl, EventProcessingTestConstants.QueueUrl)
                .WithValue(o => o.DeadLetterQueueUrl, EventProcessingTestConstants.DeadLetterQueueUrl))
            .ForOptions<EventsPublishingOptions>(configure => configure
                .WithValue(o => o.QueueUrl, EventProcessingTestConstants.ResultsQueueUrl))
            .Build();

        builder.AddInMemoryCollection(configuration!);
    }
}
