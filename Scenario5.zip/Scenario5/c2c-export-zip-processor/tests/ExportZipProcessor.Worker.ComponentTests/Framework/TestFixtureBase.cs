using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration;
using Cove.Platform.Extensions.Testing.SharedHelpers.DependencyInjection;
using ExportZipProcessor.Worker.ComponentTests.Steps.Given;
using ExportZipProcessor.Worker.ComponentTests.Steps.Then;
using ExportZipProcessor.Worker.ComponentTests.Steps.When;

namespace ExportZipProcessor.Worker.ComponentTests.Framework;

internal class TestFixtureBase : ApplicationTestFixtureBase<Program, GivenStep, WhenStep, ThenStep, Scenario>
{
    protected override IApplicationConfigurationOverride BuildConfigurationOverride()
    {
        return new ApplicationConfigurationOverride();
    }

    protected override IApplicationServicesOverride<Scenario> BuildServicesOverride()
    {
        return new ApplicationServicesOverride();
    }
}
