using System;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.Testing;
using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using ExportZipProcessor.Worker.ComponentTests.TestHelpers.Mocks;
using ExportZipProcessor.Worker.Constants;

namespace ExportZipProcessor.Worker.ComponentTests.Framework;

/// <summary>
/// Holds shared data that is scoped to the currently running test.
/// </summary>
/// <remarks>
/// <see cref="Scenario"/> class is defined as internal as it may hold references to internal classes from the SUT.
/// </remarks>
internal class Scenario : DefaultApplicationScenarioBase<Program>
{
    public Mocks Mocks => GetAndInitialiseIfNotSet<Mocks>(nameof(Mocks));

    public AmazonSqsTransportMock AmazonSqsTransport
        => Extensions.GetAmazonSqsTransportMockByKey(PipelineConstants.EventsProcessingPipeline);

    public Exception? ThrownException
    {
        get => ContextStore.Get<Exception?>(nameof(ThrownException));
        set => ContextStore.Set(nameof(ThrownException), value);
    }
}
