namespace ExportZipProcessor.Worker.ComponentTests.Framework.Constants;

internal static class EventProcessingTestConstants
{
    public const string QueueUrl = "c2c-export-zip-processor-events-test-queue.fifo";

    public const string DeadLetterQueueUrl = "c2c-export-zip-processor-events-test-dlq.fifo";

    public const string ResultsQueueUrl = "c2c-export-zip-manager-results-test-queue.fifo";
}
