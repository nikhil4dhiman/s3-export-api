namespace ExportZipProcessor.Worker.ComponentTests.Framework.Constants;

internal static class ZipArchiveTestConstants
{
    public const long ZipArchiveSizeInBytes = 4096;

    public const string ZipBucketName = "component-tests-bucket";
}
