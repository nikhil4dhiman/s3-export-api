using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.Testing;
using Cove.Platform.Extensions.Testing.SharedHelpers.DateTimeHandling;
using Cove.Platform.Extensions.Testing.SharedHelpers.DependencyInjection;
using Cove.Platform.Extensions.Testing.SharedHelpers.Logging;
using ExportZipProcessor.Data.DownloadsProxyApi.Adapters;
using ExportZipProcessor.Data.SqsPublisher.Adapters;
using ExportZipProcessor.Domain.ApiClients;
using ExportZipProcessor.Domain.Metrics;
using ExportZipProcessor.Domain.Storage;
using ExportZipProcessor.Worker.Constants;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipProcessor.Worker.ComponentTests.Framework;

internal class ApplicationServicesOverride : IApplicationServicesOverride<Scenario>
{
    public void Apply(IServiceCollection services, Scenario scenario)
    {
        services
            .AddScenario(scenario)
            .RemoveHealthCheckRegistrations()
            .OverrideLogger(scenario)
            .OverrideTimeProvider(scenario)
            .OverrideAmazonSqsTransport(scenario, PipelineConstants.EventsProcessingPipeline);
        ;

        services
            .AddScoped<IFooApiClient>(_ => scenario.Mocks.FooApiClient)
            .AddScoped<IDownloadsProxyApiAdapter>(_ => scenario.Mocks.DownloadsProxyApi)
            .AddScoped<IStagedFilesStorage>(_ => scenario.Mocks.StagedFilesStorage)
            .AddScoped<IZipArchiveWriter>(_ => scenario.Mocks.ZipArchiveWriter)
            .AddScoped<IAmazonSqsPublishingAdapter>(_ => scenario.Mocks.AmazonSqsPublishingAdapter)
            .AddSingleton<IMetricsService>(_ => scenario.Mocks.MetricsService);
    }
}
