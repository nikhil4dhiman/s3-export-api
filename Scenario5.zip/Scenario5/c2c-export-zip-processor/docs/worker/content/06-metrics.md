# Metrics

The service exposes Prometheus metrics on `/metrics` on the management port (see
[Environment](01-environment.md)), scraped through the `prometheus.io/*` pod annotations in
`deployment/deployment.yaml`. Every application metric is prefixed with
`c2c_export_zip_processor_`.

They are charted by the [Export Zip Processor dashboard](05-application-card.md#grafana).

## Business metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `c2c_export_zip_processor_zip_generation_duration_seconds` | histogram | `result` | Time taken to build an export zip archive from its staged files. |
| `c2c_export_zip_processor_zip_archive_size_bytes` | histogram | – | Size of a generated export zip archive. |
| `c2c_export_zip_processor_staged_files_size_bytes` | histogram | – | Total size of the staged files an archive was built from. |

All three are observed only when the current attempt actually generated the archive. A
redelivered message that reuses an archive a previous attempt already wrote does no
generation work, so observing it would count the same export twice and skew the histograms.
Because the size histograms cover exactly the same set of exports, the compression ratio is
derivable from them:

```promql
sum(rate(c2c_export_zip_processor_zip_archive_size_bytes_sum[$__rate_interval]))
/ sum(rate(c2c_export_zip_processor_staged_files_size_bytes_sum[$__rate_interval]))
```

`zip_generation_duration_seconds_count` doubles as the count of generation *attempts*, split
by outcome via its `result` label. Only `result="processed"` attempts produced an archive; a
`result="failed"` observation is recorded when writing threw, so it counts work attempted
rather than archives built.

The buckets span many orders of magnitude, because an export ranges from a handful of small
files finishing in seconds to terabytes streamed over several hours.

## Event processing metrics

| Metric | Type | Labels | Description |
|--------|------|--------|-------------|
| `c2c_export_zip_processor_zip_generation_events_processed_total` | counter | `result` | Zip generation events processed (`processed`, `retried`, `failed`). |
| `c2c_export_zip_processor_result_events_published_total` | counter | `result`, `state` | Result events published back to the manager. |
| `c2c_export_zip_processor_downloads_proxy_api_errors_total` | counter | `result` | Failures to create a download link for an archive that was generated successfully. |
