# Environment variables

| Name                                                                                | Description                                                                                                                              |
| ----------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| ASPNETCORE_URLS                                                                     | Indicates the IP addresses or host addresses with ports and protocols that the server should listen on for requests.                     |
| ASPNETCORE_ENVIRONMENT                                                              | Defines current runtime environment.                                                                                                     |
| ManagementPort                                                                      | A port on which health checks and metrics endpoints are exposed.                                                                         |
| FooApi__BaseUrl                                                                     | A URL to a dependent API.                                                                                                                |
| FooApi__TimeoutInSeconds                                                            | A Foo API request timeout in seconds.                                                                                                    |
| Tracing__ExporterEndpoint                                                           | An endpoint URL to the OpenTelemetry collector                                                                                           |
| Tracing__EnvironmentName                                                            | An environment name that is added to the OpenTelemetry tracing                                                                           |
