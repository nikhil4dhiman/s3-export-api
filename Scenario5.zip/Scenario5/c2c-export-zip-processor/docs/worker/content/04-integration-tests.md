# Setup integration tests

#### Create file `secrets.json`:

```json
{
  "FooApi:BaseUrl": "https://fooapi-katman"
}
```

The whole file with populated example values you can find in Vault by the path `vault:backup/data/services/export-zip/processor/tests#secrets-for-local-run`.

#### To set user secrets, run the following command:

```sh
cat secrets.json | dotnet user-secrets --project tests/ExportZipProcessor.Worker.IntegrationTests/ExportZipProcessor.Worker.IntegrationTests.csproj set
```

#### To set up an SSH tunnel, replace the placeholder and run the following command (under VPN):

```sh
ssh -Nn -L localhost:33070:DB_HOST:DB_PORT dev@bastion-eks.dev.bckp.io -i ~/.ssh/YOUR_SECRET_FILENAME
```

#### To run integration tests, run the following command:

```sh
dotnet test tests/ExportZipProcessor.Worker.IntegrationTests/ExportZipProcessor.Worker.IntegrationTests.csproj
```
