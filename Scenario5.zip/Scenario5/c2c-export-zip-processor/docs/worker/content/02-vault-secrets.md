# Vault secrets

## Location
vault:backup/data/services/export-zip/processor/<env_name>, where <env_name> is one of the following values: dev, coll, stg, prd

## Values

| Key Name                         | Description                                                      | Environment variable name                     |
|----------------------------------|------------------------------------------------------------------|-----------------------------------------------|
