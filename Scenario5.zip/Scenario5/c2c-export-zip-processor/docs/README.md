# Export Zip Processor

The service documentation can be found on BackStage.

## System
https://portal.n-able.dev/catalog/cove/system/c2c-export-zip

## Component
https://portal.n-able.dev/catalog/cove/component/c2c-export-zip-processor
