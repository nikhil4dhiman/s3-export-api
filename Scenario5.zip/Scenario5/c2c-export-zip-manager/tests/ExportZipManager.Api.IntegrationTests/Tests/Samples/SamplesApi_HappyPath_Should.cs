using ExportZipManager.Api.IntegrationTests.Framework;
using NUnit.Framework;

namespace ExportZipManager.Api.IntegrationTests.Tests.Samples;

[TestFixture]
internal class SamplesApi_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
    }

    [Test]
    public void Test1()
    {
        Assert.Pass();
    }
}
