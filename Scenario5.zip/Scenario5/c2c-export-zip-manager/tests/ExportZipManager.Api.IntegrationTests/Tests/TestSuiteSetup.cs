using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using NUnit.Framework;

[assembly: FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
[assembly: Parallelizable(ParallelScope.None)]

namespace ExportZipManager.Api.IntegrationTests.Tests;

[SetUpFixture]
internal class TestSuiteSetup : ApplicationTestSuiteSetupBase;
