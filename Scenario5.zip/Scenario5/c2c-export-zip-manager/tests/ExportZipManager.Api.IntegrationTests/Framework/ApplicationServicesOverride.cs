using Cove.Platform.Extensions.Testing.SharedHelpers.DateTimeHandling;
using Cove.Platform.Extensions.Testing.SharedHelpers.DependencyInjection;
using Cove.Platform.Extensions.Testing.SharedHelpers.Logging;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Api.IntegrationTests.Framework;

internal class ApplicationServicesOverride : IApplicationServicesOverride<Scenario>
{
    public void Apply(IServiceCollection services, Scenario scenario)
    {
        services
            .AddScenario(scenario)
            .RemoveHealthCheckRegistrations()
            .OverrideLogger(scenario)
            .OverrideTimeProvider(scenario);
    }
}
