using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration;
using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration.Builders;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace ExportZipManager.Api.IntegrationTests.Framework;

internal class ApplicationConfigurationOverride : IApplicationConfigurationOverride
{
    public void Apply(IConfigurationBuilder builder, IHostEnvironment environment)
    {
        var configuration = new InMemoryConfigurationBuilder()
            .Build();

        builder
            .AddInMemoryCollection(configuration!)
            .AddUserSecrets(typeof(ApplicationConfigurationOverride).Assembly);
    }
}
