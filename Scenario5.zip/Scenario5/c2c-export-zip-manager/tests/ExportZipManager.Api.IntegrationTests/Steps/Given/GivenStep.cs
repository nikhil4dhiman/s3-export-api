using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.IntegrationTests.Framework;

namespace ExportZipManager.Api.IntegrationTests.Steps.Given;

internal class GivenStep : RootStep<GivenStep, Scenario>;
