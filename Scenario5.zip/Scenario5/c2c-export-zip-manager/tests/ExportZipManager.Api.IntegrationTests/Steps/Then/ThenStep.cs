using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.IntegrationTests.Framework;

namespace ExportZipManager.Api.IntegrationTests.Steps.Then;

internal class ThenStep : RootStep<ThenStep, Scenario>;
