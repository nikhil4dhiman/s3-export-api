using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.IntegrationTests.Framework;

namespace ExportZipManager.Api.IntegrationTests.Steps.When;

internal class WhenStep : RootStep<WhenStep, Scenario>;
