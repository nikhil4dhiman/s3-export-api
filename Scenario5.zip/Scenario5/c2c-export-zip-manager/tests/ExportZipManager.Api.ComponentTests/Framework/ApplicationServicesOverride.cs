using Cove.Platform.Extensions.Identifiers.Testing;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.Testing;
using Cove.Platform.Extensions.Testing.SharedHelpers.Api.RequestsTracking;
using Cove.Platform.Extensions.Testing.SharedHelpers.DateTimeHandling;
using Cove.Platform.Extensions.Testing.SharedHelpers.DependencyInjection;
using Cove.Platform.Extensions.Testing.SharedHelpers.EntityFramework;
using Cove.Platform.Extensions.Testing.SharedHelpers.Logging;
using ExportZipManager.BackgroundServices.AwsSqs.Constants;
using ExportZipManager.Data.DynamoDb.Api;
using ExportZipManager.Data.PostgreSql;
using ExportZipManager.Data.S3.Api;
using ExportZipManager.Data.SqsPublisher.Adapters;
using ExportZipManager.Domain.Metrics;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection.Extensions;

namespace ExportZipManager.Api.ComponentTests.Framework;

internal class ApplicationServicesOverride : IApplicationServicesOverride<Scenario>
{
    public void Apply(IServiceCollection services, Scenario scenario)
    {
        services
            .AddScenario(scenario)
            .ConfigureRequestsTracking<Scenario>()
            .RemoveHealthCheckRegistrations()
            .OverrideLogger(scenario)
            .OverrideIdGenerator(scenario)
            .OverrideTimeProvider(scenario)
            .OverrideAmazonSqsTransport(scenario, PipelineConstants.EventsProcessingPipeline);

        services.ReplaceDbContextWithSqlite<ExportZipManagerDbContext>(
            scenario,
            o => o.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking));

        services
            .RemoveAll<IAmazonDynamoDbApi>()
            .RemoveAll<IAmazonS3Api>()
            .RemoveAll<IAmazonSqsPublishingAdapter>()
            .RemoveAll<IMetricsService>();

        services
            .AddTransient<IAmazonDynamoDbApi>(_ => scenario.Mocks.AmazonDynamoDbApiMock)
            .AddTransient<IAmazonS3Api>(_ => scenario.Mocks.AmazonS3ApiMock)
            .AddTransient<IAmazonSqsPublishingAdapter>(_ => scenario.Mocks.AmazonSqsPublisher)
            .AddSingleton<IMetricsService>(_ => scenario.Mocks.MetricsServiceMock);
    }
}
