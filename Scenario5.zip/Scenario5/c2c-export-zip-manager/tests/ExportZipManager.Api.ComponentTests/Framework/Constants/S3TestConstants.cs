namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class S3TestConstants
{
    public const string BucketName = "export-zip-manager-test";

    public const string Region = "eu-west-1";
}
