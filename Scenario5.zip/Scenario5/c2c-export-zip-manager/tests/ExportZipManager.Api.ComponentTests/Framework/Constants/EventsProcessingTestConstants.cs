using System;

namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class EventsProcessingTestConstants
{
    public const string QueueUrl = "c2c-export-zip-manager-results-test-queue-url";
    public const string DeadLetterQueueUrl = "c2c-export-zip-manager-results-test-queue-dlq-url";
    public const int MaxNumberOfMessages = 10;
    public static readonly TimeSpan MessageProcessingTimeout = TimeSpan.FromSeconds(30);
}
