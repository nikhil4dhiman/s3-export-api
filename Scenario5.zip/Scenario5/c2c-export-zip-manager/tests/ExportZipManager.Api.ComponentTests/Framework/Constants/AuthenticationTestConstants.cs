namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class AuthenticationTestConstants
{
    public const string UserName = "UserName";

    public const string Password = "Password";
}
