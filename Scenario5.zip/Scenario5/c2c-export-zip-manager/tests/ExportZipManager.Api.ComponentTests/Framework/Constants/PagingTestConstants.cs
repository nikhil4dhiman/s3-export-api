namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class PagingTestConstants
{
    public const int DefaultPageSize = 5;

    public const int MaxPageSize = 10;
}
