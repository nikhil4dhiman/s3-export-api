namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class RequestTestConstants
{
    public const string ContentLength = "ContentLength";
}
