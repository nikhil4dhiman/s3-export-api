namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class DynamoDbTestConstants
{
    public const string TableName = "test-c2c-export-zip-manager";
}
