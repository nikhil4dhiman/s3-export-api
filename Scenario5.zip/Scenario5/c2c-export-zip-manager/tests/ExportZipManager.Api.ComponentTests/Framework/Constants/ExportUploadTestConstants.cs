using System.IO;

namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class ExportUploadTestConstants
{
    public static readonly string TempFileDirectory = Path.GetTempPath();

    public const int MemoryBufferThresholdInMegabytes = 1;

    public const int MaxPartSizeInMegabytes = 1;

    public const long MaxPartSizeInBytes = MaxPartSizeInMegabytes * 1024 * 1024;

    public const int MaxFileSizeInMegabytes = 1;

    public const long MaxFileSizeInBytes = MaxFileSizeInMegabytes * 1024 * 1024;
}
