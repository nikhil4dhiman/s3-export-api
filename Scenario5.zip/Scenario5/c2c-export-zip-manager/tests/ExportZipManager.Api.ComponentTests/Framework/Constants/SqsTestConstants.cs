namespace ExportZipManager.Api.ComponentTests.Framework.Constants;

internal static class SqsTestConstants
{
    public const string QueueUrl = "https://sqs.eu-west-1.amazonaws.com/000000000000/c2c-export-zip-processor-events";
}
