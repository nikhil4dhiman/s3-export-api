using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration;
using Cove.Platform.Extensions.Testing.SharedHelpers.DependencyInjection;
using ExportZipManager.Api.ComponentTests.Steps.Given;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.ComponentTests.Steps.When;

namespace ExportZipManager.Api.ComponentTests.Framework;

internal class TestFixtureBase : ApplicationTestFixtureBase<Program, GivenStep, WhenStep, ThenStep, Scenario>
{
    protected override IApplicationConfigurationOverride BuildConfigurationOverride()
    {
        return new ApplicationConfigurationOverride();
    }

    protected override IApplicationServicesOverride<Scenario> BuildServicesOverride()
    {
        return new ApplicationServicesOverride();
    }
}
