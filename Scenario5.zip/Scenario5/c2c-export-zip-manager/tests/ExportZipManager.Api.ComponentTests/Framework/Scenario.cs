using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.Testing;
using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using Cove.Platform.Extensions.Testing.SharedHelpers.DateTimeHandling;
using Cove.Platform.Extensions.Testing.SharedHelpers.EntityFramework;
using ExportZipManager.Api.ComponentTests.TestHelpers.Mocks;
using ExportZipManager.BackgroundServices.AwsSqs.Constants;
using ExportZipManager.Data.PostgreSql;
using Microsoft.Extensions.Time.Testing;

namespace ExportZipManager.Api.ComponentTests.Framework;

/// <summary>
/// Holds shared data that is scoped to the currently running test.
/// </summary>
/// <remarks>
/// <see cref="Scenario"/> class is defined as internal as it may hold references to internal classes from the SUT.
/// </remarks>
internal class Scenario : DefaultApiApplicationScenarioBase<Program>
{
    public Mocks Mocks => GetAndInitialiseIfNotSet(nameof(Mocks), () => new Mocks(this));

    public SqliteDatabaseMock<ExportZipManagerDbContext> Database
        => Extensions.GetDatabaseMock<ExportZipManagerDbContext>();

    public FakeTimeProvider TimeProvider => Extensions.GetTimeProviderMock();

    public AmazonSqsTransportMock EventsProcessingSqsTransport
        => Extensions.GetAmazonSqsTransportMockByKey(PipelineConstants.EventsProcessingPipeline);
}
