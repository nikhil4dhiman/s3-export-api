using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration;
using Cove.Platform.Extensions.Testing.SharedHelpers.Configuration.Builders;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using ExportZipManager.Api.Configuration;
using ExportZipManager.BackgroundServices.AwsSqs.Configuration;
using ExportZipManager.Data.DynamoDb.Configuration;
using ExportZipManager.Data.S3.Configuration;
using ExportZipManager.Data.SqsPublisher.Configuration;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;

namespace ExportZipManager.Api.ComponentTests.Framework;

internal class ApplicationConfigurationOverride : IApplicationConfigurationOverride
{
    public void Apply(IConfigurationBuilder builder, IHostEnvironment environment)
    {
        var configuration = new InMemoryConfigurationBuilder()
            .ForOptions<BasicAuthenticationOptions>(configure => configure
                .WithValue(o => o.UserName, AuthenticationTestConstants.UserName)
                .WithValue(o => o.Password, AuthenticationTestConstants.Password))
            .ForOptions<PagingOptions>(configure => configure
                .WithValue(o => o.MaxPageSize, PagingTestConstants.MaxPageSize)
                .WithValue(o => o.DefaultPageSize, PagingTestConstants.DefaultPageSize))
            .ForOptions<ExportUploadOptions>(configure => configure
                .WithValue(o => o.TempFileDirectory, ExportUploadTestConstants.TempFileDirectory)
                .WithValue(o => o.MemoryBufferThresholdInMegabytes, ExportUploadTestConstants.MemoryBufferThresholdInMegabytes)
                .WithValue(o => o.MaxPartSizeInMegabytes, ExportUploadTestConstants.MaxPartSizeInMegabytes)
                .WithValue(o => o.MaxFileSizeInMegabytes, ExportUploadTestConstants.MaxFileSizeInMegabytes))
            .ForOptions<DynamoDbOptions>(configure => configure
                .WithValue(o => o.TableName, DynamoDbTestConstants.TableName))
            .ForOptions<S3Options>(configure => configure
                .WithValue(o => o.BucketName, S3TestConstants.BucketName))
            .ForOptions<SqsOptions>(configure => configure
                .WithValue(o => o.QueueUrl, SqsTestConstants.QueueUrl))
            .ForOptions<EventsProcessingOptions>(configure => configure
                .WithValue(o => o.QueueUrl, EventsProcessingTestConstants.QueueUrl)
                .WithValue(o => o.DeadLetterQueueUrl, EventsProcessingTestConstants.DeadLetterQueueUrl)
                .WithValue(o => o.MaxNumberOfMessages, EventsProcessingTestConstants.MaxNumberOfMessages)
                .WithValue(o => o.MessageProcessingTimeout, EventsProcessingTestConstants.MessageProcessingTimeout))
            .Build();

        builder.AddInMemoryCollection(configuration!);
    }
}
