using Cove.Platform.Extensions.Testing.SharedHelpers.BddContexts;
using NUnit.Framework;

[assembly: FixtureLifeCycle(LifeCycle.InstancePerTestCase)]
[assembly: Parallelizable(ParallelScope.Children)]

namespace ExportZipManager.Api.ComponentTests.Tests;

[SetUpFixture]
internal class TestSuiteSetup : ApplicationTestSuiteSetupBase;
