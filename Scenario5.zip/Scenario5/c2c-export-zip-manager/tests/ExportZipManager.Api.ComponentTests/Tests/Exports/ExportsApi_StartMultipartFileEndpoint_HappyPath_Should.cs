using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Tests.Core.Builders.S3.Api;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_StartMultipartFileEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void ReturnTheUploadIdForTheInitiatedMultipartUpload()
    {
        var exportId = Generate.RandomString();
        var uploadId = Generate.RandomString();

        var request = new StartFileRequestBuilder()
            .WithRandomValues()
            .Build();

        var initiateUploadResponse = new InitiateMultipartUploadResponseBuilder()
            .WithRandomValues()
            .WithUploadId(uploadId)
            .Build();

        var expectedResponse = new StartMultipartFileResponseBuilder()
            .WithUploadId(uploadId)
            .Build();

        Given.AnAmazonS3.WillInitiateMultipartUploadWith(initiateUploadResponse);
        When.ICall.TheExportsApi.StartMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillSucceed()
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }
}
