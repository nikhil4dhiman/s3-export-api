using System;
using System.Net;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Domain.Metrics;
using ExportZipManager.Domain.Models.Exports;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_CompleteEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void PublishZipGenerationEventToSqs()
    {
        var exportId = Generate.RandomString();
        var partnerId = Generate.RandomString();
        var sourceName = Generate.RandomString();
        var sourceType = Generate.RandomEnumValue<SourceType>();

        var expectedResponse = new CompleteExportResponseBuilder()
            .WithExportId(exportId)
            .Build();

        var request = new CompleteExportRequestBuilder()
            .WithSourceName(sourceName)
            .WithSourceType(sourceType)
            .Build();

        Given.ARequestHas.PartnerIdHeader(partnerId);
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Accepted)
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse)
            .And.TheAmazonSqs.WillHavePublishedEventFor(
                exportId,
                partnerId,
                sourceName,
                sourceType,
                Scenario.TimeProvider.GetUtcNow())
            .And.TheMetrics.WillHaveIncreasedZipGenerationEventsPublishedCounterOnce(
                MetricLabelValues.Result.Published);
    }

    [Test]
    public void PublishSourceDetailsSoTheProcessorCanNameTheArchive()
    {
        var exportId = Generate.RandomString();
        var partnerId = Generate.RandomString();
        var sourceName = Generate.RandomString();
        var sourceType = Generate.RandomEnumValue<SourceType>();

        var request = new CompleteExportRequestBuilder()
            .WithSourceName(sourceName)
            .WithSourceType(sourceType)
            .Build();

        Given.ARequestHas.PartnerIdHeader(partnerId);
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Accepted)
            .And.TheAmazonSqs.WillHavePublishedEventFor(
                exportId,
                partnerId,
                sourceName,
                sourceType,
                // Stamped by the service, so a redelivered message keeps the same archive key.
                Scenario.TimeProvider.GetUtcNow());
    }

    [TestCase("onedrive", SourceType.OneDrive)]
    [TestCase("SharePoint", SourceType.SharePoint)]
    public void PublishTheSourceTypeWhateverCaseItsNameArrivesIn(string sourceTypeName, SourceType expected)
    {
        // Callers spell the type themselves, so the naming inputs must not hinge on their casing.
        var exportId = Generate.RandomString();
        var partnerId = Generate.RandomString();
        var sourceName = Generate.RandomString();

        Given.ARequestHas.PartnerIdHeader(partnerId);
        When.ICall.TheExportsApi.CompleteEndpointWithRawBody(
            exportId,
            $$"""
              { "sourceName": "{{sourceName}}", "sourceType": "{{sourceTypeName}}" }
              """);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Accepted)
            .And.TheAmazonSqs.WillHavePublishedEventFor(
                exportId,
                partnerId,
                sourceName,
                expected,
                Scenario.TimeProvider.GetUtcNow());
    }

    [Test]
    public void PublishTheRetriedCallsOwnSourceDetailsWhenRepublishingForAnExportAlreadyInProgress()
    {
        // Source details are taken from the request on every call rather than persisted, so a
        // republish carries whatever the retried call itself sent.
        var exportId = Generate.RandomString();
        var partnerId = Generate.RandomString();
        var zipRequestedAt = Scenario.TimeProvider.GetUtcNow();

        Scenario.TimeProvider.Advance(TimeSpan.FromMinutes(30));

        var retriedSourceName = Generate.RandomString();
        var retriedSourceType = Generate.RandomEnumValue<SourceType>();
        var request = new CompleteExportRequestBuilder()
            .WithSourceName(retriedSourceName)
            .WithSourceType(retriedSourceType)
            .Build();

        Given.ARequestHas.PartnerIdHeader(partnerId)
            .And.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress, zipRequestedAt: zipRequestedAt);
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Accepted)
            .And.TheAmazonSqs.WillHavePublishedEventFor(
                exportId,
                partnerId,
                retriedSourceName,
                retriedSourceType,
                // The request time is still the one exception: stamped by the first call and
                // reused so a redelivered message keeps the same archive key.
                zipRequestedAt);
    }

    [Test]
    public void RepublishZipGenerationEventToSqsIfExportIsAlreadyInProgress()
    {
        var exportId = Generate.RandomString();
        var partnerId = Generate.RandomString();
        var sourceName = Generate.RandomString();
        var sourceType = Generate.RandomEnumValue<SourceType>();
        var zipRequestedAt = Scenario.TimeProvider.GetUtcNow();

        var expectedResponse = new CompleteExportResponseBuilder()
            .WithExportId(exportId)
            .Build();

        var request = new CompleteExportRequestBuilder()
            .WithSourceName(sourceName)
            .WithSourceType(sourceType)
            .Build();

        Given.ARequestHas.PartnerIdHeader(partnerId)
            .And.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress, zipRequestedAt: zipRequestedAt);
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Accepted)
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse)
            .And.TheAmazonSqs.WillHavePublishedEventFor(
                exportId,
                partnerId,
                sourceName,
                sourceType,
                zipRequestedAt);
    }

    [Test]
    public void RecordZipRequestedAtOnTheExistingRecordWithoutTouchingStartedAt()
    {
        var exportId = Generate.RandomString();
        var startedAt = Given.TheTime.Now;
        var uploadDuration = TimeSpan.FromMinutes(3);

        var request = new CompleteExportRequestBuilder().WithRandomValues().Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString())
            .And.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress, startedAt: startedAt)
            .And.TheTime.AdvancesBy(uploadDuration);
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Accepted)
            .And.TheAmazonDynamoDb.WillHaveExportStartedAt(startedAt)
            .And.TheAmazonDynamoDb.WillHaveExportZipRequestedAt(startedAt + uploadDuration);
    }

    [Test]
    public void KeepTheFirstZipRequestedAtWhenTheCompleteEndpointIsRetried()
    {
        var exportId = Generate.RandomString();
        var startedAt = Given.TheTime.Now;
        var uploadDuration = TimeSpan.FromMinutes(3);

        var request = new CompleteExportRequestBuilder().WithRandomValues().Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString())
            .And.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress, startedAt: startedAt)
            .And.TheTime.AdvancesBy(uploadDuration);
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Given.TheTime.AdvancesBy(TimeSpan.FromMinutes(10));
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Accepted)
            .And.TheAmazonDynamoDb.WillHaveExportZipRequestedAt(startedAt + uploadDuration);
    }
}
