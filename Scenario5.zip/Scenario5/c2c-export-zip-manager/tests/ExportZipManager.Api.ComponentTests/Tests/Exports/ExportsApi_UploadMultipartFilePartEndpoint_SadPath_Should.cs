using System.Text;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using Cove.Platform.Extensions.Testing.SharedHelpers.TestCases;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Tests.Core.TestCases;
using ExportZipManager.Api.Validation;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_UploadMultipartFilePartEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfFileNameIsInvalid(string? invalidFileName)
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .WithFileName(invalidFileName)
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadMultipartFilePartRequestQuery>(
            x => x.FileName,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [PathTraversalFileNameTestCases]
    public void FailWithValidationErrorIfFileNameContainsPathTraversal(string unsafeFileName)
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .WithFileName(unsafeFileName)
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadMultipartFilePartRequestQuery>(
            x => x.FileName,
            ValidationMessages.FileNameShouldNotContainPathTraversal);
    }

    [Test]
    public void FailWithValidationErrorIfFileNameIsTooLong()
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());
        var tooLongFileName = new string('a', 1025);

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .WithFileName(tooLongFileName)
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadMultipartFilePartRequestQuery>(
            x => x.FileName,
            "The length of 'File Name' must be 1024 characters or fewer. You entered 1025 characters.");
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfUploadIdIsInvalid(string? invalidUploadId)
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .WithUploadId(invalidUploadId)
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadMultipartFilePartRequestQuery>(
            x => x.UploadId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfPartNumberIsNotProvided()
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .WithPartNumber(null)
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadMultipartFilePartRequestQuery>(
            x => x.PartNumber,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [TestCase(0)]
    [TestCase(10001)]
    public void FailWithValidationErrorIfPartNumberIsOutOfRange(int invalidPartNumber)
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .WithPartNumber(invalidPartNumber)
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadMultipartFilePartRequestQuery>(
            x => x.PartNumber,
            "Part Number should be between 1 and 10000.");
    }

    [Test]
    public void FailWithValidationErrorIfBodyIsNotProvided()
    {
        var exportId = Generate.RandomString();

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data: null);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor(
            RequestTestConstants.ContentLength,
            "Content Length should not be null or empty.");
    }

    [Test]
    public void FailWithValidationErrorIfBodyExceedsMaxPartSize()
    {
        var exportId = Generate.RandomString();
        var tooLargeData = new byte[ExportUploadTestConstants.MaxPartSizeInBytes + 1];

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, tooLargeData);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor(
            RequestTestConstants.ContentLength,
            $"Content Length should be between 0 and {ExportUploadTestConstants.MaxPartSizeInBytes} bytes.");
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonS3ApiIsUnavailable()
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        Given.AnAmazonS3.IsUnavailable();
        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithInternalServerError();
    }
}
