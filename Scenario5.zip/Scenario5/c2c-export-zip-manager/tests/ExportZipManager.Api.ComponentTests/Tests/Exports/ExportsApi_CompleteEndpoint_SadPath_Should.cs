using System.Net;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Validation;
using ExportZipManager.Domain.Metrics;
using ExportZipManager.Domain.Models.Exports;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_CompleteEndpoint_SadPath_Should : TestFixtureBase
{
    private const int SourceNameMaxLength = 256;

    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void FailWithValidationErrorIfExportIdIsWhitespace()
    {
        var exportId = " ";
        var request = new CompleteExportRequestBuilder().WithRandomValues().Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<ExportRequestPath>(
            x => x.ExportId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfPartnerIdHeaderIsMissing()
    {
        var exportId = Generate.RandomString();
        var request = new CompleteExportRequestBuilder().WithRandomValues().Build();

        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteExportRequestHeaders>(
            x => x.PartnerId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithBadRequestIfTheRequestHasNoBody()
    {
        // The body carries the archive naming inputs, so the endpoint no longer binds without
        // one and the caller is rejected before validation runs.
        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpointWithNoBody(Generate.RandomString());
        Then.TheCall.WillFail.WithStatusCode(HttpStatusCode.BadRequest)
            .And.TheAmazonSqs.WillNotHaveAnyPublishedEvent();
    }

    [Test]
    public void FailWithValidationErrorIfTheRequestBodyIsAnEmptyJsonObject()
    {
        // An empty object binds where a body-less request does not, so it is the validator
        // rather than model binding that has to reject it. Both details are missing, and the
        // per-field messages are covered by the single-field cases below.
        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpointWithRawBody(Generate.RandomString(), "{}");
        Then.TheCall.WillFail.WithStatusCode(HttpStatusCode.UnprocessableEntity)
            .And.TheAmazonSqs.WillNotHaveAnyPublishedEvent();
    }

    [Test]
    public void FailWithValidationErrorIfSourceTypeIsMissing()
    {
        // The name is supplied so the failure isolates to the type alone.
        var request = new CompleteExportRequestBuilder()
            .WithSourceName(Generate.RandomString())
            .WithSourceType(null)
            .Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpoint(Generate.RandomString(), request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteExportRequest>(
            x => x.SourceType,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfSourceNameIsMissing()
    {
        // The type is supplied so the failure isolates to the name alone.
        var request = new CompleteExportRequestBuilder()
            .WithSourceName(null)
            .WithSourceType(SourceType.SharePoint)
            .Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpoint(Generate.RandomString(), request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteExportRequest>(
            x => x.SourceName,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfSourceNameIsWhitespace()
    {
        var request = new CompleteExportRequestBuilder()
            .WithSourceName(" ")
            .WithSourceType(SourceType.SharePoint)
            .Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpoint(Generate.RandomString(), request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteExportRequest>(
            x => x.SourceName,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfSourceTypeIsOutsideTheEnum()
    {
        // A number binds to the enum without the converter objecting, so this rule is all that
        // keeps an unknown workload out of the archive name.
        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpointWithRawBody(
            Generate.RandomString(),
            """
            { "sourceName": "Marketing Site", "sourceType": 99 }
            """);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteExportRequest>(
                x => x.SourceType,
                ValidationMessages.PropertyShouldBeAKnownValue)
            .And.TheAmazonSqs.WillNotHaveAnyPublishedEvent();
    }

    [Test]
    public void FailWithBadRequestIfSourceTypeIsNotAKnownName()
    {
        // The converter rejects an unknown name while deserialising, so the request never
        // reaches the validator and the caller gets a bare 400 instead of problem details.
        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpointWithRawBody(
            Generate.RandomString(),
            """
            { "sourceName": "Marketing Site", "sourceType": "Dropbox" }
            """);
        Then.TheCall.WillFail.WithStatusCode(HttpStatusCode.BadRequest)
            .And.TheAmazonSqs.WillNotHaveAnyPublishedEvent();
    }

    [Test]
    public void FailWithValidationErrorIfSourceNameExceedsTheMaximumLength()
    {
        // The name reaches an S3 object key, which the rest of the key shares a byte budget with.
        var request = new CompleteExportRequestBuilder()
            .WithSourceName(new string('a', SourceNameMaxLength + 1))
            .WithSourceType(SourceType.SharePoint)
            .Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString());
        When.ICall.TheExportsApi.CompleteEndpoint(Generate.RandomString(), request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteExportRequest>(
                x => x.SourceName,
                $"The length of 'Source Name' must be {SourceNameMaxLength} characters or fewer. "
                + $"You entered {SourceNameMaxLength + 1} characters.")
            .And.TheAmazonSqs.WillNotHaveAnyPublishedEvent();
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonDynamoDbIsUnavailable()
    {
        var exportId = Generate.RandomString();
        var request = new CompleteExportRequestBuilder().WithRandomValues().Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString())
            .And.AnAmazonDynamoDb.IsUnavailable();
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillFail.WithInternalServerError();
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonSqsApiIsUnavailable()
    {
        var exportId = Generate.RandomString();
        var request = new CompleteExportRequestBuilder().WithRandomValues().Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString())
            .And.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress)
            .And.AnAmazonSqs.IsUnavailable();
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillFail.WithInternalServerError()
            .And.TheMetrics.WillHaveIncreasedZipGenerationEventsPublishedCounterOnce(
                MetricLabelValues.Result.Failed);
    }

    [TestCase(ExportStatus.Completed)]
    [TestCase(ExportStatus.Failed)]
    [TestCase(ExportStatus.Cancelled)]
    public void FailWithConflictErrorIfExportHasAlreadyBeenProcessed(ExportStatus status)
    {
        var exportId = Generate.RandomString();
        var request = new CompleteExportRequestBuilder().WithRandomValues().Build();

        Given.ARequestHas.PartnerIdHeader(Generate.RandomString())
            .And.AnAmazonDynamoDb.HasExportWithStatus(status);
        When.ICall.TheExportsApi.CompleteEndpoint(exportId, request);
        Then.TheCall.WillFail.WithStatusCode(HttpStatusCode.Conflict)
            .And.TheAmazonSqs.WillNotHaveAnyPublishedEvent();
    }
}
