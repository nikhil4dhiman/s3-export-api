using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_CancelEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void FailWithValidationErrorIfExportIdIsWhitespace()
    {
        var exportId = " ";

        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<ExportRequestPath>(
            x => x.ExportId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonS3ApiIsUnavailable()
    {
        var exportId = Generate.RandomString();

        Given.AnAmazonS3.IsUnavailable();
        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillFail.WithInternalServerError();
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonDynamoDbIsUnavailable()
    {
        var exportId = Generate.RandomString();

        Given.AnAmazonDynamoDb.IsUnavailable();
        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillFail.WithInternalServerError();
    }
}
