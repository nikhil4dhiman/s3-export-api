using System;
using System.Text;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.TestHelpers;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_UploadFileEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void UploadTheFileToS3()
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFileRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        var expectedKey = ExportHelper.BuildStagingFileKey(exportId, query.FileName);

        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, data);
        Then.TheCall.WillSucceed()
            .And.TheAmazonS3.WillHaveExportedDataFor(expectedKey, data);
    }

    [Test]
    public void UploadABlankFileToS3()
    {
        var exportId = Generate.RandomString();
        var data = Array.Empty<byte>();

        var query = new UploadFileRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        var expectedKey = ExportHelper.BuildStagingFileKey(exportId, query.FileName);

        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, data);
        Then.TheCall.WillSucceed()
            .And.TheAmazonS3.WillHaveExportedDataFor(expectedKey, data);
    }
}
