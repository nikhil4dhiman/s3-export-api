using System.Text;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.TestHelpers;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Tests.Core.Builders.S3.Api;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_UploadMultipartFilePartEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void ReturnTheETagForTheUploadedPart()
    {
        var exportId = Generate.RandomString();
        var eTag = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        var uploadPartResponse = new UploadPartResponseBuilder()
            .WithRandomValues()
            .WithETag(eTag)
            .Build();

        var expectedResponse = new UploadMultipartFilePartResponseBuilder()
            .WithETag(eTag)
            .Build();

        Given.AnAmazonS3.WillUploadPartWith(uploadPartResponse);
        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillSucceed()
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }

    [Test]
    public void UploadTheChunkDataToS3()
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFilePartRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        var expectedKey = ExportHelper.BuildStagingFileKey(exportId, query.FileName);

        When.ICall.TheExportsApi.UploadMultipartFilePartEndpoint(exportId, query, data);
        Then.TheCall.WillSucceed()
            .And.TheAmazonS3.WillHaveExportedDataFor(expectedKey, data);
    }
}
