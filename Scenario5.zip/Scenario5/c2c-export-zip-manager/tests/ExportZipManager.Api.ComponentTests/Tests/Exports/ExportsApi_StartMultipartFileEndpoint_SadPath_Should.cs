using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using Cove.Platform.Extensions.Testing.SharedHelpers.TestCases;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Tests.Core.TestCases;
using ExportZipManager.Api.Validation;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_StartMultipartFileEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfFileNameIsInvalid(string? invalidFileName)
    {
        var exportId = Generate.RandomString();

        var request = new StartFileRequestBuilder()
            .WithRandomValues()
            .WithFileName(invalidFileName)
            .Build();

        When.ICall.TheExportsApi.StartMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<StartMultipartFileRequest>(
            x => x.FileName,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [PathTraversalFileNameTestCases]
    public void FailWithValidationErrorIfFileNameContainsPathTraversal(string unsafeFileName)
    {
        var exportId = Generate.RandomString();

        var request = new StartFileRequestBuilder()
            .WithRandomValues()
            .WithFileName(unsafeFileName)
            .Build();

        When.ICall.TheExportsApi.StartMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<StartMultipartFileRequest>(
            x => x.FileName,
            ValidationMessages.FileNameShouldNotContainPathTraversal);
    }

    [Test]
    public void FailWithValidationErrorIfFileNameIsTooLong()
    {
        var exportId = Generate.RandomString();
        var tooLongFileName = new string('a', 1025);

        var request = new StartFileRequestBuilder()
            .WithRandomValues()
            .WithFileName(tooLongFileName)
            .Build();

        When.ICall.TheExportsApi.StartMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<StartMultipartFileRequest>(
            x => x.FileName,
            "The length of 'File Name' must be 1024 characters or fewer. You entered 1025 characters.");
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonS3ApiIsUnavailable()
    {
        var exportId = Generate.RandomString();

        var request = new StartFileRequestBuilder()
            .WithRandomValues()
            .Build();

        Given.AnAmazonS3.IsUnavailable();
        When.ICall.TheExportsApi.StartMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithInternalServerError();
    }
}
