using System.Text;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using Cove.Platform.Extensions.Testing.SharedHelpers.TestCases;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Tests.Core.TestCases;
using ExportZipManager.Api.Validation;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_UploadFileEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void FailWithValidationErrorIfFileIsNotProvided()
    {
        var exportId = Generate.RandomString();

        var query = new UploadFileRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, fileContent: null);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor(
            RequestTestConstants.ContentLength,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfFileExceedsMaxFileSize()
    {
        var exportId = Generate.RandomString();
        var tooLargeData = new byte[ExportUploadTestConstants.MaxFileSizeInBytes + 1];

        var query = new UploadFileRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, tooLargeData);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor(
            RequestTestConstants.ContentLength,
            $"Content Length should be between 0 and {ExportUploadTestConstants.MaxFileSizeInBytes} bytes.");
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfFileNameIsInvalid(string? invalidFileName)
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFileRequestQueryBuilder()
            .WithFileName(invalidFileName)
            .Build();

        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadFileRequestQuery>(
            x => x.FileName,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [PathTraversalFileNameTestCases]
    public void FailWithValidationErrorIfFileNameContainsPathTraversal(string unsafeFileName)
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFileRequestQueryBuilder()
            .WithFileName(unsafeFileName)
            .Build();

        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadFileRequestQuery>(
            x => x.FileName,
            ValidationMessages.FileNameShouldNotContainPathTraversal);
    }

    [Test]
    public void FailWithValidationErrorIfFileNameIsTooLong()
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());
        var tooLongFileName = new string('a', 1025);

        var query = new UploadFileRequestQueryBuilder()
            .WithFileName(tooLongFileName)
            .Build();

        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<UploadFileRequestQuery>(
            x => x.FileName,
            "The length of 'File Name' must be 1024 characters or fewer. You entered 1025 characters.");
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonS3ApiIsUnavailable()
    {
        var exportId = Generate.RandomString();
        var data = Encoding.UTF8.GetBytes(Generate.RandomString());

        var query = new UploadFileRequestQueryBuilder()
            .WithRandomValues()
            .Build();

        Given.AnAmazonS3.IsUnavailable();
        When.ICall.TheExportsApi.UploadFileEndpoint(exportId, query, data);
        Then.TheCall.WillFail.WithInternalServerError();
    }
}
