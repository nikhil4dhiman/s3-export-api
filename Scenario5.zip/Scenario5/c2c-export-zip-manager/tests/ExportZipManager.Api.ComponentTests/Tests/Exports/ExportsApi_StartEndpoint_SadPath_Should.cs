using Cove.Platform.Extensions.Testing.SharedHelpers.TestCases;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Validation;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_StartEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfBackupIdIsInvalid(string? invalidBackupId)
    {
        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .WithBackupId(invalidBackupId)
            .Build();

        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<StartExportRequest>(
            x => x.BackupId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfSessionIdIsInvalid(string? invalidSessionId)
    {
        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .WithSessionId(invalidSessionId)
            .Build();

        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<StartExportRequest>(
            x => x.SessionId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfRunIdIsInvalid(string? invalidRunId)
    {
        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .WithRunId(invalidRunId)
            .Build();

        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<StartExportRequest>(
            x => x.RunId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfSourceIdIsInvalid(string? invalidSourceId)
    {
        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .WithSourceId(invalidSourceId)
            .Build();

        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<StartExportRequest>(
            x => x.SourceId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonDynamoDbIsUnavailable()
    {
        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .Build();

        Given.AnAmazonDynamoDb.IsUnavailable();
        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillFail.WithInternalServerError();
    }
}
