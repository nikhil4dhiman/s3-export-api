using System.Net;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Domain.Models.Exports;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_StatusEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void ReturnInProgressStatusWithNoFileIdWhileExportIsInProgress()
    {
        var exportId = Generate.RandomString();

        var expectedResponse = new GetExportStatusResponseBuilder()
            .WithStatus(ExportStatus.InProgress.ToString())
            .WithFileId(null)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress);
        When.ICall.TheExportsApi.StatusEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.OK)
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }

    [Test]
    public void ReturnCompletedStatusWithFileIdWhenExportHasCompleted()
    {
        var exportId = Generate.RandomString();
        var fileId = Generate.RandomString();

        var expectedResponse = new GetExportStatusResponseBuilder()
            .WithStatus(ExportStatus.Completed.ToString())
            .WithFileId(fileId)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.Completed, fileId);
        When.ICall.TheExportsApi.StatusEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.OK)
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }

    [Test]
    public void ReturnFailedStatusWithNoFileIdWhenExportHasFailed()
    {
        var exportId = Generate.RandomString();

        var expectedResponse = new GetExportStatusResponseBuilder()
            .WithStatus(ExportStatus.Failed.ToString())
            .WithFileId(null)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.Failed);
        When.ICall.TheExportsApi.StatusEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.OK)
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }

    [Test]
    public void ReturnCancelledStatusWithNoFileIdWhenExportHasBeenCancelled()
    {
        var exportId = Generate.RandomString();

        var expectedResponse = new GetExportStatusResponseBuilder()
            .WithStatus(ExportStatus.Cancelled.ToString())
            .WithFileId(null)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.Cancelled);
        When.ICall.TheExportsApi.StatusEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.OK)
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }
}
