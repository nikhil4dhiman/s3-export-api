using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using Cove.Platform.Extensions.Testing.SharedHelpers.TestCases;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Api.Tests.Core.TestCases;
using ExportZipManager.Api.Validation;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_CompleteMultipartFileEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfFileNameIsInvalid(string? invalidFileName)
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithFileName(invalidFileName)
            .Build();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteMultipartFileRequest>(
            x => x.FileName,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [PathTraversalFileNameTestCases]
    public void FailWithValidationErrorIfFileNameContainsPathTraversal(string unsafeFileName)
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithFileName(unsafeFileName)
            .Build();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteMultipartFileRequest>(
            x => x.FileName,
            ValidationMessages.FileNameShouldNotContainPathTraversal);
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfUploadIdIsInvalid(string? invalidUploadId)
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithUploadId(invalidUploadId)
            .Build();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteMultipartFileRequest>(
            x => x.UploadId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfPartsAreMissing()
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithParts(null)
            .Build();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CompleteMultipartFileRequest>(
            x => x.Parts,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfPartNumberIsMissing()
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithParts(
            [
                new CompleteMultipartFileRequestPartBuilder()
                    .WithRandomValues()
                    .WithPartNumber(null)
                    .Build()
            ])
            .Build();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor(
            "Parts[0].PartNumber",
            "Part Number should not be null or empty.");
    }

    [TestCase(0)]
    [TestCase(-1)]
    [TestCase(10001)]
    public void FailWithValidationErrorIfPartNumberIsOutOfRange(int invalidPartNumber)
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithParts(
            [
                new CompleteMultipartFileRequestPartBuilder()
                    .WithRandomValues()
                    .WithPartNumber(invalidPartNumber)
                    .Build()
            ])
            .Build();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor(
            "Parts[0].PartNumber",
            "Part Number should be between 1 and 10000.");
    }

    [Test]
    public void FailWithValidationErrorIfETagIsMissing()
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithParts(
            [
                new CompleteMultipartFileRequestPartBuilder()
                    .WithRandomValues()
                    .WithETag(null)
                    .Build()
            ])
            .Build();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor(
            "Parts[0].ETag",
            "E Tag should not be null or empty.");
    }

    [Test]
    public void FailWithInternalServerErrorIfAmazonS3ApiIsUnavailable()
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .Build();

        Given.AnAmazonS3.IsUnavailable();
        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillFail.WithInternalServerError();
    }
}
