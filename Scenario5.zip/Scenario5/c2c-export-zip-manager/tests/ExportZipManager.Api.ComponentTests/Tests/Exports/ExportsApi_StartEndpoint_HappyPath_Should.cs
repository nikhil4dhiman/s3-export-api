using System;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using ExportZipManager.Domain.Models.Exports;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_StartEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void ReturnExportId()
    {
        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .Build();

        var expectedResponse = new StartExportResponseBuilder()
            .FromRequest(request)
            .Build();

        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillSucceed()
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }

    [Test]
    public void RecordExportAsInProgressWithTheTimeItStarted()
    {
        var startedAt = Given.TheTime.Now;

        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .Build();

        var expectedResponse = new StartExportResponseBuilder()
            .FromRequest(request)
            .Build();

        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillSucceed()
            .And.TheAmazonDynamoDb.WillHaveExportRecordWith(expectedResponse.ExportId, ExportStatus.InProgress)
            .And.TheAmazonDynamoDb.WillHaveExportStartedAt(startedAt)
            .And.TheMetrics.WillHaveIncreasedExportsStartedCounterOnce();
    }

    [Test]
    public void KeepTheOriginalStartedAtWhenTheSameExportIsStartedAgain()
    {
        var startedAt = Given.TheTime.Now;

        var request = new StartExportRequestBuilder()
            .WithRandomValues()
            .Build();

        var expectedResponse = new StartExportResponseBuilder()
            .FromRequest(request)
            .Build();

        When.ICall.TheExportsApi.StartEndpoint(request);
        Given.TheTime.AdvancesBy(TimeSpan.FromMinutes(5));
        When.ICall.TheExportsApi.StartEndpoint(request);
        Then.TheCall.WillSucceed()
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse)
            .And.TheAmazonDynamoDb.WillHaveExportStartedAt(startedAt)
            .And.TheMetrics.WillHaveIncreasedExportsStartedCounterOnce();
    }
}
