using System.Linq;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.TestHelpers;
using ExportZipManager.Api.Tests.Core.Builders.Exports.Api;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_CompleteMultipartFileEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void CompleteTheMultipartUploadInS3()
    {
        var exportId = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .Build();

        var expectedKey = ExportHelper.BuildStagingFileKey(exportId, request.FileName);
        var expectedParts = request.Parts!
            .Select(p => (p.PartNumber!.Value, p.ETag!))
            .ToArray();

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillSucceed()
            .And.TheAmazonS3.WillHaveCompletedMultipartUploadFor(expectedKey, request.UploadId!, expectedParts);
    }

    [Test]
    public void CompleteTheMultipartUploadForABlankFileInS3()
    {
        var exportId = Generate.RandomString();
        var eTag = Generate.RandomString();

        var request = new CompleteMultipartFileRequestBuilder()
            .WithRandomValues()
            .WithParts(
            [
                new CompleteMultipartFileRequestPartBuilder()
                    .WithRandomValues()
                    .WithPartNumber(1)
                    .WithETag(eTag)
                    .Build()
            ])
            .Build();

        var expectedKey = ExportHelper.BuildStagingFileKey(exportId, request.FileName);

        When.ICall.TheExportsApi.CompleteMultipartFileEndpoint(exportId, request);
        Then.TheCall.WillSucceed()
            .And.TheAmazonS3.WillHaveCompletedMultipartUploadFor(expectedKey, request.UploadId!, (1, eTag));
    }
}
