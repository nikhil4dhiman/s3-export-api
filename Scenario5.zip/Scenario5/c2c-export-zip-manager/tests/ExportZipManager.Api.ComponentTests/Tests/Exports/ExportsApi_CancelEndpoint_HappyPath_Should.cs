using System.Net;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Domain.Models.Exports;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Exports;

[TestFixture]
internal class ExportsApi_CancelEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void WriteCancelledStatusAndDeleteAllStagedFilesFromS3WhenNoRecordExists()
    {
        var exportId = Generate.RandomString();
        var cancelledAt = Given.TheTime.Now;

        Given.AnAmazonS3.HasStagedFilesFor(exportId, "document.pdf", "thumbnail.png");
        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.NoContent)
            .And.TheAmazonDynamoDb.WillHaveExportRecordWith(exportId, ExportStatus.Cancelled)
            .And.TheAmazonDynamoDb.WillHaveExportCancelledAt(cancelledAt)
            .And.TheAmazonS3.HasNoStagedFilesFor(exportId)
            .And.TheMetrics.WillHaveIncreasedExportsCancelledCounterOnce();
    }

    [Test]
    public void SucceedEvenWhenNoStagedFilesExist()
    {
        var exportId = Generate.RandomString();

        Given.AnAmazonS3.DoesNotHaveAnyStagedFilesFor(exportId);
        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.NoContent)
            .And.TheMetrics.WillHaveIncreasedExportsCancelledCounterOnce();
    }

    [Test]
    public void UpdateStatusToCancelledButLeaveS3UntouchedWhenExportIsInProgress()
    {
        var exportId = Generate.RandomString();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress)
            .And.AnAmazonS3.HasStagedFilesFor(exportId, "document.pdf");

        var cancelledAt = Given.TheTime.Now;

        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.NoContent)
            .And.TheAmazonDynamoDb.WillHaveUpdatedExportWith(exportId, ExportStatus.Cancelled)
            .And.TheAmazonDynamoDb.WillHaveExportCancelledAt(cancelledAt)
            .And.TheAmazonS3.HasStagedFilesFor(exportId)
            .And.TheMetrics.WillHaveIncreasedExportsCancelledCounterOnce();
    }

    [Test]
    public void NotWriteStatusAgainOrDeleteStagedFilesWhenExportIsAlreadyCancelled()
    {
        var exportId = Generate.RandomString();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.Cancelled)
            .And.AnAmazonS3.HasStagedFilesFor(exportId, "document.pdf");
        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.NoContent)
            .And.TheAmazonS3.HasStagedFilesFor(exportId)
            .And.TheMetrics.WillNotHaveIncreasedExportsCancelledCounter();
    }

    [TestCase(ExportStatus.Completed)]
    [TestCase(ExportStatus.Failed)]
    public void NotOverwriteStatusButStillDeleteStagedFilesWhenExportHasAlreadyFinished(ExportStatus status)
    {
        var exportId = Generate.RandomString();

        Given.AnAmazonDynamoDb.HasExportWithStatus(status)
            .And.AnAmazonS3.HasStagedFilesFor(exportId, "document.pdf");
        When.ICall.TheExportsApi.CancelEndpoint(exportId);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.NoContent)
            .And.TheAmazonDynamoDb.WillNotHaveAnyUpdatedExport()
            .And.TheAmazonS3.HasNoStagedFilesFor(exportId)
            .And.TheMetrics.WillNotHaveIncreasedExportsCancelledCounter();
    }
}
