using Cove.Platform.Extensions.Testing.SharedHelpers.TestCases;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Models.Samples.Requests;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Api;
using ExportZipManager.Api.Validation;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Samples;

[TestFixture]
internal class SamplesApi_CreateEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidUserIdHeader()
            .And.ARequestHas.ValidBasicAuthCredentials();
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfSampleNameIsInvalid(string? invalidName)
    {
        var request = new CreateSampleRequestBuilder()
            .WithRandomValues()
            .WithName(invalidName)
            .Build();

        When.ICall.TheSamplesApi.CreateEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CreateSampleRequest>(
            x => x.Name,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [EmptyStringTestCases]
    public void FailWithValidationErrorIfSampleAdditionalDetailsAreEmptyButRequired(string? emptyAdditionalDetails)
    {
        var request = new CreateSampleRequestBuilder()
            .WithRandomValues()
            .WithSomeFlagFieldThatWillRequireDetails(true)
            .WithDetails(x => x.WithAdditionalDetails(emptyAdditionalDetails))
            .Build();

        When.ICall.TheSamplesApi.CreateEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CreateSampleRequest>(
            x => x.Details!.AdditionalDetails,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }

    [Test]
    public void FailWithValidationErrorIfSampleDetailsPropertyIsMissingButRequired()
    {
        var request = new CreateSampleRequestBuilder()
            .WithRandomValues()
            .WithSomeFlagFieldThatWillRequireDetails(true)
            .WithoutDetails()
            .Build();

        When.ICall.TheSamplesApi.CreateEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CreateSampleRequest>(
            x => x.Details,
            ValidationMessages.PropertyShouldNotBeNullOrEmptyWhenDependentPropertyIsTrue(
                nameof(CreateSampleRequest.SomeFlagFieldThatWillRequireDetails)));
    }

    [Test]
    public void FailWithValidationErrorIfUserIdParameterIsNotValid()
    {
        var request = new CreateSampleRequestBuilder()
            .WithRandomValues()
            .Build();

        Given.ARequestHas.InvalidUserIdHeader();
        When.ICall.TheSamplesApi.CreateEndpoint(request);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<CreateSampleRequestHeaders>(
            x => x.UserId,
            ValidationMessages.PropertyShouldNotBeNullOrEmpty);
    }
}
