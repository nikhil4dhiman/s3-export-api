using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Api;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Domain;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Samples;

[TestFixture]
internal class SamplesApi_GetByIdEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void ReturnExistingSampleById()
    {
        var existingSample = new SampleBuilder()
            .WithRandomValues()
            .Build();

        var expectedResponse = new GetSampleResponseBuilder()
            .FromDomainModel(existingSample)
            .Build();

        Given.ADatabase.HasSamples(existingSample);
        When.ICall.TheSamplesApi.GetByIdEndpoint(existingSample.Id);
        Then.TheCall.WillSucceed()
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }
}
