using System.Linq;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Api;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Domain;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Samples;

[TestFixture]
internal class SamplesApi_GetPageEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void ReturnExpectedPageOfSamples()
    {
        var take = Generate.RandomInt(1, PagingTestConstants.MaxPageSize);
        var skip = Generate.RandomInt(0, 10);
        var totalCount = skip + Generate.RandomInt(1, PagingTestConstants.MaxPageSize * 2);

        var existingSamples = new SamplesBuilder()
            .AppendMultipleRandom(totalCount)
            .Build();

        var requestQuery = new GetSamplesRequestQueryBuilder()
            .WithSkip(skip)
            .WithTake(take)
            .Build();

        var expectedItems = existingSamples
            .OrderBy(x => x.Name)
            .Skip(skip)
            .Take(take);

        var expectedResponse = new GetSamplesResponseBuilder()
            .WithItems(expectedItems)
            .WithTotalCount(totalCount)
            .Build();

        Given.ADatabase.HasSamples(existingSamples);
        When.ICall.TheSamplesApi.GetPageEndpoint(requestQuery);
        Then.TheCall.WillSucceed()
            .And.TheCall.WillHaveAResponseEqualTo(expectedResponse);
    }
}
