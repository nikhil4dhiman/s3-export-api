using System.Net;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Api;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Domain;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Samples;

[TestFixture]
internal class SamplesApi_CreateEndpoint_HappyPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidUserIdHeader()
            .And.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void CreateANewSample()
    {
        var idForCreatedRecord = Generate.RandomString();

        var request = new CreateSampleRequestBuilder()
            .WithRandomValues()
            .Build();

        var expectedSample = new SampleBuilder()
            .FromRequest(request)
            .WithId(idForCreatedRecord)
            .Build();

        Given.AnIdGenerator.WillGenerateOrderedId(idForCreatedRecord);
        When.ICall.TheSamplesApi.CreateEndpoint(request);
        Then.TheCall.WillSucceedWithStatusCode(HttpStatusCode.Created)
            .And.TheDatabase.WillHaveSamples.EqualTo(expectedSample);
    }
}
