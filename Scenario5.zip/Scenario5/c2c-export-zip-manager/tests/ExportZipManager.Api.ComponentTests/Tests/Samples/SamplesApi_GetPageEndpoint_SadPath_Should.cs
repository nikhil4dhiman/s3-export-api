using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using ExportZipManager.Api.ComponentTests.Steps.Then;
using ExportZipManager.Api.Models.Samples.Requests;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Api;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Domain;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Samples;

[TestFixture]
internal class SamplesApi_GetPageEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void FailWithValidationErrorIfTakeParameterIsNotValid()
    {
        var take = PagingTestConstants.MaxPageSize + 1;
        var skip = Generate.RandomInt(0, 10);
        var totalCount = skip + Generate.RandomInt(1, PagingTestConstants.MaxPageSize * 2);

        var existingSamples = new SamplesBuilder()
            .AppendMultipleRandom(totalCount)
            .Build();

        var requestQuery = new GetSamplesRequestQueryBuilder()
            .WithSkip(skip)
            .WithTake(take)
            .Build();

        Given.ADatabase.HasSamples(existingSamples);
        When.ICall.TheSamplesApi.GetPageEndpoint(requestQuery);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<GetSamplesRequestQuery>(
            x => x.Take,
            $"Take should be between 1 and {PagingTestConstants.MaxPageSize}."
            );
    }

    [Test]
    public void FailWithValidationErrorIfSkipParameterIsNotValid()
    {
        var take = Generate.RandomInt(1, PagingTestConstants.MaxPageSize);
        var skip = -1;
        var totalCount = skip + Generate.RandomInt(1, PagingTestConstants.MaxPageSize * 2);

        var existingSamples = new SamplesBuilder()
            .AppendMultipleRandom(totalCount)
            .Build();

        var requestQuery = new GetSamplesRequestQueryBuilder()
            .WithSkip(skip)
            .WithTake(take)
            .Build();

        Given.ADatabase.HasSamples(existingSamples);
        When.ICall.TheSamplesApi.GetPageEndpoint(requestQuery);
        Then.TheCall.WillFail.WithValidationProblemDetailsFor<GetSamplesRequestQuery>(
            x => x.Skip,
            "Skip should be greater than or equal to 0."
            );
    }
}
