using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Domain;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.Samples;

[TestFixture]
internal class SamplesApi_GetByIdEndpoint_SadPath_Should : TestFixtureBase
{
    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void FailWithNotFoundErrorIfEntityIsNotFound()
    {
        var existingId = "existing-id";
        const string NonExistingId = "non-existing-id";

        var existingSample = new SampleBuilder()
            .WithRandomValues()
            .WithId(existingId)
            .Build();

        Given.ADatabase.HasSamples(existingSample);
        When.ICall.TheSamplesApi.GetByIdEndpoint(NonExistingId);
        Then.TheCall.WillFail.WithNotFoundError();
    }
}
