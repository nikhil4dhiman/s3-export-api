using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.RequestPipeline;

[TestFixture]
internal class RequestPipeline_ErrorHandling_SadPath_Should : TestFixtureBase
{

    [SetUp]
    public void SetUp()
    {
        Given.ARequestHas.ValidBasicAuthCredentials();
    }

    [Test]
    public void ReturnGenericErrorResponseIfUnhandledExceptionOccurs()
    {
        Given.ADatabase.IsUnavailable();
        When.ICall.TheSamplesApi.GetByIdEndpoint(Generate.RandomString());
        Then.TheCall.WillFail.WithInternalServerError();
    }

    [Test]
    public void ReturnUnauthorizedErrorResponseIfBasicAuthHeaderIsInvalid()
    {
        Given.ARequestHas.InvalidBasicAuthCredentials();
        When.ICall.AnyEndpoint();
        Then.TheCall.WillFail.WithUnauthorizedError();
    }
}
