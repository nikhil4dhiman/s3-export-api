using System;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.ZipGenerationResultEvents;
using ExportZipManager.BackgroundServices.AwsSqs.Models;
using ExportZipManager.Domain.Metrics;
using ExportZipManager.Domain.Models.Exports;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.ZipGenerationResultEvents;

[TestFixture]
internal class ZipGenerationResultEventsProcessing_HappyPath_Should : TestFixtureBase
{
    [Test]
    public void UpdateExportStatusToCompletedWithFileId()
    {
        var exportId = Generate.RandomString();
        var fileId = Generate.RandomString();
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithId(exportId)
            .WithState(ExportResultState.Completed)
            .WithFileId(fileId)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillHaveUpdatedExportWith(exportId, ExportStatus.Completed, fileId);
    }

    [Test]
    public void UpdateExportStatusToFailedWithoutFileId()
    {
        var exportId = Generate.RandomString();
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithId(exportId)
            .WithState(ExportResultState.Failed)
            .WithResultDetails(null)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillHaveUpdatedExportWith(exportId, ExportStatus.Failed);
    }

    [TestCase(ExportResultState.Completed)]
    [TestCase(ExportResultState.Failed)]
    public void NotUpdateExportStatusIfExportIsAlreadyCancelled(ExportResultState state)
    {
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithRandomValues()
            .WithState(state)
            .WithFileId(Generate.RandomString())
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.Cancelled);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillNotHaveAnyUpdatedExport()
            .And.TheMetrics.WillNotHaveIncreasedExportsCompletedCounter();
    }

    [TestCase(ExportStatus.Completed)]
    [TestCase(ExportStatus.Failed)]
    public void OverwriteExportStatusWhenExportIsAlreadyCompletedOrFailed(ExportStatus existingStatus)
    {
        var exportId = Generate.RandomString();
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithId(exportId)
            .WithState(ExportResultState.Failed)
            .WithResultDetails(null)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(existingStatus);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillHaveUpdatedExportWith(exportId, ExportStatus.Failed)
            .And.TheMetrics.WillNotHaveIncreasedExportsCompletedCounter();
    }

    [Test]
    public void RecordCompletedAtAndObserveHowLongTheExportTook()
    {
        var exportId = Generate.RandomString();
        var startedAt = Given.TheTime.Now;
        var uploadDuration = TimeSpan.FromMinutes(2);
        var zipProcessingDuration = TimeSpan.FromMinutes(5);

        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithId(exportId)
            .WithState(ExportResultState.Completed)
            .WithFileId(Generate.RandomString())
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(
                ExportStatus.InProgress,
                startedAt: startedAt,
                zipRequestedAt: startedAt + uploadDuration)
            .And.TheTime.AdvancesBy(uploadDuration + zipProcessingDuration);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheAmazonDynamoDb.WillHaveExportCompletedAt(startedAt + uploadDuration + zipProcessingDuration)
            .And.TheMetrics.WillHaveObservedExportDuration(
                MetricLabelValues.Result.Completed,
                (uploadDuration + zipProcessingDuration).TotalSeconds)
            .And.TheMetrics.WillHaveObservedZipProcessingDuration(
                MetricLabelValues.Result.Completed,
                zipProcessingDuration.TotalSeconds)
            .And.TheMetrics.WillHaveIncreasedExportsCompletedCounter(MetricLabelValues.Result.Completed);
    }

    [Test]
    public void ObserveHowLongTheExportTookWhenItFailed()
    {
        var exportId = Generate.RandomString();
        var startedAt = Given.TheTime.Now;
        var exportDuration = TimeSpan.FromMinutes(1);

        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithId(exportId)
            .WithState(ExportResultState.Failed)
            .WithResultDetails(null)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(
                ExportStatus.InProgress,
                startedAt: startedAt,
                zipRequestedAt: startedAt)
            .And.TheTime.AdvancesBy(exportDuration);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheMetrics.WillHaveObservedExportDuration(
                MetricLabelValues.Result.Failed,
                exportDuration.TotalSeconds)
            .And.TheMetrics.WillHaveObservedZipProcessingDuration(
                MetricLabelValues.Result.Failed,
                exportDuration.TotalSeconds)
            .And.TheMetrics.WillHaveIncreasedExportsCompletedCounter(MetricLabelValues.Result.Failed);
    }

    [TestCase(ExportStatus.Completed)]
    [TestCase(ExportStatus.Failed)]
    [TestCase(ExportStatus.Cancelled)]
    public void NotObserveAnyDurationForAnExportThatHadAlreadyFinished(ExportStatus existingStatus)
    {
        var startedAt = Given.TheTime.Now;

        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithRandomValues()
            .WithState(ExportResultState.Completed)
            .WithFileId(Generate.RandomString())
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(
                existingStatus,
                startedAt: startedAt,
                zipRequestedAt: startedAt)
            .And.TheTime.AdvancesBy(TimeSpan.FromMinutes(5));
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheMetrics.WillNotHaveObservedAnyDuration()
            .And.TheMetrics.WillNotHaveIncreasedExportsCompletedCounter();
    }

    [Test]
    public void NotObserveZipProcessingDurationForAnExportRecordedBeforeZipRequestedAtWasCaptured()
    {
        var startedAt = Given.TheTime.Now;

        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithRandomValues()
            .WithState(ExportResultState.Completed)
            .WithFileId(Generate.RandomString())
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress, startedAt: startedAt);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheMetrics.WillHaveObservedExportDuration(MetricLabelValues.Result.Completed, 0)
            .And.TheMetrics.WillNotHaveObservedZipProcessingDuration()
            .And.TheMetrics.WillHaveIncreasedExportsCompletedCounter(MetricLabelValues.Result.Completed);
    }
}
