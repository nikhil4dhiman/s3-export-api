using System.Text.Json.Nodes;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.ZipGenerationResultEvents;
using ExportZipManager.BackgroundServices.AwsSqs.Models;
using ExportZipManager.Domain.Metrics;
using ExportZipManager.Domain.Models.Exports;
using NUnit.Framework;

namespace ExportZipManager.Api.ComponentTests.Tests.ZipGenerationResultEvents;

[TestFixture]
internal class ZipGenerationResultEventsProcessing_SadPath_Should : TestFixtureBase
{
    [Test]
    public void DiscardEventIfExportDoesNotExist()
    {
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithRandomValues()
            .WithFileId(Generate.RandomString())
            .Build();

        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillNotHaveAnyUpdatedExport()
            .And.TheMetrics.WillHaveIncreasedZipGenerationResultEventsProcessedCounterOnce(
                MetricLabelValues.Result.Discarded);
    }

    [Test]
    public void DiscardCompletedEventWithoutFileId()
    {
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithRandomValues()
            .WithState(ExportResultState.Completed)
            .WithResultDetails(new JsonObject())
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillNotHaveAnyUpdatedExport();
    }

    [Test]
    public void DiscardEventWithUnsupportedResultState()
    {
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithRandomValues()
            .WithState(ExportResultState.Unspecified)
            .Build();

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress);
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillNotHaveAnyUpdatedExport();
    }

    [Test]
    public void DiscardEventWithUnmappedEventType()
    {
        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress);
        When.TheSqsEventsQueue.ReceivesEvent(
            "com.n-able.cove.events.c2c.export.unknown",
            new JsonObject { ["id"] = Generate.RandomString() });
        Then.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheEventsProcessingQueue.WillNotHaveForwardedAnyMessageToDeadLetterQueue()
            .And.TheAmazonDynamoDb.WillNotHaveAnyUpdatedExport();
    }

    [Test]
    public void SendEventToDeadLetterQueueIfPayloadCannotBeDeserialized()
    {
        var malformedPayload = new JsonObject
        {
            ["id"] = Generate.RandomString(),
            ["state"] = "NotAKnownState",
            ["resultDetails"] = null
        };

        Given.AnAmazonDynamoDb.HasExportWithStatus(ExportStatus.InProgress);
        When.TheSqsEventsQueue.ReceivesEvent(
            "com.n-able.cove.events.c2c.export.zip.generation.result",
            malformedPayload);
        Then.TheAmazonDynamoDb.WillNotHaveAnyUpdatedExport()
            .And.TheEventsProcessingQueue.WillHaveForwardedTheMessageToDeadLetterQueue()
            .And.TheEventsProcessingQueue.WillHaveDeletedTheMessage();
    }

    [Test]
    public void SendEventToDeadLetterQueueIfDynamoDbIsUnavailable()
    {
        var payload = new ZipGenerationResultEventPayloadBuilder()
            .WithRandomValues()
            .WithState(ExportResultState.Failed)
            .Build();

        Given.AnAmazonDynamoDb.IsUnavailable();
        When.TheSqsEventsQueue.ReceivesZipGenerationResultEvent(payload);
        Then.TheEventsProcessingQueue.WillHaveForwardedTheMessageToDeadLetterQueue()
            .And.TheEventsProcessingQueue.WillHaveDeletedTheMessage()
            .And.TheMetrics.WillHaveIncreasedZipGenerationResultEventsProcessedCounterOnce(
                MetricLabelValues.Result.Failed);
    }
}
