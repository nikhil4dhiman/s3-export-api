using System;
using System.Collections.Generic;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS.Model;
using CloudNative.CloudEvents;
using CloudNative.CloudEvents.SystemTextJson;
using ExportZipManager.Data.SqsPublisher.Adapters;
using ExportZipManager.Data.SqsPublisher.Models;

namespace ExportZipManager.Api.ComponentTests.TestHelpers.Mocks;

internal class AmazonSqsPublishingAdapterMock : IAmazonSqsPublishingAdapter
{
    private static readonly JsonEventFormatter EventFormatter = new();

    private bool _shouldThrowException;
    private readonly List<PublishedMessage> _publishedMessages = [];

    public ExportZipProcessorEventPayload? ReceivedEventFor(
        string queueUrl,
        string exportId,
        string partnerId,
        string eventType)
    {
        return _publishedMessages
            .FindLast(m =>
                string.Equals(m.QueueUrl, queueUrl, StringComparison.Ordinal)
                && string.Equals(m.EventType, eventType, StringComparison.Ordinal)
                && string.Equals(m.ExportEvent.ExportId, exportId, StringComparison.Ordinal)
                && string.Equals(m.ExportEvent.PartnerId, partnerId, StringComparison.Ordinal)
                && string.Equals(m.MessageGroupId, exportId, StringComparison.Ordinal))?
            .ExportEvent;
    }

    public bool HasReceivedNoEvents()
    {
        return _publishedMessages.Count == 0;
    }

    public Task SendMessageAsync(SendMessageRequest request, CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        var cloudEvent = DecodeCloudEvent(request.MessageBody);

        _publishedMessages.Add(new PublishedMessage(
            request.QueueUrl,
            request.MessageGroupId,
            cloudEvent.Type!,
            DeserializeExportEvent(cloudEvent)));

        return Task.CompletedTask;
    }

    public void WillThrowException()
    {
        _shouldThrowException = true;
    }

    private void ThrowExceptionIfRequired()
    {
        if (_shouldThrowException)
        {
            throw new InvalidOperationException("unexpected exception from SQS Publishing");
        }
    }

    private static CloudEvent DecodeCloudEvent(string messageBody)
    {
        return EventFormatter.DecodeStructuredModeMessage(
            Encoding.UTF8.GetBytes(messageBody),
            contentType: null,
            extensionAttributes: null);
    }

    private static ExportZipProcessorEventPayload DeserializeExportEvent(CloudEvent cloudEvent)
    {
        return ((JsonElement)cloudEvent.Data!).Deserialize<ExportZipProcessorEventPayload>()
               ?? throw new InvalidOperationException(
                   "unexpected null export event from AmazonSqsPublishingAdapterMock");
    }

    private sealed record PublishedMessage(
        string QueueUrl,
        string MessageGroupId,
        string EventType,
        ExportZipProcessorEventPayload ExportEvent);
}
