using ExportZipManager.Api.ComponentTests.Framework;

namespace ExportZipManager.Api.ComponentTests.TestHelpers.Mocks;

internal class Mocks
{
    public Mocks(Scenario scenario)
    {
        _ = scenario;
    }

    public AmazonDynamoDbApiMock AmazonDynamoDbApiMock { get; } = new();

    public AmazonS3ApiMock AmazonS3ApiMock { get; } = new();

    public AmazonSqsPublishingAdapterMock AmazonSqsPublisher { get; } = new();

    public MetricsServiceMock MetricsServiceMock { get; } = new();
}
