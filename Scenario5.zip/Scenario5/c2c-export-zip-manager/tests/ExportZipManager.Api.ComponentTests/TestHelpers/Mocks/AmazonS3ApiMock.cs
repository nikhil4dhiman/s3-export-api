using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3.Model;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Data.S3.Api;

namespace ExportZipManager.Api.ComponentTests.TestHelpers.Mocks;

internal class AmazonS3ApiMock : IAmazonS3Api
{
    private bool _shouldThrowException;
    private readonly Dictionary<string, List<byte>> _exportedData = [];

    public InitiateMultipartUploadResponse InitiateUploadResponse { get; set; }
        = Generate.Random.InitiateUploadResponse();

    public UploadPartResponse UploadPartResponse { get; set; }
        = Generate.Random.UploadPartResponse();

    public List<CompleteMultipartUploadRequest> CompleteMultipartUploadRequests { get; } = [];

    public byte[] GetExportedDataFor(string fileName)
    {
        return [.. _exportedData[fileName]];
    }

    public void AddStagedFile(string key)
    {
        _exportedData[key] = [];
    }

    public bool HasStagedFilesFor(string exportId)
    {
        var prefix = $"exports/{exportId}/staging/";

        return _exportedData.Keys.Any(k => k.StartsWith(prefix, StringComparison.Ordinal));
    }

    public Task<InitiateMultipartUploadResponse> InitiateMultipartUploadAsync(
        InitiateMultipartUploadRequest initiateUploadRequest,
        CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        _exportedData[initiateUploadRequest.Key] = [];

        return Task.FromResult(InitiateUploadResponse);
    }

    public async Task<UploadPartResponse> UploadPartAsync(
        UploadPartRequest uploadPartRequest,
        CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        using var dataStream = new MemoryStream();
        await uploadPartRequest.InputStream.CopyToAsync(dataStream, cancellationToken);

        if (!_exportedData.TryGetValue(uploadPartRequest.Key, out var data))
        {
            data = [];
            _exportedData[uploadPartRequest.Key] = data;
        }

        data.AddRange(dataStream.ToArray());

        return UploadPartResponse;
    }

    public Task<CompleteMultipartUploadResponse> CompleteMultipartUploadAsync(
        CompleteMultipartUploadRequest completeUploadRequest,
        CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        CompleteMultipartUploadRequests.Add(completeUploadRequest);

        return Task.FromResult(new CompleteMultipartUploadResponse());
    }

    public Task<ListObjectsV2Response> ListObjectsV2Async(
        ListObjectsV2Request request,
        CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        var matchingObjects = _exportedData.Keys
            .Where(k => k.StartsWith(request.Prefix, StringComparison.Ordinal))
            .Select(k => new S3Object { Key = k })
            .ToList();

        return Task.FromResult(new ListObjectsV2Response { S3Objects = matchingObjects });
    }

    public Task DeleteObjectsAsync(
        DeleteObjectsRequest request,
        CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        foreach (var key in request.Objects.Select(o => o.Key))
        {
            _exportedData.Remove(key);
        }

        return Task.CompletedTask;
    }

    public async Task PutObjectAsync(PutObjectRequest request, CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        using var dataStream = new MemoryStream();
        await request.InputStream.CopyToAsync(dataStream, cancellationToken);

        if (!_exportedData.TryGetValue(request.Key, out var data))
        {
            data = [];
            _exportedData[request.Key] = data;
        }

        data.AddRange(dataStream.ToArray());
    }

    public void WillThrowException()
    {
        _shouldThrowException = true;
    }

    private void ThrowExceptionIfRequired()
    {
        if (_shouldThrowException)
        {
            throw new InvalidOperationException("unexpected exception from AmazonS3ApiMock");
        }
    }
}
