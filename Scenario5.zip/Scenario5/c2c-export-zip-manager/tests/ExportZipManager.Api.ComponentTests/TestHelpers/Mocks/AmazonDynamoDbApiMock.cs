using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using ExportZipManager.Data.DynamoDb.Api;
using ExportStatus = ExportZipManager.Domain.Models.Exports.ExportStatus;

namespace ExportZipManager.Api.ComponentTests.TestHelpers.Mocks;

internal class AmazonDynamoDbApiMock : IAmazonDynamoDbApi
{
    private const string StatusValueKey = ":status";
    private const string ZipRequestedAtValueKey = ":zipRequestedAt";
    private const string TerminalAtValueKey = ":terminalAt";

    private bool _shouldThrowException;
    private ExportStatus? _existingExportStatus;
    private string? _existingExportFileId;
    private readonly List<Dictionary<string, AttributeValue>> _writtenItems = [];
    private readonly List<UpdateItemRequest> _updateRequests = [];

    /// <summary>
    /// The timestamps the table would hold after everything the scenario did, rather than the values
    /// individual requests carried. Conditional writes mean the two can differ.
    /// </summary>
    public DateTimeOffset StoredStartedAt { get; private set; }

    public DateTimeOffset? StoredZipRequestedAt { get; private set; }

    public DateTimeOffset? StoredCompletedAt { get; private set; }

    public DateTimeOffset? StoredCancelledAt { get; private set; }

    public bool HasUpdatedExportWith(string exportId, string status, string? fileId = null)
    {
        return StatusUpdatesFor(exportId).Any(request =>
            string.Equals(request.ExpressionAttributeValues[StatusValueKey].S, status, StringComparison.Ordinal)
            && (fileId is null
                ? request.ExpressionAttributeValues[":fileId"].NULL == true
                : string.Equals(request.ExpressionAttributeValues[":fileId"].S, fileId, StringComparison.Ordinal)));
    }

    public bool HasAnyUpdatedExport()
    {
        return _updateRequests.Any(IsStatusUpdate);
    }

    public bool HasItemWithExportId(string exportId, string status)
    {
        return WrittenItemsFor(exportId).Any(item =>
            item.TryGetValue("Status", out var statusAttr)
            && string.Equals(statusAttr.S, status, StringComparison.Ordinal));
    }

    public Task PutItemAsync(PutItemRequest request, CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        if (_existingExportStatus is not null)
        {
            throw new ConditionalCheckFailedException("Item already exists");
        }

        _writtenItems.Add(request.Item);

        // The real table now holds the record, so a later create must fail its conditional check and
        // a later read must see what was written.
        _existingExportStatus = Enum.Parse<ExportStatus>(request.Item["Status"].S);
        _existingExportFileId = request.Item.TryGetValue("FileId", out var fileId) && fileId.NULL != true
            ? fileId.S
            : null;
        StoredStartedAt = ReadTimestamp(request.Item, "StartedAt")
            ?? throw new InvalidOperationException("PutItemRequest is missing required attribute 'StartedAt'.");
        StoredZipRequestedAt = ReadTimestamp(request.Item, "ZipRequestedAt");
        StoredCompletedAt = ReadTimestamp(request.Item, "CompletedAt");
        StoredCancelledAt = ReadTimestamp(request.Item, "CancelledAt");

        return Task.CompletedTask;
    }

    public Task UpdateItemAsync(UpdateItemRequest request, CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        if (_existingExportStatus is null)
        {
            throw new ConditionalCheckFailedException("Item does not exist");
        }

        if (IsStatusUpdate(request) && _existingExportStatus == ExportStatus.Cancelled)
        {
            throw new ConditionalCheckFailedException("Export is cancelled")
            {
                Item = BuildItem(request.Key["Id"].S)
            };
        }

        _updateRequests.Add(request);

        if (IsStatusUpdate(request))
        {
            _existingExportStatus = Enum.Parse<ExportStatus>(request.ExpressionAttributeValues[StatusValueKey].S);
            _existingExportFileId = request.ExpressionAttributeValues[":fileId"].NULL == true
                ? null
                : request.ExpressionAttributeValues[":fileId"].S;

            var terminalAt = ParseTimestamp(request.ExpressionAttributeValues[TerminalAtValueKey].S);

            if (_existingExportStatus == ExportStatus.Cancelled)
            {
                StoredCancelledAt = terminalAt;
            }
            else
            {
                StoredCompletedAt = terminalAt;
            }
        }
        else
        {
            // Mirrors if_not_exists in the update expression: the first request time wins.
            StoredZipRequestedAt ??=
                ParseTimestamp(request.ExpressionAttributeValues[ZipRequestedAtValueKey].S);
        }

        return Task.CompletedTask;
    }

    public Task<GetItemResponse> GetItemAsync(GetItemRequest request, CancellationToken cancellationToken)
    {
        ThrowExceptionIfRequired();

        var response = new GetItemResponse();

        if (_existingExportStatus is not null)
        {
            response.Item = BuildItem(request.Key["Id"].S);
        }

        return Task.FromResult(response);
    }

    public void WillThrowException()
    {
        _shouldThrowException = true;
    }

    public void HasExistingExportWithStatus(
        ExportStatus status,
        string? fileId = null,
        DateTimeOffset startedAt = default,
        DateTimeOffset? zipRequestedAt = null)
    {
        _existingExportStatus = status;
        _existingExportFileId = fileId;
        StoredStartedAt = startedAt;
        StoredZipRequestedAt = zipRequestedAt;
    }

    private static bool IsStatusUpdate(UpdateItemRequest request)
    {
        return request.ExpressionAttributeValues.ContainsKey(StatusValueKey);
    }

    private static DateTimeOffset? ReadTimestamp(Dictionary<string, AttributeValue> item, string key)
    {
        return item.TryGetValue(key, out var attribute) && attribute.NULL != true
            ? ParseTimestamp(attribute.S)
            : null;
    }

    private static DateTimeOffset? ParseTimestamp(string? value)
    {
        return DateTimeOffset.TryParse(
            value,
            CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind,
            out var timestamp)
            ? timestamp
            : null;
    }

    private static AttributeValue ToAttributeValue(DateTimeOffset? value)
    {
        return value is null
            ? new AttributeValue { NULL = true }
            : new AttributeValue { S = value.Value.ToString("O", CultureInfo.InvariantCulture) };
    }

    private IEnumerable<Dictionary<string, AttributeValue>> WrittenItemsFor(string exportId)
    {
        return _writtenItems.Where(item =>
            item.TryGetValue("Id", out var id) && string.Equals(id.S, exportId, StringComparison.Ordinal));
    }

    private IEnumerable<UpdateItemRequest> StatusUpdatesFor(string exportId)
    {
        return _updateRequests
            .Where(request => string.Equals(request.Key["Id"].S, exportId, StringComparison.Ordinal))
            .Where(IsStatusUpdate);
    }

    private Dictionary<string, AttributeValue> BuildItem(string exportId)
    {
        return new Dictionary<string, AttributeValue>
        {
            ["Id"] = new() { S = exportId },
            ["Status"] = new() { S = _existingExportStatus.ToString() },
            ["FileId"] = _existingExportFileId is null
                ? new AttributeValue { NULL = true }
                : new AttributeValue { S = _existingExportFileId },
            ["StartedAt"] = ToAttributeValue(StoredStartedAt),
            ["ZipRequestedAt"] = ToAttributeValue(StoredZipRequestedAt),
            ["CompletedAt"] = ToAttributeValue(StoredCompletedAt),
            ["CancelledAt"] = ToAttributeValue(StoredCancelledAt)
        };
    }

    private void ThrowExceptionIfRequired()
    {
        if (_shouldThrowException)
        {
            throw new AmazonDynamoDBException("Unexpected exception from DynamoDB");
        }
    }
}
