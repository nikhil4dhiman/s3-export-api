using System.Collections.Generic;
using System.Linq;
using ExportZipManager.Domain.Metrics;

namespace ExportZipManager.Api.ComponentTests.TestHelpers.Mocks;

internal class MetricsServiceMock : IMetricsService
{
    private readonly List<(string Result, double DurationInSeconds)> _exportDurations = [];
    private readonly List<(string Result, double DurationInSeconds)> _zipProcessingDurations = [];
    private readonly List<string> _exportsCompletedResults = [];
    private readonly List<string> _zipGenerationResultEventsProcessedResults = [];
    private readonly List<string> _zipGenerationEventsPublishedResults = [];

    public void IncreaseNumberOfZipGenerationEventsPublished(string result)
    {
        _zipGenerationEventsPublishedResults.Add(result);
    }

    public void IncreaseNumberOfZipGenerationResultEventsProcessed(string result)
    {
        _zipGenerationResultEventsProcessedResults.Add(result);
    }

    public void IncreaseNumberOfExportsStarted()
    {
        ExportsStartedCount++;
    }

    public void IncreaseNumberOfExportsCompleted(string result)
    {
        _exportsCompletedResults.Add(result);
    }

    public void IncreaseNumberOfExportsCancelled()
    {
        ExportsCancelledCount++;
    }

    public void ObserveExportDuration(string result, double durationInSeconds)
    {
        _exportDurations.Add((result, durationInSeconds));
    }

    public void ObserveExportZipProcessingDuration(string result, double durationInSeconds)
    {
        _zipProcessingDurations.Add((result, durationInSeconds));
    }

    public IReadOnlyCollection<double> GetExportDurations(string result)
    {
        return DurationsWithResult(_exportDurations, result);
    }

    public IReadOnlyCollection<double> GetZipProcessingDurations(string result)
    {
        return DurationsWithResult(_zipProcessingDurations, result);
    }

    public bool HasObservedAnyDuration()
    {
        return _exportDurations.Count > 0 || _zipProcessingDurations.Count > 0;
    }

    public bool HasObservedAnyZipProcessingDuration()
    {
        return _zipProcessingDurations.Count > 0;
    }

    public int GetExportsCompletedCount(string result)
    {
        return _exportsCompletedResults.Count(recordedResult => recordedResult == result);
    }

    public bool HasIncreasedExportsCompletedCounter()
    {
        return _exportsCompletedResults.Count > 0;
    }

    public int GetZipGenerationEventsPublishedCount(string result)
    {
        return _zipGenerationEventsPublishedResults.Count(
            recordedResult => recordedResult == result);
    }

    public int GetZipGenerationResultEventsProcessedCount(string result)
    {
        return _zipGenerationResultEventsProcessedResults.Count(
            recordedResult => recordedResult == result);
    }

    public int ExportsStartedCount { get; private set; }

    public int ExportsCancelledCount { get; private set; }

    private static IReadOnlyCollection<double> DurationsWithResult(
        List<(string Result, double DurationInSeconds)> observations,
        string result)
    {
        return
        [
            .. observations
                .Where(observation => observation.Result == result)
                .Select(observation => observation.DurationInSeconds)
        ];
    }
}
