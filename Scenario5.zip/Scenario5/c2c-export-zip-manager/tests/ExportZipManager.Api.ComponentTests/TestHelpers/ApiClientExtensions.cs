using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Mime;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Testing.SharedHelpers.Api;
using ExportZipManager.Api.ComponentTests.Framework;
using Microsoft.AspNetCore.Http;

namespace ExportZipManager.Api.ComponentTests.TestHelpers;

internal static class ApiClientExtensions
{
    private static readonly MediaTypeHeaderValue OctetStreamContentType = new(MediaTypeNames.Application.Octet);

    private static readonly MediaTypeHeaderValue JsonContentType = new(MediaTypeNames.Application.Json);

    private static readonly MethodInfo SetResponseAsyncMethod = typeof(ApiResponse).GetMethod(
        "SetResponseAsync",
        BindingFlags.Instance | BindingFlags.NonPublic)!;

    public static void PostOctetStream(
        this Scenario scenario,
        string path,
        IDictionary<string, string?> queryParams,
        byte[]? content)
    {
        var pathWithQueryParams = path + QueryString.Create(queryParams);

        SendAsync(scenario, pathWithQueryParams, content, OctetStreamContentType).GetAwaiter().GetResult();
    }

    /// <summary>
    /// Posts a body verbatim so tests can send payloads the typed request models cannot express,
    /// such as a source type outside the enum.
    /// </summary>
    public static void PostRawJson(this Scenario scenario, string path, string json)
    {
        SendAsync(scenario, path, Encoding.UTF8.GetBytes(json), JsonContentType).GetAwaiter().GetResult();
    }

    /// <summary>Posts with no body at all, for endpoints that now require one.</summary>
    public static void PostNoBody(this Scenario scenario, string path)
    {
        SendAsync(scenario, path, content: null, JsonContentType).GetAwaiter().GetResult();
    }

    private static async Task SendAsync(
        Scenario scenario,
        string path,
        byte[]? content,
        MediaTypeHeaderValue contentType)
    {
        using var requestMessage = BuildRequest(scenario, path, content, contentType);
        using var response = await scenario.SutHttpClient.SendAsync(requestMessage);

        await SetResponseToScenarioAsync(scenario, response);
    }

    private static HttpRequestMessage BuildRequest(
        Scenario scenario,
        string path,
        byte[]? content,
        MediaTypeHeaderValue contentType)
    {
        var requestMessage = new HttpRequestMessage(HttpMethod.Post, path);

        foreach (var header in scenario.ApiRequest.Headers)
        {
            requestMessage.Headers.TryAddWithoutValidation(header.Key, header.Value);
        }

        if (content is not null)
        {
            requestMessage.Content = new ByteArrayContent(content)
            {
                Headers = { ContentType = contentType }
            };
        }

        return requestMessage;
    }

    private static Task SetResponseToScenarioAsync(Scenario scenario, HttpResponseMessage response)
    {
        return (Task)SetResponseAsyncMethod.Invoke(scenario.ApiResponse, [response])!;
    }
}
