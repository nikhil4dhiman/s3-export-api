using Amazon.S3.Model;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.Tests.Core.Builders.S3.Api;

namespace ExportZipManager.Api.ComponentTests.TestHelpers;

internal static class GenerateRandomExtensions
{
    public static InitiateMultipartUploadResponse InitiateUploadResponse(this RandomExtensionPoint _)
    {
        return new InitiateMultipartUploadResponseBuilder().WithRandomValues().Build();
    }

    public static UploadPartResponse UploadPartResponse(this RandomExtensionPoint _)
    {
        return new UploadPartResponseBuilder().WithRandomValues().Build();
    }
}
