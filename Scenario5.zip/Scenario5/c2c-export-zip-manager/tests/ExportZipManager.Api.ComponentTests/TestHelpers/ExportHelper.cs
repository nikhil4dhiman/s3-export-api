namespace ExportZipManager.Api.ComponentTests.TestHelpers;

internal static class ExportHelper
{
    public static string BuildStagingFileKey(string exportId, string? fileName)
    {
        return $"exports/{exportId}/staging/{fileName}";
    }
}
