using System;
using System.Net.Mime;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using Amazon.SQS.Model;
using CloudNative.CloudEvents;
using CloudNative.CloudEvents.SystemTextJson;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.BackgroundServices.AwsSqs.Constants;
using ExportZipManager.BackgroundServices.AwsSqs.Models;

namespace ExportZipManager.Api.ComponentTests.Steps.When.Sqs;

internal class TheSqsEventsQueueStep : Step<WhenStep, Scenario>
{
    private const string EventSource = "urn:c2c-export-zip-processor";

    private static readonly JsonEventFormatter EventFormatter = new();

    private static readonly JsonSerializerOptions PayloadSerializerOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public IAnd<WhenStep> ReceivesZipGenerationResultEvent(ZipGenerationResultEventPayload payload)
    {
        var payloadNode = JsonSerializer.SerializeToNode(payload, PayloadSerializerOptions)!;

        return ReceivesEvent(EventTypes.ZipGenerationResult, payloadNode);
    }

    public IAnd<WhenStep> ReceivesEvent(string eventType, JsonNode payload)
    {
        var message = BuildSqsMessage(Scenario, eventType, payload);

        Scenario.EventsProcessingSqsTransport
            .WaitForProcessingAsync([message])
            .GetAwaiter()
            .GetResult();

        return AndStep;
    }

    private static Message BuildSqsMessage(Scenario scenario, string eventType, JsonNode payload)
    {
        var cloudEvent = new CloudEvent(CloudEventsSpecVersion.V1_0)
        {
            Id = Generate.RandomString(),
            Type = eventType,
            Source = new Uri(EventSource),
            Time = scenario.TimeProvider.GetUtcNow(),
            DataContentType = MediaTypeNames.Application.Json,
            Data = JsonSerializer.Deserialize<JsonElement>(payload.ToJsonString())
        };

        var cloudEventJson = Encoding.UTF8.GetString(
            EventFormatter.EncodeStructuredModeMessage(cloudEvent, out _).ToArray());

        return new Message
        {
            MessageId = Generate.RandomString(),
            ReceiptHandle = Generate.RandomString(),
            Body = cloudEventJson
        };
    }
}
