using System.Collections.Generic;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.TestHelpers;
using ExportZipManager.Api.Constants;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.ComponentTests.Steps.When.Request;

internal class TheExportsApiStep : Step<WhenStep, Scenario>
{
    public IAnd<WhenStep> StartEndpoint(StartExportRequest request)
    {
        Scenario.ApiClient.Post(Routes.ExportStartPath(), request);

        return AndStep;
    }

    public IAnd<WhenStep> StartMultipartFileEndpoint(string exportId, StartMultipartFileRequest request)
    {
        Scenario.ApiClient.Post(Routes.StartMultipartFilePath(exportId), request);

        return AndStep;
    }

    public IAnd<WhenStep> UploadMultipartFilePartEndpoint(
        string exportId,
        UploadMultipartFilePartRequestQuery query,
        byte[]? data)
    {
        var queryParams = new Dictionary<string, string?>();
        if (query.FileName is not null)
        {
            queryParams.Add(nameof(query.FileName), query.FileName);
        }

        if (query.UploadId is not null)
        {
            queryParams.Add(nameof(query.UploadId), query.UploadId);
        }

        if (query.PartNumber.HasValue)
        {
            queryParams.Add(nameof(query.PartNumber), query.PartNumber.ToString());
        }

        Scenario.PostOctetStream(Routes.UploadMultipartFilePartPath(exportId), queryParams, data);

        return AndStep;
    }

    public IAnd<WhenStep> UploadFileEndpoint(string exportId, UploadFileRequestQuery query, byte[]? fileContent)
    {
        var queryParams = new Dictionary<string, string?>();

        if (query.FileName is not null)
        {
            queryParams.Add(nameof(query.FileName), query.FileName);
        }

        Scenario.PostOctetStream(Routes.UploadFilePath(exportId), queryParams, fileContent);

        return AndStep;
    }

    public IAnd<WhenStep> CompleteMultipartFileEndpoint(string exportId, CompleteMultipartFileRequest request)
    {
        Scenario.ApiClient.Post(Routes.CompleteMultipartFilePath(exportId), request);

        return AndStep;
    }

    public IAnd<WhenStep> CancelEndpoint(string exportId)
    {
        Scenario.ApiClient.Post(Routes.ExportCancelPath(exportId), null);

        return AndStep;
    }

    public IAnd<WhenStep> CompleteEndpoint(string exportId, CompleteExportRequest? request = null)
    {
        Scenario.ApiClient.Post(Routes.ExportCompletePath(exportId), request);

        return AndStep;
    }

    public IAnd<WhenStep> CompleteEndpointWithNoBody(string exportId)
    {
        Scenario.PostNoBody(Routes.ExportCompletePath(exportId));

        return AndStep;
    }

    /// <summary>
    /// Posts the complete request body verbatim, for payloads the typed request model cannot
    /// express - a source type outside the enum, or an unknown source type name.
    /// </summary>
    public IAnd<WhenStep> CompleteEndpointWithRawBody(string exportId, string json)
    {
        Scenario.PostRawJson(Routes.ExportCompletePath(exportId), json);

        return AndStep;
    }

    public IAnd<WhenStep> StatusEndpoint(string exportId)
    {
        Scenario.ApiClient.Get(Routes.ExportStatusPath(exportId));

        return AndStep;
    }
}
