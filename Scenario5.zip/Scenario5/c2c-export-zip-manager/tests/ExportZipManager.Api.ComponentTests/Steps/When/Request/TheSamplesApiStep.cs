using System.Collections.Generic;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Constants;
using ExportZipManager.Api.Models.Samples.Requests;

namespace ExportZipManager.Api.ComponentTests.Steps.When.Request;

internal class TheSamplesApiStep : Step<WhenStep, Scenario>
{
    public IAnd<WhenStep> GetPageEndpoint(GetSamplesRequestQuery query)
    {
        var queryParams = new Dictionary<string, string?>();
        if (query.Take.HasValue)
        {
            queryParams.Add("take", query.Take.ToString());
        }

        if (query.Skip.HasValue)
        {
            queryParams.Add("skip", query.Skip.ToString());
        }

        Scenario.ApiClient.Get(Routes.Samples, queryParams);

        return AndStep;
    }

    public IAnd<WhenStep> GetByIdEndpoint(string id)
    {
        Scenario.ApiClient.GetById(Routes.Samples, id);

        return AndStep;
    }

    public IAnd<WhenStep> CreateEndpoint(CreateSampleRequest request)
    {
        Scenario.ApiClient.Post(Routes.Samples, request);

        return AndStep;
    }
}
