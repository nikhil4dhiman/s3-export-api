using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.Tests.Core.Builders.Samples.Api;

namespace ExportZipManager.Api.ComponentTests.Steps.When.Request;

internal class ICallStep : Step<WhenStep, Scenario>
{
    public TheSamplesApiStep TheSamplesApi => StepFactory<TheSamplesApiStep>();

    public TheExportsApiStep TheExportsApi => StepFactory<TheExportsApiStep>();

    public IAnd<WhenStep> AnyEndpoint()
    {
        if (Generate.RandomBool())
        {
            TheSamplesApi.GetByIdEndpoint(Generate.RandomString());
        }
        else
        {
            var request = new CreateSampleRequestBuilder().WithRandomValues().Build();
            TheSamplesApi.CreateEndpoint(request);
        }

        return AndStep;
    }
}
