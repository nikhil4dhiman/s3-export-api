using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.When.Request;
using ExportZipManager.Api.ComponentTests.Steps.When.Sqs;

namespace ExportZipManager.Api.ComponentTests.Steps.When;

internal class WhenStep : RootStep<WhenStep, Scenario>
{
    public ICallStep ICall => StepFactory<ICallStep>();

    public TheSqsEventsQueueStep TheSqsEventsQueue => StepFactory<TheSqsEventsQueueStep>();
}
