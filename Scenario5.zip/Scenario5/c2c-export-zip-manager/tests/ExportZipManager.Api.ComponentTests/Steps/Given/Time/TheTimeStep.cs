using System;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;

namespace ExportZipManager.Api.ComponentTests.Steps.Given.Time;

internal class TheTimeStep : Step<GivenStep, Scenario>
{
    /// <summary>
    /// The instant the scenario is currently frozen at. The fake clock refuses to move backwards, so
    /// tests express the timestamps they expect relative to this rather than as fixed dates.
    /// </summary>
    public DateTimeOffset Now => Scenario.TimeProvider.GetUtcNow();

    public IAnd<GivenStep> AdvancesBy(TimeSpan duration)
    {
        Scenario.TimeProvider.Advance(duration);

        return AndStep;
    }
}
