using Amazon.S3.Model;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;

namespace ExportZipManager.Api.ComponentTests.Steps.Given.S3;

internal class AnAmazonS3Step : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> WillInitiateMultipartUploadWith(InitiateMultipartUploadResponse response)
    {
        Scenario.Mocks.AmazonS3ApiMock.InitiateUploadResponse = response;

        return AndStep;
    }

    public IAnd<GivenStep> WillUploadPartWith(UploadPartResponse response)
    {
        Scenario.Mocks.AmazonS3ApiMock.UploadPartResponse = response;

        return AndStep;
    }

    public IAnd<GivenStep> HasStagedFilesFor(string exportId, params string[] fileNames)
    {
        var prefix = $"exports/{exportId}/staging/";

        foreach (var fileName in fileNames)
        {
            Scenario.Mocks.AmazonS3ApiMock.AddStagedFile($"{prefix}{fileName}");
        }

        return AndStep;
    }

    public IAnd<GivenStep> DoesNotHaveAnyStagedFilesFor(string _)
    {
        return AndStep;
    }

    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Mocks.AmazonS3ApiMock.WillThrowException();

        return AndStep;
    }
}
