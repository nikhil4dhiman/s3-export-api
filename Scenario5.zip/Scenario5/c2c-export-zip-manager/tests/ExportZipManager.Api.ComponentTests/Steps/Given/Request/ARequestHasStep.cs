using System;
using System.Text;
using Cove.Platform.Extensions.Communication.Constants.Http;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using idunno.Authentication.Basic;

namespace ExportZipManager.Api.ComponentTests.Steps.Given.Request;

internal class ARequestHasStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> ValidBasicAuthCredentials()
    {
        BasicAuthCredentials(AuthenticationTestConstants.UserName, AuthenticationTestConstants.Password);

        return AndStep;
    }

    public IAnd<GivenStep> InvalidBasicAuthCredentials()
    {
        Scenario.ApiRequest.Headers.Remove("Authorization");

        BasicAuthCredentials("invalidUser", "invalidPassword");

        return AndStep;
    }

    public IAnd<GivenStep> ValidUserIdHeader()
    {
        return UserIdHeader(Generate.RandomString());
    }

    public IAnd<GivenStep> InvalidUserIdHeader()
    {
        return UserIdHeader(string.Empty);
    }

    public IAnd<GivenStep> PartnerIdHeader(string partnerId)
    {
        Scenario.ApiRequest.Headers[KnownHttpHeaders.PartnerId] = partnerId;

        return AndStep;
    }

    private IAnd<GivenStep> BasicAuthCredentials(
        string userName,
        string password,
        string scheme = BasicAuthenticationDefaults.AuthenticationScheme)
    {
        var credentials = Convert.ToBase64String(Encoding.UTF8.GetBytes($"{userName}:{password}"));
        Scenario.ApiRequest.AddAuthorizationHeader(scheme, credentials);

        return AndStep;
    }

    private IAnd<GivenStep> UserIdHeader(string userId)
    {
        Scenario.ApiRequest.Headers[KnownHttpHeaders.UserId] = userId;

        return AndStep;
    }
}
