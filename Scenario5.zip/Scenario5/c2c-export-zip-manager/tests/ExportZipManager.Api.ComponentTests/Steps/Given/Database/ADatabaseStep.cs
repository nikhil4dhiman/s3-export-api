using System;
using System.Collections.Generic;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Data.PostgreSql.Mapping;
using ExportZipManager.Domain.Models;

namespace ExportZipManager.Api.ComponentTests.Steps.Given.Database;

internal class ADatabaseStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> HasSamples(params IEnumerable<Sample> samples)
    {
        using var dbContextScope = Scenario.Database.DbContextScope;

        var entities = samples.ToEntityModels();

        dbContextScope.DbContext.Samples.AddRange(entities);
        dbContextScope.DbContext.SaveChanges();

        return AndStep;
    }

    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Database.QueriesInterceptor.ExceptionToThrowOnApplyingChanges =
            new InvalidOperationException("unexpected exception from database");

        return AndStep;
    }
}
