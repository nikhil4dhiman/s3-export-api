using System;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Api.ComponentTests.Steps.Given.DynamoDb;

internal class AnAmazonDynamoDbStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Mocks.AmazonDynamoDbApiMock.WillThrowException();

        return AndStep;
    }

    public IAnd<GivenStep> HasExportWithStatus(
        ExportStatus status,
        string? fileId = null,
        DateTimeOffset? startedAt = null,
        DateTimeOffset? zipRequestedAt = null)
    {
        Scenario.Mocks.AmazonDynamoDbApiMock.HasExistingExportWithStatus(
            status,
            fileId,
            startedAt ?? Scenario.TimeProvider.GetUtcNow(),
            zipRequestedAt);

        return AndStep;
    }
}
