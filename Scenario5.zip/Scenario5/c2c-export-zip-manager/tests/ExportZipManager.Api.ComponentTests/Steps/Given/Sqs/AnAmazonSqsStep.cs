using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;

namespace ExportZipManager.Api.ComponentTests.Steps.Given.Sqs;

internal class AnAmazonSqsStep : Step<GivenStep, Scenario>
{
    public IAnd<GivenStep> IsUnavailable()
    {
        Scenario.Mocks.AmazonSqsPublisher.WillThrowException();

        return AndStep;
    }
}
