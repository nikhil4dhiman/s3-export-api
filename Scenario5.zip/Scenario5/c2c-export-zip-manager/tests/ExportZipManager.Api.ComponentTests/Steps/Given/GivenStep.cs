using Cove.Platform.Extensions.Identifiers.Testing;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Given.Database;
using ExportZipManager.Api.ComponentTests.Steps.Given.DynamoDb;
using ExportZipManager.Api.ComponentTests.Steps.Given.Request;
using ExportZipManager.Api.ComponentTests.Steps.Given.S3;
using ExportZipManager.Api.ComponentTests.Steps.Given.Sqs;
using ExportZipManager.Api.ComponentTests.Steps.Given.Time;

namespace ExportZipManager.Api.ComponentTests.Steps.Given;

internal class GivenStep : RootStep<GivenStep, Scenario>
{
    public ARequestHasStep ARequestHas => StepFactory<ARequestHasStep>();

    public ADatabaseStep ADatabase => StepFactory<ADatabaseStep>();

    public AnIdGeneratorStep<GivenStep, Scenario> AnIdGenerator
        => StepFactory<AnIdGeneratorStep<GivenStep, Scenario>>();

    public AnAmazonDynamoDbStep AnAmazonDynamoDb => StepFactory<AnAmazonDynamoDbStep>();

    public AnAmazonS3Step AnAmazonS3 => StepFactory<AnAmazonS3Step>();

    public AnAmazonSqsStep AnAmazonSqs => StepFactory<AnAmazonSqsStep>();

    public TheTimeStep TheTime => StepFactory<TheTimeStep>();
}
