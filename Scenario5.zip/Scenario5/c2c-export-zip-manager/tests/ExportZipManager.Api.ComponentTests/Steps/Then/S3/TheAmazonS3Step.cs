using System.Linq;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipManager.Api.ComponentTests.Steps.Then.S3;

internal class TheAmazonS3Step : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHaveCompletedMultipartUploadFor(
        string key,
        string uploadId,
        params (int PartNumber, string ETag)[] expectedParts)
    {
        var request = Scenario.Mocks.AmazonS3ApiMock.CompleteMultipartUploadRequests
            .Should()
            .ContainSingle()
            .Subject;

        request.Key.Should().Be(key);
        request.UploadId.Should().Be(uploadId);
        request.PartETags.Select(p => (p.PartNumber!.Value, p.ETag))
            .Should()
            .Equal(expectedParts);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveExportedDataFor(string key, byte[] expectedData)
    {
        Scenario.Mocks.AmazonS3ApiMock.GetExportedDataFor(key)
            .Should()
            .Equal(expectedData);

        return AndStep;
    }

    public IAnd<ThenStep> HasNoStagedFilesFor(string exportId)
    {
        Scenario.Mocks.AmazonS3ApiMock.HasStagedFilesFor(exportId).Should().BeFalse();

        return AndStep;
    }

    public IAnd<ThenStep> HasStagedFilesFor(string exportId)
    {
        Scenario.Mocks.AmazonS3ApiMock.HasStagedFilesFor(exportId).Should().BeTrue();

        return AndStep;
    }
}
