using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using Cove.Platform.Extensions.Testing.SharedHelpers.Api;
using Cove.Platform.Extensions.Testing.SharedHelpers.Api.RequestsTracking;
using Cove.Platform.Extensions.Testing.SharedHelpers.Logging;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Steps.Then.Database;
using ExportZipManager.Api.ComponentTests.Steps.Then.DynamoDb;
using ExportZipManager.Api.ComponentTests.Steps.Then.Metrics;
using ExportZipManager.Api.ComponentTests.Steps.Then.S3;
using ExportZipManager.Api.ComponentTests.Steps.Then.Sqs;

namespace ExportZipManager.Api.ComponentTests.Steps.Then;

internal class ThenStep : RootStep<ThenStep, Scenario>
{
    public TheCallStep<ThenStep, Scenario> TheCall => StepFactory<TheCallStep<ThenStep, Scenario>>();

    public ApplicationLogsStep<ThenStep, Scenario> ApplicationLogs
        => StepFactory<ApplicationLogsStep<ThenStep, Scenario>>();

    public ExecutedRequestsStep<ThenStep, Scenario> ExecutedRequests
        => StepFactory<ExecutedRequestsStep<ThenStep, Scenario>>();

    public TheDatabaseStep TheDatabase => StepFactory<TheDatabaseStep>();

    public TheAmazonDynamoDbStep TheAmazonDynamoDb => StepFactory<TheAmazonDynamoDbStep>();

    public TheMetricsStep TheMetrics => StepFactory<TheMetricsStep>();

    public TheAmazonS3Step TheAmazonS3 => StepFactory<TheAmazonS3Step>();

    public TheAmazonSqsStep TheAmazonSqs => StepFactory<TheAmazonSqsStep>();

    public TheEventsProcessingQueueStep TheEventsProcessingQueue => StepFactory<TheEventsProcessingQueueStep>();
}
