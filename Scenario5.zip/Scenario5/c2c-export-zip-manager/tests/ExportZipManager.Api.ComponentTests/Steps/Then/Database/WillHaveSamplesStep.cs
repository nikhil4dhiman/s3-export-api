using System.Collections.Generic;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Data.PostgreSql.Mapping;
using ExportZipManager.Domain.Models;
using FluentAssertions;

namespace ExportZipManager.Api.ComponentTests.Steps.Then.Database;

internal class WillHaveSamplesStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> EqualTo(params IEnumerable<Sample> samples)
    {
        using var dbContextScope = Scenario.Database.DbContextScope;

        var existingSamples = dbContextScope.DbContext.Samples.ToDomainModels();

        existingSamples
            .Should()
            .BeEquivalentTo(samples, o => o.RespectingRuntimeTypes());

        return AndStep;
    }
}
