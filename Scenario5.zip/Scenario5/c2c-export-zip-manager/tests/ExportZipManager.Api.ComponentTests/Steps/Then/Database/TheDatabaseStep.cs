using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipManager.Api.ComponentTests.Steps.Then.Database;

internal class TheDatabaseStep : Step<ThenStep, Scenario>
{
    public WillHaveSamplesStep WillHaveSamples => StepFactory<WillHaveSamplesStep>();

    public IAnd<ThenStep> WillNotBeCalled()
    {
        Scenario.Database.QueriesInterceptor.CallsCount.Should().Be(0);

        return AndStep;
    }
}
