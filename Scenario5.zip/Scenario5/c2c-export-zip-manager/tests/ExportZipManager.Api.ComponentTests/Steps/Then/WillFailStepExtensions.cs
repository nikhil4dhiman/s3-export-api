using System;
using System.Collections.Generic;
using System.Collections.Immutable;
using System.Linq.Expressions;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using Cove.Platform.Extensions.Testing.SharedHelpers.Api;
using Cove.Platform.Extensions.Testing.SharedHelpers.Api.RequestsTracking;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.RequestPipeline.ErrorsHandling;

namespace ExportZipManager.Api.ComponentTests.Steps.Then;

internal static class WillFailStepExtensions
{
    public static IAnd<ThenStep> WithValidationProblemDetailsForMissingPathParameter(
        this WillFailStep<ThenStep, Scenario> step,
        string parameterName)
    {
        return step.WithValidationProblemDetailsForMissingPathParameter(
            parameterName,
            ServerErrorCodes.ValidationError,
            (builder, scenario) => builder.WithTraceIdExtension(scenario).WithRequestIdExtension(scenario));
    }

    public static IAnd<ThenStep> WithValidationProblemDetailsFor<TValidated>(
        this WillFailStep<ThenStep, Scenario> step,
        Expression<Func<TValidated, object?>> propertySelector,
        string errorMessage,
        IDictionary<string, string>? placeholders = null)
    {
        return step.WithValidationProblemDetailsFor(
            propertySelector,
            errorMessage,
            ServerErrorCodes.ValidationError,
            placeholders ?? ImmutableDictionary<string, string>.Empty,
            (builder, scenario) => builder.WithTraceIdExtension(scenario).WithRequestIdExtension(scenario));
    }

    public static IAnd<ThenStep> WithValidationProblemDetailsFor(
        this WillFailStep<ThenStep, Scenario> step,
        string propertyKey,
        string errorMessage)
    {
        return step.WithValidationProblemDetailsFor(
            propertyKey,
            errorMessage,
            ServerErrorCodes.ValidationError,
            new Dictionary<string, string>(),
            (builder, scenario) => builder.WithTraceIdExtension(scenario).WithRequestIdExtension(scenario));
    }

    public static IAnd<ThenStep> WithValidationProblemDetailsForTheFirstItem<TCollection>(
        this WillFailStep<ThenStep, Scenario> step,
        Expression<Func<TCollection, object?>> collectionSelector,
        string errorMessage)
    {
        return step.WithValidationProblemDetailsForTheFirstItem(
            collectionSelector,
            errorMessage,
            ServerErrorCodes.ValidationError,
            (builder, scenario) => builder.WithTraceIdExtension(scenario).WithRequestIdExtension(scenario));
    }
}
