using System;
using System.Linq;
using System.Threading;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using FluentAssertions;

namespace ExportZipManager.Api.ComponentTests.Steps.Then.Sqs;

internal class TheEventsProcessingQueueStep : Step<ThenStep, Scenario>
{
    private static readonly TimeSpan ResultHandlingTimeout = TimeSpan.FromSeconds(5);
    private static readonly TimeSpan PollingInterval = TimeSpan.FromMilliseconds(50);

    public IAnd<ThenStep> WillHaveDeletedTheMessage()
    {
        WaitFor(() => Scenario.EventsProcessingSqsTransport.DeleteMessageRequests.Count > 0);

        Scenario.EventsProcessingSqsTransport.DeleteMessageRequests
            .Should()
            .NotBeEmpty();

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveForwardedTheMessageToDeadLetterQueue()
    {
        WaitFor(() => Scenario.EventsProcessingSqsTransport.SendMessageRequests
            .Any(request => request.QueueUrl == EventsProcessingTestConstants.DeadLetterQueueUrl));

        Scenario.EventsProcessingSqsTransport.SendMessageRequests
            .Should()
            .Contain(request => request.QueueUrl == EventsProcessingTestConstants.DeadLetterQueueUrl);

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveForwardedAnyMessageToDeadLetterQueue()
    {
        Scenario.EventsProcessingSqsTransport.SendMessageRequests
            .Where(request => request.QueueUrl == EventsProcessingTestConstants.DeadLetterQueueUrl)
            .Should()
            .BeEmpty();

        return AndStep;
    }

    private static void WaitFor(Func<bool> condition)
    {
        var deadline = DateTime.UtcNow + ResultHandlingTimeout;
        while (!condition() && DateTime.UtcNow < deadline)
        {
            Thread.Sleep(PollingInterval);
        }
    }
}
