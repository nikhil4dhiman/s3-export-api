using System;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Api.ComponentTests.Framework.Constants;
using ExportZipManager.Data.SqsPublisher.Constants;
using ExportZipManager.Domain.Models.Exports;
using FluentAssertions;

namespace ExportZipManager.Api.ComponentTests.Steps.Then.Sqs;

internal class TheAmazonSqsStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHavePublishedEventFor(
        string exportId,
        string partnerId,
        string? sourceName = null,
        SourceType? sourceType = null,
        DateTimeOffset? zipRequestedAt = null)
    {
        var published = Scenario.Mocks.AmazonSqsPublisher.ReceivedEventFor(
            SqsTestConstants.QueueUrl,
            exportId,
            partnerId,
            ExportEventTypes.ExportZipGenerationRequested);

        published.Should().NotBeNull();
        published!.SourceName.Should().Be(sourceName);
        published.SourceType.Should().Be(sourceType);
        published.ZipRequestedAt.Should().Be(zipRequestedAt);

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveAnyPublishedEvent()
    {
        Scenario.Mocks.AmazonSqsPublisher
            .HasReceivedNoEvents()
            .Should()
            .BeTrue();

        return AndStep;
    }
}
