using System;
using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using ExportZipManager.Domain.Models.Exports;
using FluentAssertions;

namespace ExportZipManager.Api.ComponentTests.Steps.Then.DynamoDb;

internal class TheAmazonDynamoDbStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHaveExportRecordWith(string exportId, ExportStatus status)
    {
        Scenario.Mocks.AmazonDynamoDbApiMock
            .HasItemWithExportId(exportId, status.ToString())
            .Should()
            .BeTrue();

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveUpdatedExportWith(string exportId, ExportStatus status, string? fileId = null)
    {
        Scenario.Mocks.AmazonDynamoDbApiMock
            .HasUpdatedExportWith(exportId, status.ToString(), fileId)
            .Should()
            .BeTrue();

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveAnyUpdatedExport()
    {
        Scenario.Mocks.AmazonDynamoDbApiMock
            .HasAnyUpdatedExport()
            .Should()
            .BeFalse();

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveExportStartedAt(DateTimeOffset expectedStartedAt)
    {
        Scenario.Mocks.AmazonDynamoDbApiMock
            .StoredStartedAt
            .Should()
            .Be(expectedStartedAt);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveExportZipRequestedAt(DateTimeOffset expectedZipRequestedAt)
    {
        Scenario.Mocks.AmazonDynamoDbApiMock
            .StoredZipRequestedAt
            .Should()
            .Be(expectedZipRequestedAt);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveExportCompletedAt(DateTimeOffset expectedCompletedAt)
    {
        Scenario.Mocks.AmazonDynamoDbApiMock
            .StoredCompletedAt
            .Should()
            .Be(expectedCompletedAt);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveExportCancelledAt(DateTimeOffset expectedCancelledAt)
    {
        Scenario.Mocks.AmazonDynamoDbApiMock
            .StoredCancelledAt
            .Should()
            .Be(expectedCancelledAt);

        return AndStep;
    }
}
