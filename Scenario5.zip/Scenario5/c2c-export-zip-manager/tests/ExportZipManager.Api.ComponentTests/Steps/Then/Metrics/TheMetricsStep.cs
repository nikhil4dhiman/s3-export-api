using Cove.Platform.Extensions.Testing.BddFramework.Steps;
using ExportZipManager.Api.ComponentTests.Framework;
using FluentAssertions;

namespace ExportZipManager.Api.ComponentTests.Steps.Then.Metrics;

internal class TheMetricsStep : Step<ThenStep, Scenario>
{
    public IAnd<ThenStep> WillHaveObservedExportDuration(string result, double expectedDurationInSeconds)
    {
        Scenario.Mocks.MetricsServiceMock
            .GetExportDurations(result)
            .Should()
            .Equal(expectedDurationInSeconds);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveObservedZipProcessingDuration(string result, double expectedDurationInSeconds)
    {
        Scenario.Mocks.MetricsServiceMock
            .GetZipProcessingDurations(result)
            .Should()
            .Equal(expectedDurationInSeconds);

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveObservedAnyDuration()
    {
        Scenario.Mocks.MetricsServiceMock
            .HasObservedAnyDuration()
            .Should()
            .BeFalse();

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveObservedZipProcessingDuration()
    {
        Scenario.Mocks.MetricsServiceMock
            .HasObservedAnyZipProcessingDuration()
            .Should()
            .BeFalse();

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveIncreasedExportsCompletedCounter(string result)
    {
        Scenario.Mocks.MetricsServiceMock
            .GetExportsCompletedCount(result)
            .Should()
            .Be(1);

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveIncreasedExportsCompletedCounter()
    {
        Scenario.Mocks.MetricsServiceMock
            .HasIncreasedExportsCompletedCounter()
            .Should()
            .BeFalse();

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveIncreasedExportsStartedCounterOnce()
    {
        Scenario.Mocks.MetricsServiceMock
            .ExportsStartedCount
            .Should()
            .Be(1);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveIncreasedZipGenerationEventsPublishedCounterOnce(string result)
    {
        Scenario.Mocks.MetricsServiceMock
            .GetZipGenerationEventsPublishedCount(result)
            .Should()
            .Be(1);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveIncreasedZipGenerationResultEventsProcessedCounterOnce(string result)
    {
        Scenario.Mocks.MetricsServiceMock
            .GetZipGenerationResultEventsProcessedCount(result)
            .Should()
            .Be(1);

        return AndStep;
    }

    public IAnd<ThenStep> WillHaveIncreasedExportsCancelledCounterOnce()
    {
        Scenario.Mocks.MetricsServiceMock
            .ExportsCancelledCount
            .Should()
            .Be(1);

        return AndStep;
    }

    public IAnd<ThenStep> WillNotHaveIncreasedExportsCancelledCounter()
    {
        Scenario.Mocks.MetricsServiceMock
            .ExportsCancelledCount
            .Should()
            .Be(0);

        return AndStep;
    }
}
