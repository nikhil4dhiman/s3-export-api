using System.Collections.Generic;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class CompleteMultipartFileRequestBuilder
    : BuilderBase<CompleteMultipartFileRequestBuilder, CompleteMultipartFileRequest>
{
    public CompleteMultipartFileRequestBuilder WithRandomValues()
    {
        return WithAutoProperties()
            .WithParts(
            [
                new CompleteMultipartFileRequestPartBuilder()
                    .WithRandomValues()
                    .WithPartNumber(1)
                    .Build(),
                new CompleteMultipartFileRequestPartBuilder()
                    .WithRandomValues()
                    .WithPartNumber(2)
                    .Build()
            ]);
    }

    public CompleteMultipartFileRequestBuilder WithFileName(string? fileName)
    {
        return With(x => x.FileName, fileName);
    }

    public CompleteMultipartFileRequestBuilder WithUploadId(string? uploadId)
    {
        return With(x => x.UploadId, uploadId);
    }

    public CompleteMultipartFileRequestBuilder WithParts(IReadOnlyCollection<CompleteMultipartFileRequestPart>? parts)
    {
        return With(x => x.Parts, parts);
    }
}
