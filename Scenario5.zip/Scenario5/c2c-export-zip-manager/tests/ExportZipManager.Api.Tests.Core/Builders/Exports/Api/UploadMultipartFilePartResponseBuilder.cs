using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class UploadMultipartFilePartResponseBuilder
    : BuilderBase<UploadMultipartFilePartResponseBuilder, UploadMultipartFilePartResponse>
{
    public UploadMultipartFilePartResponseBuilder WithETag(string eTag)
    {
        return With(x => x.ETag, eTag);
    }
}
