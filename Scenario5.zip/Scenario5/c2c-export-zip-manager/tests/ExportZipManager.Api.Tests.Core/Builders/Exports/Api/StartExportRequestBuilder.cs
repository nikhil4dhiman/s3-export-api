using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class StartExportRequestBuilder : BuilderBase<StartExportRequestBuilder, StartExportRequest>
{
    public StartExportRequestBuilder WithRandomValues()
    {
        return WithAutoProperties();
    }

    public StartExportRequestBuilder WithBackupId(string? backupId)
    {
        return With(x => x.BackupId, backupId);
    }

    public StartExportRequestBuilder WithSessionId(string? sessionId)
    {
        return With(x => x.SessionId, sessionId);
    }

    public StartExportRequestBuilder WithRunId(string? runId)
    {
        return With(x => x.RunId, runId);
    }

    public StartExportRequestBuilder WithSourceId(string? sourceId)
    {
        return With(x => x.SourceId, sourceId);
    }
}
