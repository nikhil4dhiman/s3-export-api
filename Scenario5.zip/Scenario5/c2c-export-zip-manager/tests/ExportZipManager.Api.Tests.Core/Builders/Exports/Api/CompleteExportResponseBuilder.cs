using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class CompleteExportResponseBuilder : BuilderBase<CompleteExportResponseBuilder, CompleteExportResponse>
{
    public CompleteExportResponseBuilder WithExportId(string exportId)
    {
        return With(x => x.ExportId, exportId);
    }
}
