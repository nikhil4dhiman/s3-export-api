using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class UploadFilePartRequestQueryBuilder
    : BuilderBase<UploadFilePartRequestQueryBuilder, UploadMultipartFilePartRequestQuery>
{
    public UploadFilePartRequestQueryBuilder WithRandomValues()
    {
        return WithAutoProperties();
    }

    public UploadFilePartRequestQueryBuilder WithFileName(string? fileName)
    {
        return With(x => x.FileName, fileName);
    }

    public UploadFilePartRequestQueryBuilder WithUploadId(string? uploadId)
    {
        return With(x => x.UploadId, uploadId);
    }

    public UploadFilePartRequestQueryBuilder WithPartNumber(int? partNumber)
    {
        return With(x => x.PartNumber, partNumber);
    }
}
