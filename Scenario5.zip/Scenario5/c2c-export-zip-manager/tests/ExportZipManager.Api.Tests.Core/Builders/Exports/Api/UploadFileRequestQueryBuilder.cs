using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class UploadFileRequestQueryBuilder
    : BuilderBase<UploadFileRequestQueryBuilder, UploadFileRequestQuery>
{
    public UploadFileRequestQueryBuilder WithRandomValues()
    {
        return WithAutoProperties();
    }

    public UploadFileRequestQueryBuilder WithFileName(string? fileName)
    {
        return With(x => x.FileName, fileName);
    }
}
