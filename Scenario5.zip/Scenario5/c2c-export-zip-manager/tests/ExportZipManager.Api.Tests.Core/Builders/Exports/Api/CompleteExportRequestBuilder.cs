using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class CompleteExportRequestBuilder : BuilderBase<CompleteExportRequestBuilder, CompleteExportRequest>
{
    public CompleteExportRequestBuilder WithRandomValues()
    {
        return With(x => x.SourceName, Generate.RandomString())
            .With(x => x.SourceType, Generate.RandomEnumValue<SourceType>());
    }

    public CompleteExportRequestBuilder WithSourceName(string? sourceName)
    {
        return With(x => x.SourceName, sourceName);
    }

    public CompleteExportRequestBuilder WithSourceType(SourceType? sourceType)
    {
        return With(x => x.SourceType, sourceType);
    }
}
