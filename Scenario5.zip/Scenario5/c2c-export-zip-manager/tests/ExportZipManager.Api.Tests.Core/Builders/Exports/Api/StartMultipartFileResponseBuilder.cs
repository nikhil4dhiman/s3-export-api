using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class StartMultipartFileResponseBuilder
    : BuilderBase<StartMultipartFileResponseBuilder, StartMultipartFileResponse>
{
    public StartMultipartFileResponseBuilder WithUploadId(string uploadId)
    {
        return With(x => x.UploadId, uploadId);
    }
}
