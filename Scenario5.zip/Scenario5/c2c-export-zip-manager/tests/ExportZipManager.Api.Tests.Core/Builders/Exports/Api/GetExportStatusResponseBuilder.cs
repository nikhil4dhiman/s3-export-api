using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class GetExportStatusResponseBuilder : BuilderBase<GetExportStatusResponseBuilder, GetExportStatusResponse>
{
    public GetExportStatusResponseBuilder WithStatus(string status)
    {
        return With(x => x.Status, status);
    }

    public GetExportStatusResponseBuilder WithFileId(string? fileId)
    {
        return With(x => x.FileId, fileId);
    }
}
