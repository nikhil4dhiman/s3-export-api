using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class CompleteMultipartFileRequestPartBuilder
    : BuilderBase<CompleteMultipartFileRequestPartBuilder, CompleteMultipartFileRequestPart>
{
    public CompleteMultipartFileRequestPartBuilder WithRandomValues()
    {
        return WithAutoProperties();
    }

    public CompleteMultipartFileRequestPartBuilder WithPartNumber(int? partNumber)
    {
        return With(x => x.PartNumber, partNumber);
    }

    public CompleteMultipartFileRequestPartBuilder WithETag(string? eTag)
    {
        return With(x => x.ETag, eTag);
    }
}
