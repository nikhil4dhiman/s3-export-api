using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class StartExportResponseBuilder : BuilderBase<StartExportResponseBuilder, StartExportResponse>
{
    public StartExportResponseBuilder FromRequest(StartExportRequest request)
    {
        var exportId = string.Concat(
            request.SourceId, "-",
            request.BackupId, "-",
            request.SessionId, "-",
            request.RunId);

        return With(x => x.ExportId, exportId);
    }
}
