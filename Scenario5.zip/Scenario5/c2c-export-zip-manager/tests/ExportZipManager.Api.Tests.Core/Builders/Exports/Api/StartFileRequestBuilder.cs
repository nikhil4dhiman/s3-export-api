using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Endpoints.Exports.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Exports.Api;

internal class StartFileRequestBuilder : BuilderBase<StartFileRequestBuilder, StartMultipartFileRequest>
{
    public StartFileRequestBuilder WithRandomValues()
    {
        return WithAutoProperties();
    }

    public StartFileRequestBuilder WithFileName(string? fileName)
    {
        return With(x => x.FileName, fileName);
    }
}
