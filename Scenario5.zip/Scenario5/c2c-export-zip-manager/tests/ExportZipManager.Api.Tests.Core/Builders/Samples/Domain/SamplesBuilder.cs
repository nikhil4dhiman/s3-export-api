using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Domain.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Samples.Domain;

internal class SamplesBuilder : CollectionBuilderBase<SamplesBuilder, SampleBuilder, Sample>;
