using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Models.Samples.Requests;
using ExportZipManager.Domain.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Samples.Domain;

internal class SampleBuilder : BuilderBase<SampleBuilder, Sample>, IBuildModelWithRandomValues<SampleBuilder>
{
    public SampleBuilder FromRequest(CreateSampleRequest request)
    {
        return WithName(request.Name!);
    }

    public SampleBuilder WithRandomValues()
    {
        return WithAutoProperties();
    }

    public SampleBuilder WithId(string id)
    {
        return With(x => x.Id, id);
    }

    public SampleBuilder WithName(string name)
    {
        return With(x => x.Name, name);
    }

    public SampleBuilder WithDetails(SampleDetails? details)
    {
        return With(x => x.Details, details);
    }
}
