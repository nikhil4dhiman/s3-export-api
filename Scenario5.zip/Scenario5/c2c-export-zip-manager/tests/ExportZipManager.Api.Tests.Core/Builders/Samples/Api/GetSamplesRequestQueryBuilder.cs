using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Models.Samples.Requests;

namespace ExportZipManager.Api.Tests.Core.Builders.Samples.Api;

internal class GetSamplesRequestQueryBuilder : BuilderBase<GetSamplesRequestQueryBuilder, GetSamplesRequestQuery>
{
    public GetSamplesRequestQueryBuilder WithTake(int? take)
    {
        return With(x => x.Take, take);
    }

    public GetSamplesRequestQueryBuilder WithSkip(int? skip)
    {
        return With(x => x.Skip, skip);
    }
}
