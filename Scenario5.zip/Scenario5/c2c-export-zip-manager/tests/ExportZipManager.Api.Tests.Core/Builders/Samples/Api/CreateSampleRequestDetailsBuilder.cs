using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Models.Samples.Requests;

namespace ExportZipManager.Api.Tests.Core.Builders.Samples.Api;

internal class CreateSampleRequestDetailsBuilder
    : BuilderBase<CreateSampleRequestDetailsBuilder, CreateSampleRequestDetails>
{
    public CreateSampleRequestDetailsBuilder WithRandomValues()
    {
        return WithAutoProperties();
    }

    public CreateSampleRequestDetailsBuilder WithAdditionalDetails(string? additionalDetails)
    {
        return With(x => x.AdditionalDetails, additionalDetails);
    }
}
