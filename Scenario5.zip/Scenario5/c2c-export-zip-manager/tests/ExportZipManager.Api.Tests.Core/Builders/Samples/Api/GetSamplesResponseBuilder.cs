using System.Collections.Generic;
using System.Linq;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Models.Samples.Responses;
using ExportZipManager.Domain.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Samples.Api;

internal class GetSamplesResponseBuilder : BuilderBase<GetSamplesResponseBuilder, GetSamplesResponse>
{
    public GetSamplesResponseBuilder WithItems(IEnumerable<Sample> domainItems)
    {
        var items = domainItems.Select(item => new GetSampleResponseBuilder().FromDomainModel(item).Build());

        return With(x => x.Items, [.. items]);
    }

    public GetSamplesResponseBuilder WithTotalCount(int totalCount)
    {
        return With(x => x.TotalCount, totalCount);
    }
}
