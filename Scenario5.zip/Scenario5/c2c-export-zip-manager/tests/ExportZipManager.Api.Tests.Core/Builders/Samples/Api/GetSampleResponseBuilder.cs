using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.Api.Models.Samples.Responses;
using ExportZipManager.Domain.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.Samples.Api;

internal class GetSampleResponseBuilder : BuilderBase<GetSampleResponseBuilder, GetSampleResponse>
{
    public GetSampleResponseBuilder FromDomainModel(Sample sample)
    {
        return With(x => x.Id, sample.Id)
            .With(x => x.Name, sample.Name);
    }
}
