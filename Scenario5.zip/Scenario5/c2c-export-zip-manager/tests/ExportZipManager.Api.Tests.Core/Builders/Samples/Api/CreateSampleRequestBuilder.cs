using System;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using Cove.Platform.Extensions.Testing.SharedHelpers.DataGeneration;
using ExportZipManager.Api.Models.Samples.Requests;

namespace ExportZipManager.Api.Tests.Core.Builders.Samples.Api;

internal class CreateSampleRequestBuilder : BuilderBase<CreateSampleRequestBuilder, CreateSampleRequest>
{
    public CreateSampleRequestBuilder WithRandomValues()
    {
        WithAutoProperties();

        if (Generate.RandomBool())
        {
            WithSomeFlagFieldThatWillRequireDetails(true)
                .WithDetails(x => x.WithRandomValues());
        }
        else
        {
            WithSomeFlagFieldThatWillRequireDetails(false)
                .WithoutDetails();
        }

        return this;
    }

    public CreateSampleRequestBuilder WithName(string? name)
    {
        return With(x => x.Name, name);
    }

    public CreateSampleRequestBuilder WithSomeFlagFieldThatWillRequireDetails(bool someFlagFieldThatWillRequireDetails)
    {
        return With(x => x.SomeFlagFieldThatWillRequireDetails, someFlagFieldThatWillRequireDetails);
    }

    public CreateSampleRequestBuilder WithoutDetails()
    {
        return With(x => x.Details, (CreateSampleRequestDetails?)null);
    }

    public CreateSampleRequestBuilder WithDetails(Action<CreateSampleRequestDetailsBuilder> configureBuilder)
    {
        var builder = new CreateSampleRequestDetailsBuilder();

        configureBuilder(builder);

        return With(x => x.Details, builder.Build());
    }
}
