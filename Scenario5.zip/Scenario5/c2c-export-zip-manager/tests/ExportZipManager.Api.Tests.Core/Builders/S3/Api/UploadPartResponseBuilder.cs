using Amazon.S3.Model;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;

namespace ExportZipManager.Api.Tests.Core.Builders.S3.Api;

internal class UploadPartResponseBuilder : BuilderBase<UploadPartResponseBuilder, UploadPartResponse>
{
    public UploadPartResponseBuilder WithRandomValues()
    {
        return WithAutoProperties()
            .Without(x => x.RequestCharged);
    }

    public UploadPartResponseBuilder WithETag(string eTag)
    {
        return With(x => x.ETag, eTag);
    }
}
