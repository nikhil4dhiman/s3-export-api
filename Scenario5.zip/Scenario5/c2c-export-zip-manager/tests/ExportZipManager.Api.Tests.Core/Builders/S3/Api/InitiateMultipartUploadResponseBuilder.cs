using Amazon.S3.Model;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;

namespace ExportZipManager.Api.Tests.Core.Builders.S3.Api;

internal class InitiateMultipartUploadResponseBuilder
    : BuilderBase<InitiateMultipartUploadResponseBuilder, InitiateMultipartUploadResponse>
{
    public InitiateMultipartUploadResponseBuilder WithRandomValues()
    {
        return WithAutoProperties()
            .Without(x => x.RequestCharged);
    }

    public InitiateMultipartUploadResponseBuilder WithUploadId(string uploadId)
    {
        return With(x => x.UploadId, uploadId);
    }
}
