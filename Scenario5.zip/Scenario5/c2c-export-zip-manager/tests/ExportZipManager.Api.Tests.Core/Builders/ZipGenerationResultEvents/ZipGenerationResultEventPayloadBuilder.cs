using System.Text.Json.Nodes;
using Cove.Platform.Extensions.Testing.SharedHelpers.Builders;
using ExportZipManager.BackgroundServices.AwsSqs.Models;

namespace ExportZipManager.Api.Tests.Core.Builders.ZipGenerationResultEvents;

internal class ZipGenerationResultEventPayloadBuilder
    : BuilderBase<ZipGenerationResultEventPayloadBuilder, ZipGenerationResultEventPayload>,
        IBuildModelWithRandomValues<ZipGenerationResultEventPayloadBuilder>
{
    public ZipGenerationResultEventPayloadBuilder WithRandomValues()
    {
        return WithAutoProperties()
            .WithState(ExportResultState.Completed)
            .WithResultDetails(null);
    }

    public ZipGenerationResultEventPayloadBuilder WithId(string id)
    {
        return With(x => x.Id, id);
    }

    public ZipGenerationResultEventPayloadBuilder WithState(ExportResultState state)
    {
        return With(x => x.State, state);
    }

    public ZipGenerationResultEventPayloadBuilder WithResultDetails(JsonNode? resultDetails)
    {
        return With(x => x.ResultDetails, resultDetails);
    }

    public ZipGenerationResultEventPayloadBuilder WithFileId(string fileId)
    {
        return WithResultDetails(new JsonObject { ["fileId"] = fileId });
    }
}
