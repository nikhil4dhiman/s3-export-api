using System;
using System.Linq;
using NUnit.Framework;

namespace ExportZipManager.Api.Tests.Core.TestCases;

[AttributeUsage(AttributeTargets.Method)]
public sealed class PathTraversalFileNameTestCasesAttribute : TestCaseSourceAttribute
{
    private static readonly string[] PathTraversalFileNames =
    [
        "../secret.txt",
        "folder/../../secret.txt",
        "/absolute/path.txt",
        "folder\\file.txt"
    ];

    private static readonly TestCaseData[] PathTraversalFileNameTestCases = [.. PathTraversalFileNames.Select(value => new TestCaseData(value).SetArgDisplayNames(value))];

    public PathTraversalFileNameTestCasesAttribute()
        : base(typeof(PathTraversalFileNameTestCasesAttribute), nameof(PathTraversalFileNameTestCases))
    {
    }
}
