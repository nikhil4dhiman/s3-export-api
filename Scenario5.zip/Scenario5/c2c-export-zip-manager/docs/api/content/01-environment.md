# Environment variables

| Name                                          | Description                                                                                                                              |
| --------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------- |
| ASPNETCORE_URLS                               | Indicates the IP addresses or host addresses with ports and protocols that the server should listen on for requests.                     |
| ASPNETCORE_ENVIRONMENT                        | Defines current runtime environment.                                                                                                     |
| ManagementPort                                | A port on which health checks and metrics endpoints are exposed.                                                                         |
| Database__Host                                | A database host.                                                                                                                         |
| Database__Port                                | A database port.                                                                                                                         |
| Database__UserName                            | A database user.                                                                                                                         |
| Database__Password                            | A database password.                                                                                                                     |
| Database__DatabaseName                        | A database name.                                                                                                                         |
| Database__CommandTimeoutInSeconds             | A database command timeout in seconds.                                                                                                   |
| Paging__DefaultPageSize                       | A default pagination page size.                                                                                                          |
| Paging__MaxPageSize                           | A maximum allowed page size.                                                                                                             |
| Tracing__ExporterEndpoint                     | An endpoint URL to the OpenTelemetry collector                                                                                           |
| Tracing__EnvironmentName                      | An environment name that is added to the OpenTelemetry tracing                                                                           |
| BasicAuthentication__UserName                 | C2C Export ZIP Manager API's basic auth username.                                                                                        |
| BasicAuthentication__Password                 | C2C Export ZIP Manager API's basic auth password.                                                                                        |
