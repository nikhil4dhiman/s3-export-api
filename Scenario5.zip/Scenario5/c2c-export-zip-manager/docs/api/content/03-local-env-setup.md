# Local environment setup

Prerequisites:

1. IDE is installed - Rider or Visual Studio.
2. .NET 10 SDK is installed.
3. Run or Debug an application using a standard mechanism provided by IDE. If all parameters are configured correctly, the application should start working.
