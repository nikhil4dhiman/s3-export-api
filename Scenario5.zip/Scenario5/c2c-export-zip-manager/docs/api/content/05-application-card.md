# Application card for the Export Zip Manager

### Urls

Export Zip Manager is not publicly accessible. The only way to access Export Zip Manager is via [apigatewayrouter](https://github.com/nable-backup/apigatewayrouter).
See [router configuration](https://github.com/nable-backup/backup-manager/blob/develop/Integration/IaC/router/containers/nginx/nginx.conf.tpl#c2c-export-zip-manager) for more details.

* Dev - http://router-service.dev-router-ENV.svc.cluster.local/c2c-export-zip-manager
* Coll - http://router-service.coll-router.svc.cluster.local/c2c-export-zip-manager
* Stg - http://router-service.stg-router.svc.cluster.local/c2c-export-zip-manager
* Prd - http://router-service.prd-router.svc.cluster.local/c2c-export-zip-manager

See [Notes](#notes) to check supported `ENV` values.

### Logging

Url: https://n-able.splunkcloud.com/en-US/app/search/search

|       | Dev                                                                                                                                                                                                                                                                                                | Coll                                                                                                                                                                                                                                                                                             | Stg                                                                                                                                                                                                                                                                                            | Prd                                                                                                                                                                                                                                                                                            |
|-------|----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Index | p-backup-dev (default in Splunk)                                                                                                                                                                                                                                                                   | p-backup-stg                                                                                                                                                                                                                                                                                     | p-backup-stg                                                                                                                                                                                                                                                                                   | p-backup-prd                                                                                                                                                                                                                                                                                   |
| Query | `index="p-backup-dev" container_name="export-zip-manager" namespace="dev-export-zip-ENV"`                                                                                                                                                                                                          | `index="p-backup-stg" container_name="export-zip-manager" namespace="coll-export-zip"`                                                                                                                                                                                                           | `index="p-backup-stg" container_name="export-zip-manager" namespace="stg-export-zip"`                                                                                                                                                                                                          | `index="p-backup-prd" container_name="export-zip-manager" namespace="prd-export-zip"`                                                                                                                                                                                                          |
| Link  | [Dev](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-dev%22%20container_name%3D%22export-zip-manager%22%20namespace%3D%22dev-export-zip-ENV%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823898.1831930)  | [Coll](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-stg%22%20container_name%3D%22export-zip-manager%22%20namespace%3D%22coll-export-zip%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823974.1832233)  | [Stg](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-stg%22%20container_name%3D%22export-zip-manager%22%20namespace%3D%22stg-export-zip%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823947.1832094)  | [Prd](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-prd%22%20container_name%3D%22export-zip-manager%22%20namespace%3D%22prd-export-zip%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823993.1832296)  |

See [Notes](#notes) to check supported `ENV` values.

### Grafana

#### EKS Dashboard

* [Dev](https://grafana.cloudbackup.management/d/IAnyvYlWz/eks?orgId=1&var-environment=VictoriaMetrics01.dev&var-service=dev-export-zip-c2c-mc)
* [Coll](https://grafana.cloudbackup.management/d/IAnyvYlWz/eks?orgId=1&var-environment=VictoriaMetrics01.stg&var-service=coll-export-zip)
* [Stg](https://grafana.cloudbackup.management/d/IAnyvYlWz/eks?orgId=1&var-environment=VictoriaMetrics01.stg&var-service=stg-export-zip)
* [Prd](https://grafana.cloudbackup.management/d/IAnyvYlWz/eks?orgId=1&var-environment=VictoriaMetrics01.prd&var-service=prd-export-zip)

#### Export Zip Manager dashboard

* [Dev](https://grafana.cloudbackup.management/d/c2c-export-zip-manager?orgId=1&var-env=dev&var-namespace=dev-export-zip-c2c-mc&var-pod=All)
* [Coll](https://grafana.cloudbackup.management/d/c2c-export-zip-manager?orgId=1&var-env=stg&var-namespace=coll-export-zip&var-pod=All)
* [Stg](https://grafana.cloudbackup.management/d/c2c-export-zip-manager?orgId=1&var-env=stg&var-namespace=stg-export-zip&var-pod=All)
* [Prd](https://grafana.cloudbackup.management/d/c2c-export-zip-manager?orgId=1&var-env=prd&var-namespace=prd-export-zip&var-pod=All)

### CI/CD Server

[NextStage](https://backup.build.n-able.dev/job/BACKUP/job/cove/job/c2c-export-zip)

### Repository

Url: https://github.com/nable-backup/c2c-export-zip-manager

### Secrets server

HashiCorp Vault.

* [Dev UI](https://vault.dev.bckp.io/ui/vault/secrets/c2c/kv/list/export-zip/manager/)
* [Coll and Stg UI](https://vault.stg.bckp.io/ui/vault/secrets/c2c/kv/list/export-zip/manager/)
* [Prd UI](https://vault.prd.bckp.io/ui/vault/secrets/c2c/kv/list/export-zip/manager/)

### Container images storage

[Amazon ECR Index](https://ecrindex.n-able.dev/#cove-c2c-prd-c2c-export-zip-manager)

### Notes

Supported dev environments are listed [here](https://github.com/nable-backup/c2c-export-zip-manager/tree/develop/deployment/environments).
