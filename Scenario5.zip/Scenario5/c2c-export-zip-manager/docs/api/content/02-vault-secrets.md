# Vault secrets

## Location
vault:c2c/data/export-zip/manager/<env_name>, where <env_name> is one of the following values: dev, coll, stg, prd

## Values

| Key Name                         | Description                                                                              | Environment variable name                     |
|----------------------------------|------------------------------------------------------------------------------------------|-----------------------------------------------|
| db-connection-string             | A read-only connection string to the new MySQL database.                                 | Database__ConnectionString                    |
| basic-auth-password              | The plaintext value should match the one that is stored in the vault for Auth Gateway.   | BasicAuthentication__Password                 |
