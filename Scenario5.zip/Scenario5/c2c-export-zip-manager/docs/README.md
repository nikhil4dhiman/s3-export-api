# Export Zip Manager

The service documentation can be found on BackStage.

## System
https://portal.n-able.dev/catalog/cove/system/placeholder-system-name

## Component
https://portal.n-able.dev/catalog/cove/component/export-zip-manager-api
