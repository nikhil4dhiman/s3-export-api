using System;
using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS;
using Amazon.SQS.Model;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace ExportZipManager.Core.Api.HealthChecks;

#pragma warning disable CA1031 // catching and wrapping an exception to result type for easier handling

internal sealed class AmazonSqsHealthCheck : IHealthCheck
{
    private readonly IAmazonSQS _amazonSqs;
    private readonly string _queueUrl;
    private readonly string _queueName;

    public AmazonSqsHealthCheck(IAmazonSQS amazonSqs, string queueUrl)
    {
        _amazonSqs = amazonSqs;
        _queueUrl = queueUrl;
        _queueName = GetQueueName(queueUrl);
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        try
        {
            await _amazonSqs.GetQueueAttributesAsync(
                new GetQueueAttributesRequest
                {
                    QueueUrl = _queueUrl,
                    AttributeNames = ["QueueArn"]
                },
                cancellationToken);

            return HealthCheckResult.Healthy($"SQS queue '{_queueName}' is available");
        }
        catch (Exception exception)
        {
            return new HealthCheckResult(
                context.Registration.FailureStatus,
                description: $"SQS queue '{_queueName}' is unavailable",
                exception: exception);
        }
    }

    private static string GetQueueName(string queueUrl)
    {
        var queueNameStartIndex = queueUrl.LastIndexOf('/') + 1;

        return queueUrl[queueNameStartIndex..];
    }
}
