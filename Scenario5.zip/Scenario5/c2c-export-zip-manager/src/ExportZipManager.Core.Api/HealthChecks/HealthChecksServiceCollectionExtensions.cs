using System;
using Amazon.SQS;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace ExportZipManager.Core.Api.HealthChecks;

public static class HealthChecksServiceCollectionExtensions
{
    extension(IHealthChecksBuilder healthChecksBuilder)
    {
        public IHealthChecksBuilder AddAmazonSqsHealthCheck(
            string name,
            Func<IServiceProvider, string> queueUrlProvider,
            params string[] tags)
        {
            return healthChecksBuilder.Add(new HealthCheckRegistration(
                name,
                sp => new AmazonSqsHealthCheck(
                    sp.GetRequiredService<IAmazonSQS>(),
                    queueUrlProvider(sp)),
                failureStatus: HealthStatus.Unhealthy,
                tags: tags));
        }
    }
}
