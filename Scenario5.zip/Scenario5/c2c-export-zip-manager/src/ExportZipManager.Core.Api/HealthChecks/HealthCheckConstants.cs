namespace ExportZipManager.Core.Api.HealthChecks;

public static class HealthCheckConstants
{
    public const string LivenessTag = "liveness";
    public const string HealthRoute = "/health";
    public const string ReadinessRoute = HealthRoute + "/ready";
    public const string ReadinessTag = "readiness";
    public const string LivenessRoute = HealthRoute + "/live";
}
