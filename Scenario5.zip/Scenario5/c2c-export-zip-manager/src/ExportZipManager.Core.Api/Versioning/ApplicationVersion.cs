using System.Reflection;

namespace ExportZipManager.Core.Api.Versioning;

public static class ApplicationVersion
{
    public static readonly string InformationalVersion =
        Assembly.GetEntryAssembly()!
            .GetCustomAttribute<AssemblyInformationalVersionAttribute>()!
            .InformationalVersion;
}
