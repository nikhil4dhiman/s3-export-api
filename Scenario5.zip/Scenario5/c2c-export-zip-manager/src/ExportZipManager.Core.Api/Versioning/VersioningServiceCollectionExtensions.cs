using Asp.Versioning;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Core.Api.Versioning;

public static class VersioningServiceCollectionExtensions
{
    private const string ApiVersionHeaderName = "api-version";

    extension(IServiceCollection services)
    {
        public IServiceCollection AddVersioningServices()
        {
            services
                .AddApiVersioning(options =>
                {
                    var apiShortVersion = string.IsNullOrWhiteSpace(ApplicationVersion.InformationalVersion)
                        ? ApiVersion.Default.ToString()
                        : ApplicationVersion.InformationalVersion[..3];

                    options.DefaultApiVersion = ApiVersionParser.Default.TryParse(apiShortVersion, out var version)
                        ? version
                        : ApiVersion.Default;

                    options.AssumeDefaultVersionWhenUnspecified = true;
                    options.ReportApiVersions = true;
                    options.ApiVersionReader = new HeaderApiVersionReader(ApiVersionHeaderName);
                });

            return services;
        }
    }
}
