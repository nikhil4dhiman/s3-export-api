using System;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;

namespace ExportZipManager.Core.Api.Serialization;

public class StringToJsonNodeConverter : JsonConverter<JsonNode?>
{
    public override JsonNode? Read(ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
    {
        if (reader.TokenType == JsonTokenType.Null)
        {
            return null;
        }

        if (reader.TokenType == JsonTokenType.String)
        {
            var jsonString = reader.GetString();

            return string.IsNullOrEmpty(jsonString)
                ? null
                : JsonNode.Parse(jsonString);
        }

        using var document = JsonDocument.ParseValue(ref reader);

        return JsonNode.Parse(document.RootElement.GetRawText());
    }

    public override void Write(Utf8JsonWriter writer, JsonNode? value, JsonSerializerOptions options)
    {
        if (value == null)
        {
            writer.WriteNullValue();
        }
        else
        {
            value.WriteTo(writer, options);
        }
    }
}
