using System;
using System.Collections.Generic;
using System.Text;

namespace ExportZipManager.Core.Api.Validation;

public class RequestValidationException : Exception
{
    public RequestValidationException(IDictionary<string, string[]> validationErrors)
        : base(FormatExceptionMessage(validationErrors))
    {
        ValidationErrors = validationErrors;
    }

    public IDictionary<string, string[]> ValidationErrors { get; }

    private static string FormatExceptionMessage(IDictionary<string, string[]> validationErrors)
    {
        var builder = new StringBuilder("Request validation failed. See validation errors below: ")
            .AppendLine();

        foreach (var error in validationErrors)
        {
            builder
                .AppendFormat("Property: {0}, Errors: ", error.Key)
                .AppendJoin("; ", error.Value)
                .AppendLine();
        }

        return builder.ToString();
    }
}
