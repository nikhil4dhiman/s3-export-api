using Microsoft.Extensions.Logging;

namespace ExportZipManager.Data.SqsPublisher.Logging;

internal static partial class LoggerExtensions
{
    [LoggerMessage(
        Level = LogLevel.Error,
        Message = "Publishing to Amazon SQS failed. Export ID: {ExportId}, Partner ID: {PartnerId}, Error: {ErrorMessage}")]
    public static partial void LogSqsPublishingFailure(
        this ILogger<ExportZipEventsSqsPublisher> logger,
        string exportId,
        string partnerId,
        string errorMessage);
}
