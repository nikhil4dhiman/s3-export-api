using System;
using System.Net.Mime;
using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS.Model;
using CloudNative.CloudEvents;
using Cove.Platform.Extensions.Identifiers.DataGeneration;
using ExportZipManager.Data.SqsPublisher.Adapters;
using ExportZipManager.Data.SqsPublisher.Configuration;
using ExportZipManager.Data.SqsPublisher.Constants;
using ExportZipManager.Data.SqsPublisher.Extensions;
using ExportZipManager.Data.SqsPublisher.Logging;
using ExportZipManager.Data.SqsPublisher.Models;
using ExportZipManager.Domain.EventsPublishing;
using ExportZipManager.Domain.Metrics;
using ExportZipManager.Domain.Models.Exports;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.Data.SqsPublisher;

internal class ExportZipEventsSqsPublisher : IExportZipEventsSqsPublisher
{
    private readonly IAmazonSqsPublishingAdapter _amazonSqsPublishing;
    private readonly IIdGenerator _idGenerator;
    private readonly IMetricsService _metricsService;
    private readonly SqsOptions _sqsOptions;
    private readonly ILogger<ExportZipEventsSqsPublisher> _logger;

    public ExportZipEventsSqsPublisher(
        IAmazonSqsPublishingAdapter amazonSqsPublishing,
        IIdGenerator idGenerator,
        IMetricsService metricsService,
        SqsOptions sqsOptions,
        ILogger<ExportZipEventsSqsPublisher> logger)
    {
        _amazonSqsPublishing = amazonSqsPublishing;
        _idGenerator = idGenerator;
        _metricsService = metricsService;
        _sqsOptions = sqsOptions;
        _logger = logger;
    }

    public async Task PublishAsync(
        ExportCompletionDetails completionDetails,
        CancellationToken cancellationToken)
    {
        var payload = completionDetails.ToEventPayload();

        var publishRequest = CreateRequest(payload);

        try
        {
            await _amazonSqsPublishing.SendMessageAsync(publishRequest, cancellationToken);

            _metricsService.IncreaseNumberOfZipGenerationEventsPublished(MetricLabelValues.Result.Published);
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogSqsPublishingFailure(payload.ExportId, payload.PartnerId, e.Message);

            _metricsService.IncreaseNumberOfZipGenerationEventsPublished(MetricLabelValues.Result.Failed);

            throw;
        }
    }

    private SendMessageRequest CreateRequest(ExportZipProcessorEventPayload payload)
    {
        var cloudEvent = new CloudEvent(CloudEventsSpecVersion.V1_0)
        {
            Id = _idGenerator.GenerateId(),
            Type = ExportEventTypes.ExportZipGenerationRequested,
            Time = DateTimeOffset.UtcNow,
            Source = EventSources.ExportZipManager,
            DataContentType = MediaTypeNames.Application.Json,
            Data = payload
        };

        return new SendMessageRequest
        {
            QueueUrl = _sqsOptions.QueueUrl,
            MessageBody = cloudEvent.EncodeToJsonString(),
            MessageGroupId = payload.ExportId,
            MessageDeduplicationId = $"{payload.ExportId}-{ExportEventTypes.ExportZipGenerationRequested}"
        };
    }
}
