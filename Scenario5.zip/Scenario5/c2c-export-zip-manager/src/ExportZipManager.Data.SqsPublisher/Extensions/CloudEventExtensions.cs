using System.Text;
using CloudNative.CloudEvents;
using CloudNative.CloudEvents.SystemTextJson;

namespace ExportZipManager.Data.SqsPublisher.Extensions;

internal static class CloudEventExtensions
{
    private static readonly JsonEventFormatter EventFormatter = new();

    public static string EncodeToJsonString(this CloudEvent cloudEvent)
    {
        var messageBytes = EventFormatter.EncodeStructuredModeMessage(cloudEvent, out _);
        return Encoding.UTF8.GetString(messageBytes.Span);
    }
}
