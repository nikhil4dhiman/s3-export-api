using ExportZipManager.Data.SqsPublisher.Models;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Data.SqsPublisher.Extensions;

internal static class MappingExtensions
{
    public static ExportZipProcessorEventPayload ToEventPayload(this ExportCompletionDetails completionDetails)
    {
        return new ExportZipProcessorEventPayload
        {
            ExportId = completionDetails.ExportId,
            PartnerId = completionDetails.PartnerId,
            SourceName = completionDetails.SourceName,
            SourceType = completionDetails.SourceType,
            ZipRequestedAt = completionDetails.ZipRequestedAt
        };
    }
}
