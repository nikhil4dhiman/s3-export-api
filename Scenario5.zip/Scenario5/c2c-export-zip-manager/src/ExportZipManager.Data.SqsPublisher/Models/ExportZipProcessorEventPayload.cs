using System;
using System.Text.Json.Serialization;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Data.SqsPublisher.Models;

internal class ExportZipProcessorEventPayload
{
    [JsonPropertyName("exportId")]
    public required string ExportId { get; init; }

    [JsonPropertyName("partnerId")]
    public required string PartnerId { get; init; }

    [JsonPropertyName("sourceName")]
    public required string SourceName { get; init; }

    [JsonPropertyName("sourceType")]
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public required SourceType SourceType { get; init; }

    [JsonPropertyName("zipRequestedAt")]
    public required DateTimeOffset ZipRequestedAt { get; init; }
}
