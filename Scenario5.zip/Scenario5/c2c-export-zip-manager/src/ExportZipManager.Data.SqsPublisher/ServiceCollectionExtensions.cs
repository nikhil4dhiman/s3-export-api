using Amazon.SQS;
using Cove.Platform.Extensions.Configuration;
using ExportZipManager.Data.SqsPublisher.Adapters;
using ExportZipManager.Data.SqsPublisher.Configuration;
using ExportZipManager.Domain.EventsPublishing;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Data.SqsPublisher;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddSqsServices()
        {
            return services
                .AddOptionsAndValidate<SqsOptions>()
                .AddAWSService<IAmazonSQS>()
                .AddScoped<IExportZipEventsSqsPublisher, ExportZipEventsSqsPublisher>()
                .AddScoped<IAmazonSqsPublishingAdapter, AmazonSqsPublishingAdapter>();
        }
    }
}
