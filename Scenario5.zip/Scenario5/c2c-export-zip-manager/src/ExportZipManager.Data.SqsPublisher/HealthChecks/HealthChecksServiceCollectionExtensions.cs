using ExportZipManager.Core.Api.HealthChecks;
using ExportZipManager.Data.SqsPublisher.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Options;

namespace ExportZipManager.Data.SqsPublisher.HealthChecks;

public static class HealthChecksServiceCollectionExtensions
{
    extension(IHealthChecksBuilder healthChecksBuilder)
    {
        public IHealthChecksBuilder AddAmazonSqsPublisherHealthCheck(params string[] tags)
        {
            return healthChecksBuilder.AddAmazonSqsHealthCheck(
                "SQS queue is available for publishing",
                sp => sp.GetRequiredService<IOptions<SqsOptions>>().Value.QueueUrl,
                tags);
        }
    }
}
