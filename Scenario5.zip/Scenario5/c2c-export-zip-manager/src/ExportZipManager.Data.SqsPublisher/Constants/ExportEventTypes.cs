namespace ExportZipManager.Data.SqsPublisher.Constants;

internal static class ExportEventTypes
{
    public const string ExportZipGenerationRequested = "com.n-able.cove.events.c2c.export.zip.generation.requested";
}
