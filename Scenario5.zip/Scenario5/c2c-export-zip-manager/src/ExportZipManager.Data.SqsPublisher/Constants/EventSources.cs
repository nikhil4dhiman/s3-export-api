using System;

namespace ExportZipManager.Data.SqsPublisher.Constants;

internal static class EventSources
{
    public static readonly Uri ExportZipManager = new("com.n-able.cove.c2c.c2c-export-zip-manager", UriKind.Relative);
}
