using System.ComponentModel.DataAnnotations;

namespace ExportZipManager.Data.SqsPublisher.Configuration;

internal class SqsOptions
{
    [Required]
    public required string QueueUrl { get; init; }
}
