using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS;
using Amazon.SQS.Model;

namespace ExportZipManager.Data.SqsPublisher.Adapters;

internal class AmazonSqsPublishingAdapter : IAmazonSqsPublishingAdapter
{
    private readonly IAmazonSQS _sqsClient;

    public AmazonSqsPublishingAdapter(IAmazonSQS sqsClient)
    {
        _sqsClient = sqsClient;
    }

    public async Task SendMessageAsync(SendMessageRequest request, CancellationToken cancellationToken)
    {
        await _sqsClient.SendMessageAsync(request, cancellationToken);
    }
}
