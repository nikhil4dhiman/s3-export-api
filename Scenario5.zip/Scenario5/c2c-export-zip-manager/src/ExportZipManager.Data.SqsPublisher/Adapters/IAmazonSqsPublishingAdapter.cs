using System.Threading;
using System.Threading.Tasks;
using Amazon.SQS.Model;

namespace ExportZipManager.Data.SqsPublisher.Adapters;

internal interface IAmazonSqsPublishingAdapter
{
    Task SendMessageAsync(SendMessageRequest request, CancellationToken cancellationToken);
}
