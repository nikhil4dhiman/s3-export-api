using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3.Model;
using ExportZipManager.Data.S3.Api;
using ExportZipManager.Data.S3.Configuration;
using ExportZipManager.Domain.Models.Exports;
using ExportZipManager.Domain.Repositories;

namespace ExportZipManager.Data.S3;

internal class ExportFileStore : IExportFileStore
{
    private readonly IAmazonS3Api _amazonS3Api;
    private readonly S3Options _s3Options;

    public ExportFileStore(IAmazonS3Api amazonS3Api, S3Options s3Options)
    {
        _amazonS3Api = amazonS3Api;
        _s3Options = s3Options;
    }

    public async Task<string> StartMultipartUploadAsync(string key, CancellationToken cancellationToken)
    {
        var request = new InitiateMultipartUploadRequest
        {
            BucketName = _s3Options.BucketName,
            Key = key
        };

        var response = await _amazonS3Api.InitiateMultipartUploadAsync(request, cancellationToken);

        return response.UploadId;
    }

    public async Task<string> UploadPartAsync(
        string key,
        MultipartFilePartDetails part,
        CancellationToken cancellationToken)
    {
        var request = new UploadPartRequest
        {
            BucketName = _s3Options.BucketName,
            Key = key,
            UploadId = part.UploadId,
            PartNumber = part.PartNumber,
            InputStream = part.Data,
            PartSize = part.DataSize
        };

        var response = await _amazonS3Api.UploadPartAsync(request, cancellationToken);

        return response.ETag;
    }

    public async Task CompleteMultipartUploadAsync(
        string key,
        MultipartFileCompletionDetails completionDetails,
        CancellationToken cancellationToken)
    {
        var request = new CompleteMultipartUploadRequest
        {
            BucketName = _s3Options.BucketName,
            Key = key,
            UploadId = completionDetails.UploadId,
            PartETags =
            [
                .. completionDetails.Parts.OrderBy(p => p.PartNumber).Select(p => new PartETag(p.PartNumber, p.ETag))
            ]
        };

        await _amazonS3Api.CompleteMultipartUploadAsync(request, cancellationToken);
    }

    public async Task UploadFileAsync(string key, FileDetails details, CancellationToken cancellationToken)
    {
        var request = new PutObjectRequest
        {
            BucketName = _s3Options.BucketName,
            Key = key,
            InputStream = details.Data
        };

        await _amazonS3Api.PutObjectAsync(request, cancellationToken);
    }

    public async Task DeleteStagedFilesAsync(string exportId, CancellationToken cancellationToken)
    {
        var listRequest = new ListObjectsV2Request
        {
            BucketName = _s3Options.BucketName,
            Prefix = $"exports/{exportId}/staging/"
        };

        var listResponse = await _amazonS3Api.ListObjectsV2Async(listRequest, cancellationToken);

        var objectsToDelete = listResponse.S3Objects
            .Select(o => new KeyVersion { Key = o.Key })
            .Append(new KeyVersion { Key = $"exports/{exportId}" })
            .ToList();

        var deleteRequest = new DeleteObjectsRequest
        {
            BucketName = _s3Options.BucketName,
            Objects = objectsToDelete
        };

        await _amazonS3Api.DeleteObjectsAsync(deleteRequest, cancellationToken);
    }
}
