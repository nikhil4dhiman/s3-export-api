using System.ComponentModel.DataAnnotations;

namespace ExportZipManager.Data.S3.Configuration;

public class S3Options
{
    [Required]
    public required string BucketName { get; init; }
}
