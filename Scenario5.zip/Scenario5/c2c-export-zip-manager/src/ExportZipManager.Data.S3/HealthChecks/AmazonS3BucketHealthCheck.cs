using System;
using System.Threading;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;
using ExportZipManager.Data.S3.Configuration;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;

namespace ExportZipManager.Data.S3.HealthChecks;

#pragma warning disable CA1031 // catching and wrapping an exception to result type for easier handling

internal class AmazonS3BucketHealthCheck : IHealthCheck
{
    private readonly IAmazonS3 _amazonS3;
    private readonly IOptions<S3Options> _options;

    public AmazonS3BucketHealthCheck(IAmazonS3 amazonS3, IOptions<S3Options> options)
    {
        _amazonS3 = amazonS3;
        _options = options;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        var bucketName = _options.Value.BucketName;

        try
        {
            await _amazonS3.HeadBucketAsync(
                new HeadBucketRequest { BucketName = bucketName },
                cancellationToken);

            return HealthCheckResult.Healthy($"S3 bucket '{bucketName}' is available");
        }
        catch (Exception exception)
        {
            return new HealthCheckResult(
                context.Registration.FailureStatus,
                description: $"S3 bucket '{bucketName}' is unavailable",
                exception: exception);
        }
    }
}
