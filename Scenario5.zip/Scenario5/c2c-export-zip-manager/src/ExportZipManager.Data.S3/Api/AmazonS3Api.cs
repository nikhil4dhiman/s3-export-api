using System.Threading;
using System.Threading.Tasks;
using Amazon.S3;
using Amazon.S3.Model;

namespace ExportZipManager.Data.S3.Api;

internal class AmazonS3Api : IAmazonS3Api
{
    private readonly IAmazonS3 _s3Client;

    public AmazonS3Api(IAmazonS3 s3Client)
    {
        _s3Client = s3Client;
    }

    public async Task<InitiateMultipartUploadResponse> InitiateMultipartUploadAsync(
        InitiateMultipartUploadRequest initiateUploadRequest,
        CancellationToken cancellationToken)
    {
        return await _s3Client.InitiateMultipartUploadAsync(initiateUploadRequest, cancellationToken);
    }

    public async Task<UploadPartResponse> UploadPartAsync(
        UploadPartRequest uploadPartRequest,
        CancellationToken cancellationToken)
    {
        return await _s3Client.UploadPartAsync(uploadPartRequest, cancellationToken);
    }

    public async Task<CompleteMultipartUploadResponse> CompleteMultipartUploadAsync(
        CompleteMultipartUploadRequest completeUploadRequest,
        CancellationToken cancellationToken)
    {
        return await _s3Client.CompleteMultipartUploadAsync(completeUploadRequest, cancellationToken);
    }

    public async Task<ListObjectsV2Response> ListObjectsV2Async(
        ListObjectsV2Request request,
        CancellationToken cancellationToken)
    {
        return await _s3Client.ListObjectsV2Async(request, cancellationToken);
    }

    public async Task DeleteObjectsAsync(
        DeleteObjectsRequest request,
        CancellationToken cancellationToken)
    {
        await _s3Client.DeleteObjectsAsync(request, cancellationToken);
    }

    public async Task PutObjectAsync(PutObjectRequest request, CancellationToken cancellationToken)
    {
        await _s3Client.PutObjectAsync(request, cancellationToken);
    }
}
