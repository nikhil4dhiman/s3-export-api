using System.Threading;
using System.Threading.Tasks;
using Amazon.S3.Model;

namespace ExportZipManager.Data.S3.Api;

internal interface IAmazonS3Api
{
    Task<InitiateMultipartUploadResponse> InitiateMultipartUploadAsync(
        InitiateMultipartUploadRequest initiateUploadRequest,
        CancellationToken cancellationToken);

    Task<UploadPartResponse> UploadPartAsync(
        UploadPartRequest uploadPartRequest,
        CancellationToken cancellationToken);

    Task<CompleteMultipartUploadResponse> CompleteMultipartUploadAsync(
        CompleteMultipartUploadRequest completeUploadRequest,
        CancellationToken cancellationToken);

    Task<ListObjectsV2Response> ListObjectsV2Async(
        ListObjectsV2Request request,
        CancellationToken cancellationToken);

    Task DeleteObjectsAsync(
        DeleteObjectsRequest request,
        CancellationToken cancellationToken);

    Task PutObjectAsync(PutObjectRequest request, CancellationToken cancellationToken);
}
