using Amazon.S3;
using Cove.Platform.Extensions.Configuration;
using ExportZipManager.Data.S3.Api;
using ExportZipManager.Data.S3.Configuration;
using ExportZipManager.Domain.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Data.S3;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddS3Services()
        {
            return services
                .AddOptionsAndValidate<S3Options>()
                .AddAWSService<IAmazonS3>()
                .AddScoped<IExportFileStore, ExportFileStore>()
                .AddScoped<IAmazonS3Api, AmazonS3Api>();
        }
    }
}
