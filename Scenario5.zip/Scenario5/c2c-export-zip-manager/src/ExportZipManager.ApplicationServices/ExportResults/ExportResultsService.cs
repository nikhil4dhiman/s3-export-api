using System;
using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.Models.Exports;
using ExportZipManager.Domain.Repositories;

namespace ExportZipManager.ApplicationServices.ExportResults;

public class ExportResultsService
{
    private readonly IExportRepository _exportRepository;

    public ExportResultsService(IExportRepository exportRepository)
    {
        _exportRepository = exportRepository;
    }

    public Task<ExportRecord?> GetExportInfoAsync(string exportId, CancellationToken cancellationToken)
    {
        return _exportRepository.GetAsync(exportId, cancellationToken);
    }

    public Task<bool> UpdateExportStatusAsync(
        string exportId,
        ExportStatus status,
        string? fileId,
        DateTimeOffset completedAt,
        CancellationToken cancellationToken)
    {
        return _exportRepository.TryUpdateStatusAsync(exportId, status, fileId, completedAt, cancellationToken);
    }
}
