using ExportZipManager.ApplicationServices.ExportResults;
using ExportZipManager.ApplicationServices.Exports;
using ExportZipManager.ApplicationServices.Samples;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.ApplicationServices;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddApplicationServices()
        {
            return services
                .AddScoped<SamplesService>()
                .AddScoped<ExportsService>()
                .AddScoped<ExportResultsService>();
        }
    }
}
