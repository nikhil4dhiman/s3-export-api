using System;
using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.EventsPublishing;
using ExportZipManager.Domain.Exceptions;
using ExportZipManager.Domain.Metrics;
using ExportZipManager.Domain.Models.Exports;
using ExportZipManager.Domain.Repositories;

namespace ExportZipManager.ApplicationServices.Exports;

public class ExportsService
{
    private readonly IExportFileStore _exportFileStore;
    private readonly IExportRepository _exportRepository;
    private readonly IExportZipEventsSqsPublisher _exportZipEventsPublisher;
    private readonly IMetricsService _metricsService;
    private readonly TimeProvider _timeProvider;

    public ExportsService(
        IExportFileStore exportFileStore,
        IExportRepository exportRepository,
        IExportZipEventsSqsPublisher exportZipEventsPublisher,
        IMetricsService metricsService,
        TimeProvider timeProvider)
    {
        _exportFileStore = exportFileStore;
        _exportRepository = exportRepository;
        _exportZipEventsPublisher = exportZipEventsPublisher;
        _metricsService = metricsService;
        _timeProvider = timeProvider;
    }

    public async Task<string> StartExportAsync(ExportInfo exportInfo, CancellationToken cancellationToken)
    {
        var exportId = ExportHelper.GetExportId(exportInfo);

        var export = new ExportRecord
        {
            Id = exportId,
            Status = ExportStatus.InProgress,
            StartedAt = _timeProvider.GetUtcNow()
        };

        // The export id is derived from the request, so a retried start resolves to the same record.
        // The conditional create keeps the first StartedAt -- that is when the customer began
        // waiting -- and leaves an already finished export untouched so complete still rejects it.
        var isCreated = await _exportRepository.TryCreateAsync(export, cancellationToken);

        if (isCreated)
        {
            _metricsService.IncreaseNumberOfExportsStarted();
        }

        return exportId;
    }

    public async Task<string> StartMultipartFileAsync(
        string exportId,
        string fileName,
        CancellationToken cancellationToken)
    {
        var key = BuildStagingFileKey(exportId, fileName);

        return await _exportFileStore.StartMultipartUploadAsync(key, cancellationToken);
    }

    public async Task<string> UploadMultipartFilePartAsync(
        MultipartFilePartDetails partDetails,
        CancellationToken cancellationToken)
    {
        var key = BuildStagingFileKey(partDetails.ExportId, partDetails.FileName);

        return await _exportFileStore.UploadPartAsync(key, partDetails, cancellationToken);
    }

    public async Task CompleteMultipartFileAsync(
        MultipartFileCompletionDetails completionDetails,
        CancellationToken cancellationToken)
    {
        var key = BuildStagingFileKey(completionDetails.ExportId, completionDetails.FileName);

        await _exportFileStore.CompleteMultipartUploadAsync(key, completionDetails, cancellationToken);
    }

    public async Task UploadFileAsync(FileDetails fileDetails, CancellationToken cancellationToken)
    {
        // TODO: C2C-15530 - Validate that the export exists once the exports table is added.

        var key = BuildStagingFileKey(fileDetails.ExportId, fileDetails.FileName);

        await _exportFileStore.UploadFileAsync(key, fileDetails, cancellationToken);
    }

    public async Task CompleteExportAsync(
        string exportId,
        string partnerId,
        string sourceName,
        SourceType sourceType,
        CancellationToken cancellationToken)
    {
        var zipGenerationRequestedAt = _timeProvider.GetUtcNow();
        var existingExportInfo = await _exportRepository.GetAsync(exportId, cancellationToken);

        if (existingExportInfo is not null)
        {
            if (existingExportInfo.Status != ExportStatus.InProgress)
            {
                throw new ExportAlreadyProcessedException(exportId, existingExportInfo.Status);
            }

            await _exportRepository.TrySetZipRequestedAtAsync(exportId, zipGenerationRequestedAt, cancellationToken);
        }

        var completionDetails = new ExportCompletionDetails
        {
            ExportId = exportId,
            PartnerId = partnerId,
            SourceName = sourceName,
            SourceType = sourceType,
            ZipRequestedAt = existingExportInfo?.ZipRequestedAt ?? zipGenerationRequestedAt
        };

        await _exportZipEventsPublisher.PublishAsync(completionDetails, cancellationToken);
    }

    public async Task<ExportRecord> GetExportStatusAsync(string exportId, CancellationToken cancellationToken)
    {
        var export = await _exportRepository.GetAsync(exportId, cancellationToken);

        if (export is null)
        {
            throw new NotFoundException(nameof(ExportRecord), exportId);
        }

        return export;
    }

    public async Task CancelExportAsync(string exportId, CancellationToken cancellationToken)
    {
        var existingExportInfo = await _exportRepository.GetAsync(exportId, cancellationToken);

        if (existingExportInfo?.Status is ExportStatus.Cancelled)
        {
            return;
        }

        var cancelledAt = _timeProvider.GetUtcNow();

        if (existingExportInfo?.Status is ExportStatus.InProgress)
        {
            // A concurrent cancel can have already won this race, leaving the update a no-op; only
            // count a cancellation this call actually performed.
            var isUpdated = await _exportRepository.TryUpdateStatusAsync(
                exportId,
                ExportStatus.Cancelled,
                fileId: null,
                cancelledAt,
                cancellationToken);

            if (isUpdated)
            {
                _metricsService.IncreaseNumberOfExportsCancelled();
            }

            return;
        }

        if (existingExportInfo is null)
        {
            // Records the cancellation so a later complete is rejected with 409 instead of
            // publishing a zip generation job whose staged files have just been deleted. StartedAt
            // is only used here as a fallback: /start was never called for this export, so the
            // earliest time it's known to exist is now.
            var exportInfo = new ExportRecord
            {
                Id = exportId,
                Status = ExportStatus.Cancelled,
                StartedAt = cancelledAt,
                CancelledAt = cancelledAt
            };

            // A concurrent complete or cancel can have created the record first, making this a
            // no-op; only count a record this call actually created.
            var isCancellationRecorded = await _exportRepository.TryCreateAsync(exportInfo, cancellationToken);

            if (isCancellationRecorded)
            {
                _metricsService.IncreaseNumberOfExportsCancelled();
            }
        }

        await _exportFileStore.DeleteStagedFilesAsync(exportId, cancellationToken);
    }

    private static string BuildStagingFileKey(string exportId, string fileName)
    {
        return $"exports/{exportId}/staging/{fileName}";
    }
}
