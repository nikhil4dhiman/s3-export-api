using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.ApplicationServices.Exports;

internal static class ExportHelper
{
    private const string Hyphen = "-";

    public static string GetExportId(ExportInfo exportInfo)
    {
        return string.Concat(
            exportInfo.SourceId, Hyphen,
            exportInfo.BackupId, Hyphen,
            exportInfo.SessionId, Hyphen,
            exportInfo.RunId);
    }
}
