using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.Models;
using ExportZipManager.Domain.Models.Paging;
using ExportZipManager.Domain.Repositories;

namespace ExportZipManager.ApplicationServices.Samples;

public class SamplesService
{
    private readonly ISamplesRepository _samplesRepository;

    public SamplesService(ISamplesRepository samplesRepository)
    {
        _samplesRepository = samplesRepository;
    }

    public async Task<Page<Sample>> GetSamplesPageAsync(
        int skip,
        int take,
        CancellationToken cancellationToken)
    {
        return await _samplesRepository.GetSamplesPageAsync(skip, take, cancellationToken);
    }

    public async Task<Sample> GetSampleByIdAsync(string id, CancellationToken cancellationToken)
    {
        return await _samplesRepository.GetSampleByIdAsync(id, cancellationToken);
    }

    public async Task<Sample> CreateSampleAsync(Sample sample, CancellationToken cancellationToken)
    {
        return await _samplesRepository.CreateSampleAsync(sample, cancellationToken);
    }
}
