using System.ComponentModel.DataAnnotations;

namespace ExportZipManager.Data.DynamoDb.Configuration;

internal class DynamoDbOptions
{
    [Required]
    public required string TableName { get; init; }
}
