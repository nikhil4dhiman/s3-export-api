using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Data.DynamoDb.HealthChecks;

public static class HealthChecksServiceCollectionExtensions
{
    extension(IHealthChecksBuilder healthChecksBuilder)
    {
        public IHealthChecksBuilder AddAmazonDynamoDbHealthCheck(params string[] tags)
        {
            return healthChecksBuilder.AddCheck<AmazonDynamoDbHealthCheck>(
                "DynamoDB table is available for consuming",
                tags: tags);
        }
    }
}
