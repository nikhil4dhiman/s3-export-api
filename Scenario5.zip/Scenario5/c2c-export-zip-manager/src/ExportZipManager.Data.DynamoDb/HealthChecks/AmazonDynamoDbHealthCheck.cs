using System;
using System.Threading;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using ExportZipManager.Data.DynamoDb.Configuration;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;

namespace ExportZipManager.Data.DynamoDb.HealthChecks;

#pragma warning disable CA1031 // catching and wrapping an exception to result type for easier handling

internal class AmazonDynamoDbHealthCheck : IHealthCheck
{
    private readonly IAmazonDynamoDB _amazonDynamoDb;
    private readonly IOptions<DynamoDbOptions> _options;

    public AmazonDynamoDbHealthCheck(IAmazonDynamoDB amazonDynamoDb, IOptions<DynamoDbOptions> options)
    {
        _amazonDynamoDb = amazonDynamoDb;
        _options = options;
    }

    public async Task<HealthCheckResult> CheckHealthAsync(
        HealthCheckContext context,
        CancellationToken cancellationToken = default)
    {
        var tableName = _options.Value.TableName;

        try
        {
            await _amazonDynamoDb.DescribeTableAsync(tableName, cancellationToken);

            return HealthCheckResult.Healthy($"DynamoDB table '{tableName}' is available");
        }
        catch (Exception exception)
        {
            return new HealthCheckResult(
                context.Registration.FailureStatus,
                description: $"DynamoDB table '{tableName}' is unavailable",
                exception: exception);
        }
    }
}
