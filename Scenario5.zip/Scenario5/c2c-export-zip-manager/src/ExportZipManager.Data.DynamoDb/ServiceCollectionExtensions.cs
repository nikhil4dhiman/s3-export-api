using Amazon.DynamoDBv2;
using Cove.Platform.Extensions.Configuration;
using ExportZipManager.Data.DynamoDb.Api;
using ExportZipManager.Data.DynamoDb.Configuration;
using ExportZipManager.Domain.Repositories;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Data.DynamoDb;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddDynamoDbServices()
        {
            return services
                .AddOptionsAndValidate<DynamoDbOptions>()
                .AddAWSService<IAmazonDynamoDB>()
                .AddScoped<IExportRepository, ExportRepository>()
                .AddScoped<IAmazonDynamoDbApi, AmazonDynamoDbApi>();
        }
    }
}
