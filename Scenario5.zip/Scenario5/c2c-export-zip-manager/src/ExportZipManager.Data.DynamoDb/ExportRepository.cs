using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;
using ExportZipManager.Data.DynamoDb.Api;
using ExportZipManager.Data.DynamoDb.Configuration;
using ExportZipManager.Data.DynamoDb.Extensions;
using ExportZipManager.Data.DynamoDb.Logging;
using ExportZipManager.Domain.Exceptions;
using ExportZipManager.Domain.Models.Exports;
using ExportZipManager.Domain.Repositories;
using Microsoft.Extensions.Logging;
using ExportStatus = ExportZipManager.Domain.Models.Exports.ExportStatus;

namespace ExportZipManager.Data.DynamoDb;

internal class ExportRepository : IExportRepository
{
    private readonly IAmazonDynamoDbApi _dynamoDbApi;
    private readonly DynamoDbOptions _dynamoDbOptions;
    private readonly ILogger<ExportRepository> _logger;

    public ExportRepository(
        IAmazonDynamoDbApi dynamoDbApi,
        DynamoDbOptions dynamoDbOptions,
        ILogger<ExportRepository> logger)
    {
        _dynamoDbApi = dynamoDbApi;
        _dynamoDbOptions = dynamoDbOptions;
        _logger = logger;
    }

    public async Task<bool> TryCreateAsync(ExportRecord export, CancellationToken cancellationToken)
    {
        var item = new Dictionary<string, AttributeValue>
        {
            ["Id"] = new() { S = export.Id },
            ["Status"] = new() { S = export.Status.ToString() },
            ["FileId"] = export.FileId.ToAttributeValue(),
            ["StartedAt"] = export.StartedAt.ToAttributeValue()
        };

        item.AddIfNotNull("ZipRequestedAt", export.ZipRequestedAt);
        item.AddIfNotNull("CompletedAt", export.CompletedAt);
        item.AddIfNotNull("CancelledAt", export.CancelledAt);

        var request = new PutItemRequest
        {
            TableName = _dynamoDbOptions.TableName,
            Item = item,
            ConditionExpression = "attribute_not_exists(Id)"
        };

        try
        {
            await _dynamoDbApi.PutItemAsync(request, cancellationToken);

            return true;
        }
        catch (ConditionalCheckFailedException)
        {
            return false;
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogDynamoDbWriteFailure(e, export.Id);

            throw;
        }
    }

    public async Task<bool> TryUpdateStatusAsync(
        string exportId,
        ExportStatus status,
        string? fileId,
        DateTimeOffset terminalAt,
        CancellationToken cancellationToken)
    {
        var terminalAtAttributeName = status == ExportStatus.Cancelled ? "CancelledAt" : "CompletedAt";

        var request = BuildUpdateItemRequest(
            exportId,
            updateExpression: "SET #status = :status, FileId = :fileId, #terminalAt = :terminalAt",
            conditionExpression: "attribute_exists(Id) AND #status <> :cancelledStatus",
            expressionAttributeValues: new Dictionary<string, AttributeValue>
            {
                [":status"] = new() { S = status.ToString() },
                [":fileId"] = fileId.ToAttributeValue(),
                [":terminalAt"] = terminalAt.ToAttributeValue(),
                [":cancelledStatus"] = new() { S = nameof(ExportStatus.Cancelled) }
            },
            expressionAttributeNames: new Dictionary<string, string>
            {
                ["#status"] = "Status",
                ["#terminalAt"] = terminalAtAttributeName
            },
            returnValuesOnConditionCheckFailure: ReturnValuesOnConditionCheckFailure.ALL_OLD);

        try
        {
            await _dynamoDbApi.UpdateItemAsync(request, cancellationToken);

            return true;
        }
        catch (ConditionalCheckFailedException e)
        {
            if (e.Item is not { Count: > 0 })
            {
                throw new NotFoundException(nameof(ExportRecord), exportId);
            }

            return false;
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogDynamoDbWriteFailure(e, exportId);

            throw;
        }
    }

    public async Task TrySetZipRequestedAtAsync(
        string exportId,
        DateTimeOffset zipRequestedAt,
        CancellationToken cancellationToken)
    {
        // The complete endpoint is retryable and republishes the zip generation event for an
        // export that is still in progress. if_not_exists keeps the first request time, so a
        // retry cannot make the measured processing time look shorter than it was.
        var request = BuildUpdateItemRequest(
            exportId,
            updateExpression: "SET ZipRequestedAt = if_not_exists(ZipRequestedAt, :zipRequestedAt)",
            conditionExpression: "attribute_exists(Id)",
            expressionAttributeValues: new Dictionary<string, AttributeValue>
            {
                [":zipRequestedAt"] = zipRequestedAt.ToAttributeValue()
            });

        try
        {
            await _dynamoDbApi.UpdateItemAsync(request, cancellationToken);
        }
        catch (ConditionalCheckFailedException)
        {
            // The record disappeared between reading it and stamping it.
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogDynamoDbWriteFailure(e, exportId);

            throw;
        }
    }

    public async Task<ExportRecord?> GetAsync(string exportId, CancellationToken cancellationToken)
    {
        var request = new GetItemRequest
        {
            TableName = _dynamoDbOptions.TableName,
            Key = new Dictionary<string, AttributeValue> { ["Id"] = new() { S = exportId } },
            ConsistentRead = true
        };

        try
        {
            var response = await _dynamoDbApi.GetItemAsync(request, cancellationToken);

            if (response.Item is not { Count: > 0 })
            {
                return null;
            }

            var statusValue = response.Item["Status"].S;

            if (!Enum.TryParse<ExportStatus>(statusValue, out var status))
            {
                throw new InvalidOperationException(
                    $"Unknown export status '{statusValue}' stored in DynamoDB. ExportId: {exportId}");
            }

            return new ExportRecord
            {
                Id = response.Item["Id"].S,
                Status = status,
                FileId = response.Item.GetNullableString("FileId"),
                StartedAt = response.Item.GetTimestamp("StartedAt"),
                ZipRequestedAt = response.Item.GetNullableTimestamp("ZipRequestedAt"),
                CompletedAt = response.Item.GetNullableTimestamp("CompletedAt"),
                CancelledAt = response.Item.GetNullableTimestamp("CancelledAt")
            };
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogDynamoDbReadFailure(e, exportId);

            throw;
        }
    }

    /// <summary>
    /// The UpdateItem skeleton every conditional update on this table shares. Callers differ in
    /// their expression and in how they react to a failed condition -- one must distinguish
    /// "not found" from "condition failed", the other treats both alike -- so those stay separate
    /// rather than being forced into one shared success/failure contract.
    /// </summary>
    private UpdateItemRequest BuildUpdateItemRequest(
        string exportId,
        string updateExpression,
        string conditionExpression,
        Dictionary<string, AttributeValue> expressionAttributeValues,
        Dictionary<string, string>? expressionAttributeNames = null,
        ReturnValuesOnConditionCheckFailure? returnValuesOnConditionCheckFailure = null)
    {
        return new UpdateItemRequest
        {
            TableName = _dynamoDbOptions.TableName,
            Key = new Dictionary<string, AttributeValue> { ["Id"] = new() { S = exportId } },
            UpdateExpression = updateExpression,
            ExpressionAttributeNames = expressionAttributeNames,
            ExpressionAttributeValues = expressionAttributeValues,
            ConditionExpression = conditionExpression,
            ReturnValuesOnConditionCheckFailure = returnValuesOnConditionCheckFailure
        };
    }
}
