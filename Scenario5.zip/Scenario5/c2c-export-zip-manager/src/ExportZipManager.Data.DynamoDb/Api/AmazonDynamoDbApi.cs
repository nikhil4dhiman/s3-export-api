using System.Threading;
using System.Threading.Tasks;
using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.Model;

namespace ExportZipManager.Data.DynamoDb.Api;

internal class AmazonDynamoDbApi : IAmazonDynamoDbApi
{
    private readonly IAmazonDynamoDB _dynamoDbClient;

    public AmazonDynamoDbApi(IAmazonDynamoDB dynamoDbClient)
    {
        _dynamoDbClient = dynamoDbClient;
    }

    public async Task PutItemAsync(PutItemRequest request, CancellationToken cancellationToken)
    {
        await _dynamoDbClient.PutItemAsync(request, cancellationToken);
    }

    public async Task UpdateItemAsync(UpdateItemRequest request, CancellationToken cancellationToken)
    {
        await _dynamoDbClient.UpdateItemAsync(request, cancellationToken);
    }

    public async Task<GetItemResponse> GetItemAsync(GetItemRequest request, CancellationToken cancellationToken)
    {
        return await _dynamoDbClient.GetItemAsync(request, cancellationToken);
    }
}
