using System.Threading;
using System.Threading.Tasks;
using Amazon.DynamoDBv2.Model;

namespace ExportZipManager.Data.DynamoDb.Api;

internal interface IAmazonDynamoDbApi
{
    Task PutItemAsync(PutItemRequest request, CancellationToken cancellationToken);

    Task UpdateItemAsync(UpdateItemRequest request, CancellationToken cancellationToken);

    Task<GetItemResponse> GetItemAsync(GetItemRequest request, CancellationToken cancellationToken);
}
