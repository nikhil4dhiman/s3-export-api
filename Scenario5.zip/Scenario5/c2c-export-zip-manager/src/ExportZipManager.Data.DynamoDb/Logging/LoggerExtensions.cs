using System;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.Data.DynamoDb.Logging;

internal static class LoggerExtensions
{
    private static readonly Action<ILogger, string, Exception?> WriteFailureLogger =
        LoggerMessage.Define<string>(
            LogLevel.Error,
            new EventId(1, "DynamoDbWriteFailure"),
            "Failed to write to DynamoDB. ExportId: {ExportId}");

    private static readonly Action<ILogger, string, Exception?> ReadFailureLogger =
        LoggerMessage.Define<string>(
            LogLevel.Error,
            new EventId(2, "DynamoDbReadFailure"),
            "Failed to read from DynamoDB. ExportId: {ExportId}");

    public static void LogDynamoDbWriteFailure(
        this ILogger<ExportRepository> logger, Exception exception, string exportId)
    {
        WriteFailureLogger(logger, exportId, exception);
    }

    public static void LogDynamoDbReadFailure(
        this ILogger<ExportRepository> logger, Exception exception, string exportId)
    {
        ReadFailureLogger(logger, exportId, exception);
    }
}
