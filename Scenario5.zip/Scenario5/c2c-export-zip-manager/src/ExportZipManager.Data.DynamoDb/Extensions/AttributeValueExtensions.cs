using System;
using System.Collections.Generic;
using System.Globalization;
using Amazon.DynamoDBv2.Model;

namespace ExportZipManager.Data.DynamoDb.Extensions;

internal static class AttributeValueExtensions
{
    public static AttributeValue ToAttributeValue(this string? value)
    {
        return value is null
            ? new AttributeValue { NULL = true }
            : new AttributeValue { S = value };
    }

    // Round-trippable ISO-8601, so the timestamps stay readable in the DynamoDB console and sort
    // lexicographically.
    public static AttributeValue ToAttributeValue(this DateTimeOffset value)
    {
        return new AttributeValue { S = value.ToString("O", CultureInfo.InvariantCulture) };
    }

    public static void AddIfNotNull(
        this Dictionary<string, AttributeValue> item,
        string attributeName,
        DateTimeOffset? value)
    {
        if (value is { } actualValue)
        {
            item[attributeName] = actualValue.ToAttributeValue();
        }
    }

    public static string? GetNullableString(this Dictionary<string, AttributeValue> item, string key)
    {
        return item.TryGetValue(key, out var attribute) && attribute.NULL != true
            ? attribute.S
            : null;
    }

    public static DateTimeOffset? GetNullableTimestamp(this Dictionary<string, AttributeValue> item, string key)
    {
        var value = item.GetNullableString(key);

        return DateTimeOffset.TryParse(
            value,
            CultureInfo.InvariantCulture,
            DateTimeStyles.RoundtripKind,
            out var timestamp)
            ? timestamp
            : null;
    }

    public static DateTimeOffset GetTimestamp(this Dictionary<string, AttributeValue> item, string key)
    {
        return item.GetNullableTimestamp(key)
            ?? throw new InvalidOperationException($"Missing or invalid required timestamp '{key}' in DynamoDB item.");
    }
}
