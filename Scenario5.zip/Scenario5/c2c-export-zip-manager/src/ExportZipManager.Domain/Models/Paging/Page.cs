using System.Collections.Generic;

namespace ExportZipManager.Domain.Models.Paging;

public class Page<TItem>
{
    public Page(IReadOnlyCollection<TItem> items, int totalCount)
    {
        Items = items;
        TotalCount = totalCount;
    }

    public IReadOnlyCollection<TItem> Items { get; }

    public int TotalCount { get; }
}
