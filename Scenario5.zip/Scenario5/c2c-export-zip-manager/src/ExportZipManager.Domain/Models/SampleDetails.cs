namespace ExportZipManager.Domain.Models;

public class SampleDetails
{
    public string? AdditionalDetails { get; set; }
}
