namespace ExportZipManager.Domain.Models;

public class Sample
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;

    public SampleDetails? Details { get; set; }
}
