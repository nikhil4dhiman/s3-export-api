namespace ExportZipManager.Domain.Models.Exports;

public enum ExportStatus
{
    InProgress,
    Completed,
    Failed,
    Cancelled
}
