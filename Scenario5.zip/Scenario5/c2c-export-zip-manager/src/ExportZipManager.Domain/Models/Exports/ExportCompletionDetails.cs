using System;

namespace ExportZipManager.Domain.Models.Exports;

public class ExportCompletionDetails
{
    public required string ExportId { get; init; }

    public required string PartnerId { get; init; }

    public required string SourceName { get; init; }

    public required SourceType SourceType { get; init; }

    public required DateTimeOffset ZipRequestedAt { get; init; }
}
