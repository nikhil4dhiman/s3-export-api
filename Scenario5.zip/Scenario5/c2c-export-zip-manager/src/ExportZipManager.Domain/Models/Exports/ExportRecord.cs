using System;

namespace ExportZipManager.Domain.Models.Exports;

public class ExportRecord
{
    public required string Id { get; init; }

    public required ExportStatus Status { get; init; }

    public string? FileId { get; init; }

    public required DateTimeOffset StartedAt { get; init; }

    public DateTimeOffset? ZipRequestedAt { get; init; }

    public DateTimeOffset? CompletedAt { get; init; }

    public DateTimeOffset? CancelledAt { get; init; }
}
