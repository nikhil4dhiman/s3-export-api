using System.Collections.Generic;

namespace ExportZipManager.Domain.Models.Exports;

public class MultipartFileCompletionDetails
{
    public required string ExportId { get; init; }

    public required string FileName { get; init; }

    public required string UploadId { get; init; }

    public required IReadOnlyCollection<CompletedFilePart> Parts { get; init; }
}
