using System.IO;

namespace ExportZipManager.Domain.Models.Exports;

public class FileDetails
{
    public required string ExportId { get; init; }

    public required string FileName { get; init; }

    public required Stream Data { get; init; }
}
