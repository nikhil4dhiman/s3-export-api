namespace ExportZipManager.Domain.Models.Exports;

public class ExportInfo
{
    public required string BackupId { get; init; }

    public required string SessionId { get; init; }

    public required string RunId { get; init; }

    public required string SourceId { get; init; }
}
