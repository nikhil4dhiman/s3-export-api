using System.IO;

namespace ExportZipManager.Domain.Models.Exports;

public class MultipartFilePartDetails
{
    public required string ExportId { get; init; }

    public required string FileName { get; init; }

    public required string UploadId { get; init; }

    public required int PartNumber { get; init; }

    public required Stream Data { get; init; }

    public required long DataSize { get; init; }
}
