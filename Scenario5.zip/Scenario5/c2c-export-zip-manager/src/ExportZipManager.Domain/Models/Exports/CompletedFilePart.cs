namespace ExportZipManager.Domain.Models.Exports;

public class CompletedFilePart
{
    public required int PartNumber { get; init; }

    public required string ETag { get; init; }
}
