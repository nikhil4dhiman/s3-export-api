namespace ExportZipManager.Domain.Models.Exports;

/// <summary>The workload an export was taken from, and part of the archive's name.</summary>
public enum SourceType
{
    SharePoint,
    OneDrive
}
