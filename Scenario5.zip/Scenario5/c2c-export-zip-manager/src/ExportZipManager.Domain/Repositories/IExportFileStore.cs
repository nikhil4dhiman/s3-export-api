using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Domain.Repositories;

public interface IExportFileStore
{
    Task<string> StartMultipartUploadAsync(string key, CancellationToken cancellationToken);

    Task<string> UploadPartAsync(
        string key,
        MultipartFilePartDetails part,
        CancellationToken cancellationToken);

    Task CompleteMultipartUploadAsync(
        string key,
        MultipartFileCompletionDetails completionDetails,
        CancellationToken cancellationToken);

    Task DeleteStagedFilesAsync(string exportId, CancellationToken cancellationToken);

    Task UploadFileAsync(string key, FileDetails details, CancellationToken cancellationToken);
}
