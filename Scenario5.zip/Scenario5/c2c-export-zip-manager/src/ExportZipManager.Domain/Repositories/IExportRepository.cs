using System;
using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Domain.Repositories;

public interface IExportRepository
{
    Task<bool> TryCreateAsync(ExportRecord export, CancellationToken cancellationToken);

    Task<ExportRecord?> GetAsync(string exportId, CancellationToken cancellationToken);

    /// <summary>
    /// Sets a terminal status. The timestamp lands in CancelledAt or CompletedAt depending on
    /// which status is being set.
    /// </summary>
    Task<bool> TryUpdateStatusAsync(
        string exportId,
        ExportStatus status,
        string? fileId,
        DateTimeOffset terminalAt,
        CancellationToken cancellationToken);

    /// <summary>
    /// Stamps when the zip was first requested. If_not_exists means the first complete call wins,
    /// so a republish for an export still in progress reads back the same request time instead of
    /// a fresh one.
    /// </summary>
    Task TrySetZipRequestedAtAsync(
        string exportId,
        DateTimeOffset zipRequestedAt,
        CancellationToken cancellationToken);
}
