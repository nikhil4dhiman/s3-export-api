using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.Models;
using ExportZipManager.Domain.Models.Paging;

namespace ExportZipManager.Domain.Repositories;

public interface ISamplesRepository
{
    Task<Page<Sample>> GetSamplesPageAsync(int skip, int take, CancellationToken cancellationToken);

    Task<Sample> GetSampleByIdAsync(string id, CancellationToken cancellationToken);

    Task<Sample> CreateSampleAsync(Sample sample, CancellationToken cancellationToken);
}
