namespace ExportZipManager.Domain.Metrics;

public interface IMetricsService
{
    void IncreaseNumberOfZipGenerationEventsPublished(string result);

    void IncreaseNumberOfZipGenerationResultEventsProcessed(string result);

    void IncreaseNumberOfExportsStarted();

    void IncreaseNumberOfExportsCompleted(string result);

    void IncreaseNumberOfExportsCancelled();

    void ObserveExportDuration(string result, double durationInSeconds);

    void ObserveExportZipProcessingDuration(string result, double durationInSeconds);
}
