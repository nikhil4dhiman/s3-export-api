using System;

namespace ExportZipManager.Domain.Exceptions;

public class DomainException : Exception
{
    protected DomainException(string message)
        : base(message)
    {
    }
}
