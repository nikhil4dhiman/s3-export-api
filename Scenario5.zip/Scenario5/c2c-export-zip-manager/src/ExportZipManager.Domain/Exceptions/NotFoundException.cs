namespace ExportZipManager.Domain.Exceptions;

public class NotFoundException : DomainException
{
    public NotFoundException(string modelName, string id)
        : base($"{modelName} with Id={id} was not found.")
    {
        ModelName = modelName;
        Id = id;
    }

    public string ModelName { get; }

    public string Id { get; }
}
