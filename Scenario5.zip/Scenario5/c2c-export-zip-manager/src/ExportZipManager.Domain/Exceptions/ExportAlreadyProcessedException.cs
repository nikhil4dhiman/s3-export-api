using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Domain.Exceptions;

public class ExportAlreadyProcessedException : DomainException
{
    public ExportAlreadyProcessedException(string exportId, ExportStatus status)
        : base($"Export with Id={exportId} was already processed. Status={status}.")
    {
        ExportId = exportId;
        Status = status;
    }

    public string ExportId { get; }

    public ExportStatus Status { get; }
}
