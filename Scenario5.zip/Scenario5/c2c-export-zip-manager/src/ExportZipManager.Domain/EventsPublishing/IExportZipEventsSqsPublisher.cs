using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Domain.EventsPublishing;

public interface IExportZipEventsSqsPublisher
{
    Task PublishAsync(ExportCompletionDetails completionDetails, CancellationToken cancellationToken);
}
