namespace ExportZipManager.Api.Validation;

internal static class ValidationMessages
{
    public const string PropertyShouldNotBeNullOrEmpty = "{PropertyName} should not be null or empty.";

    public const string PropertyShouldBeGreaterThanOrEqualTo = "{PropertyName} should be greater than or equal to {ComparisonValue}.";

    public const string PropertyShouldBeBetweenValues = "{PropertyName} should be between {From} and {To}.";

    public const string FileNameShouldNotContainPathTraversal = "{PropertyName} must not contain path traversal sequences.";

    public const string PropertyShouldBeAKnownValue = "{PropertyName} is not a known value.";

    public static string PropertyShouldNotBeNullOrEmptyWhenDependentPropertyIsTrue(string dependentProperty)
    {
        return $"{{PropertyName}} should not be null or empty when {dependentProperty} property is true.";
    }
}
