using ExportZipManager.Api.Models.Samples.Requests;
using FluentValidation;

namespace ExportZipManager.Api.Validation.Samples;

internal class CreateSampleRequestDetailsValidator : AbstractValidator<CreateSampleRequestDetails>
{
    public CreateSampleRequestDetailsValidator()
    {
        RuleFor(x => x.AdditionalDetails)
            .Required();
    }
}
