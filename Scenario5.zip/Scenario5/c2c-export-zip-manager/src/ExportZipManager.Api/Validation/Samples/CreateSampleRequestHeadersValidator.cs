using ExportZipManager.Api.Models.Samples.Requests;
using FluentValidation;

namespace ExportZipManager.Api.Validation.Samples;

internal class CreateSampleRequestHeadersValidator : AbstractValidator<CreateSampleRequestHeaders>
{
    public CreateSampleRequestHeadersValidator()
    {
        RuleFor(x => x.UserId)
            .Required();
    }
}
