using ExportZipManager.Api.Configuration;
using ExportZipManager.Api.Models.Samples.Requests;
using FluentValidation;

namespace ExportZipManager.Api.Validation.Samples;

internal class GetSamplesRequestQueryValidator : AbstractValidator<GetSamplesRequestQuery>
{
    public GetSamplesRequestQueryValidator(PagingOptions pagingOptions)
    {
        RuleFor(x => x.Skip)
            .PositiveWhenProvided();

        RuleFor(x => x.Take)
            .InclusiveBetweenWhenProvided(1, pagingOptions.MaxPageSize);
    }
}
