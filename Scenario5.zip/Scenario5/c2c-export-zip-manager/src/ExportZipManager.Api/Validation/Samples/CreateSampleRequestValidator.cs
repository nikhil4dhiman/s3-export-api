using ExportZipManager.Api.Models.Samples.Requests;
using FluentValidation;

namespace ExportZipManager.Api.Validation.Samples;

internal class CreateSampleRequestValidator : AbstractValidator<CreateSampleRequest>
{
    public CreateSampleRequestValidator()
    {
        RuleFor(x => x.Name)
            .Required();

        When(x => x.SomeFlagFieldThatWillRequireDetails,
            () =>
            {
                RuleFor(x => x.Details)
                    .Cascade(CascadeMode.Stop)
                    .Required(ValidationMessages.PropertyShouldNotBeNullOrEmptyWhenDependentPropertyIsTrue(
                        nameof(CreateSampleRequest.SomeFlagFieldThatWillRequireDetails)))
                    .SetValidator(new CreateSampleRequestDetailsValidator());
            });
    }
}
