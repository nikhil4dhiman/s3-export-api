using System;
using FluentValidation;

namespace ExportZipManager.Api.Validation;

internal static class ValidationExtensions
{
    private const int DefaultFileNameMaxLength = 1024;
    private const string ParentDirectorySegment = "..";
    private const char UnixDirectorySeparator = '/';
    private const char WindowsDirectorySeparator = '\\';

    extension<TValidated, TProperty>(IRuleBuilder<TValidated, TProperty?> ruleBuilder)
    {
        public IRuleBuilderOptions<TValidated, TProperty> Required(
            string errorMessage = ValidationMessages.PropertyShouldNotBeNullOrEmpty)
        {
            return ruleBuilder
                .NotEmpty()
                .WithMessage(errorMessage)!;
        }
    }

    extension<TValidated>(IRuleBuilder<TValidated, string?> ruleBuilder)
    {
        public IRuleBuilderOptions<TValidated, string?> ValidFileName(int maxLength = DefaultFileNameMaxLength)
        {
            return ruleBuilder
                .Must(fileName => fileName is null || IsValidFileName(fileName))
                .WithMessage(ValidationMessages.FileNameShouldNotContainPathTraversal)
                .MaximumLength(maxLength);
        }
    }

    extension<TValidated>(IRuleBuilder<TValidated, int?> ruleBuilder)
    {
        public IRuleBuilderOptions<TValidated, int?> PositiveWhenProvided()
        {
            return ruleBuilder
                .GreaterThanOrEqualTo(0)
                .WithMessage(ValidationMessages.PropertyShouldBeGreaterThanOrEqualTo)
                .WhenNotNull();
        }

        public IRuleBuilderOptions<TValidated, int?> InclusiveBetweenWhenProvided(int from, int to)
        {
            return ruleBuilder
                .InclusiveBetween(from, to)
                .WithMessage(ValidationMessages.PropertyShouldBeBetweenValues)
                .WhenNotNull();
        }
    }

    extension<TValidated, TProperty>(IRuleBuilderOptions<TValidated, TProperty?> ruleBuilderOptions)
    {
        // This is a recommended way of checking that value is present:
        // https://github.com/FluentValidation/FluentValidation/issues/1688#issuecomment-815990401
        internal IRuleBuilderOptions<TValidated, TProperty?> WhenNotNull()
        {
            return ruleBuilderOptions
                .Configure(configure => configure.ApplyCondition(
                    ctx => configure.GetPropertyValue(ctx.InstanceToValidate) is not null,
                    ApplyConditionTo.CurrentValidator));
        }
    }

    private static bool IsValidFileName(string value)
    {
        return !value.Contains(ParentDirectorySegment, StringComparison.Ordinal)
               && !value.StartsWith(UnixDirectorySeparator)
               && !value.Contains(WindowsDirectorySeparator, StringComparison.Ordinal);
    }
}
