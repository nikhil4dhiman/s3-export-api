namespace ExportZipManager.Api.Constants;

internal static class SizeConstants
{
    public const int BytesPerMegabyte = 1024 * 1024;
}
