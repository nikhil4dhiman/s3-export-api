namespace ExportZipManager.Api.Constants;

internal static class ApiVersions
{
    public const string Version1 = "1.0";
}
