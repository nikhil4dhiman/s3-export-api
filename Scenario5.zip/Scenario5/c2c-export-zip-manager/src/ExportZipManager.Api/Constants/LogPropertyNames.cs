namespace ExportZipManager.Api.Constants;

internal static class LogPropertyNames
{
    public const string UserId = "UserId";

    public const string TraceParent = "TraceParent";
}
