namespace ExportZipManager.Api.Constants;

internal static class KestrelLimitsDefaults
{
    public const int DefaultMaxRequestBodySizeInMegabytes = 30;
}
