namespace ExportZipManager.Api.Constants;

internal static class Routes
{
    public const string Samples = "samples";

    public const string Exports = "exports";

    public const string ExportStart = "start";

    public const string ExportMultipartFileStart = "files/multipart/start";

    public const string ExportMultipartFilePartUpload = "files/multipart/parts/upload";

    public const string ExportMultipartFileComplete = "files/multipart/complete";

    public const string ExportCancel = "cancel";

    public const string ExportFileUpload = "files";

    public const string ExportComplete = "complete";

    public const string ExportStatus = "status";

    public static string ExportStartPath(bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{ExportStart}", prependSlash);
    }

    public static string StartMultipartFilePath(string exportId, bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{exportId}/{ExportMultipartFileStart}", prependSlash);
    }

    public static string UploadMultipartFilePartPath(string exportId, bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{exportId}/{ExportMultipartFilePartUpload}", prependSlash);
    }

    public static string CompleteMultipartFilePath(string exportId, bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{exportId}/{ExportMultipartFileComplete}", prependSlash);
    }

    public static string ExportCancelPath(string exportId, bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{exportId}/{ExportCancel}", prependSlash);
    }

    public static string UploadFilePath(string exportId, bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{exportId}/{ExportFileUpload}", prependSlash);
    }

    public static string ExportCompletePath(string exportId, bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{exportId}/{ExportComplete}", prependSlash);
    }

    public static string ExportStatusPath(string exportId, bool prependSlash = false)
    {
        return BuildPath($"{Exports}/{exportId}/{ExportStatus}", prependSlash);
    }

    public static string GetSamplesPath(bool prependSlash = false)
    {
        return BuildPath(Samples, prependSlash);
    }

    public static string GetSampleByIdPath(string id, bool prependSlash = false)
    {
        return BuildPath($"{Samples}/{id}", prependSlash);
    }

    public static string CreateSamplePath(bool prependSlash = false)
    {
        return BuildPath(Samples, prependSlash);
    }

    private static string BuildPath(string pathBase, bool prependSlash)
    {
        return prependSlash
            ? $"/{pathBase}"
            : pathBase;
    }
}
