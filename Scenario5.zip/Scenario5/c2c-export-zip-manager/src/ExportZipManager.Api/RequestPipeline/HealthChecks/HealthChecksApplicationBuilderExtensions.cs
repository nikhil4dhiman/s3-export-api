using System;
using System.Net.Http;
using ExportZipManager.Core.Api.HealthChecks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace ExportZipManager.Api.RequestPipeline.HealthChecks;

internal static class HealthChecksApplicationBuilderExtensions
{
    extension(IApplicationBuilder app)
    {
        public IApplicationBuilder UseHealthChecksPipeline(int port)
        {
            MapHealthCheckWithSpecifiedConfiguration(
                app,
                HealthCheckConstants.ReadinessRoute,
                port,
                healthCheckRegistration => healthCheckRegistration.Tags.Contains(HealthCheckConstants.ReadinessTag));

            MapHealthCheckWithSpecifiedConfiguration(
                app,
                HealthCheckConstants.LivenessRoute,
                port,
                healthCheckRegistration => healthCheckRegistration.Tags.Contains(HealthCheckConstants.LivenessTag));

            return app;
        }
    }

    private static void MapHealthCheckWithSpecifiedConfiguration(
        IApplicationBuilder app,
        string route,
        int port,
        Func<HealthCheckRegistration, bool> predicate)
    {
        app.MapWhen(
            ctx => ctx.Request.Method == HttpMethod.Get.Method
                   && ctx.Request.Path.StartsWithSegments(route, StringComparison.Ordinal),
            builder => builder.UseHealthChecks(route, port, new HealthCheckOptions { Predicate = predicate })
        );
    }
}
