using ExportZipManager.BackgroundServices.AwsSqs.Configuration;
using ExportZipManager.Core.Api.HealthChecks;
using ExportZipManager.Data.DynamoDb.HealthChecks;
using ExportZipManager.Data.S3.HealthChecks;
using ExportZipManager.Data.SqsPublisher.HealthChecks;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Diagnostics.HealthChecks;
using Microsoft.Extensions.Options;
using Prometheus;

namespace ExportZipManager.Api.RequestPipeline.HealthChecks;

internal static class HealthChecksServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddApplicationHealthChecks()
        {
            services
                .AddHealthChecks()
                .AddApiHealthCheck()
                .AddAmazonS3BucketHealthCheck(HealthCheckConstants.ReadinessTag)
                .AddAmazonSqsProcessingHealthCheck(HealthCheckConstants.ReadinessTag)
                .AddAmazonSqsPublisherHealthCheck(HealthCheckConstants.ReadinessTag)
                .AddAmazonDynamoDbHealthCheck(HealthCheckConstants.ReadinessTag)
                .ForwardToPrometheus();

            return services;
        }
    }

    extension(IHealthChecksBuilder healthChecksBuilder)
    {
        internal IHealthChecksBuilder AddApiHealthCheck()
        {
            return healthChecksBuilder.AddCheck(
                "Application is alive",
                () => HealthCheckResult.Healthy("Application is alive"),
                [HealthCheckConstants.LivenessTag]);
        }

        internal IHealthChecksBuilder AddAmazonSqsProcessingHealthCheck(params string[] tags)
        {
            return healthChecksBuilder.AddAmazonSqsHealthCheck(
                "SQS queue is available for processing",
                sp => sp.GetRequiredService<IOptions<EventsProcessingOptions>>().Value.QueueUrl,
                tags);
        }
    }
}
