using System;
using System.Net.Http;
using Microsoft.AspNetCore.Builder;
using Prometheus;

namespace ExportZipManager.Api.RequestPipeline.Metrics;

internal static class MetricsApplicationBuilderExtensions
{
    private const string MetricsRoute = "/metrics";

    extension(IApplicationBuilder app)
    {
        public IApplicationBuilder UseMetricsPipeline(int port)
        {
            app.MapWhen(
                ctx => ctx.Request.Method == HttpMethod.Get.Method
                       && ctx.Request.Path.StartsWithSegments(MetricsRoute, StringComparison.Ordinal)
                       && ctx.Connection.LocalPort == port,
                builder =>
                {
                    builder.UseRouting();
                    builder.UseEndpoints(endpoints => endpoints.MapMetrics());
                }
            );

            return app;
        }
    }
}
