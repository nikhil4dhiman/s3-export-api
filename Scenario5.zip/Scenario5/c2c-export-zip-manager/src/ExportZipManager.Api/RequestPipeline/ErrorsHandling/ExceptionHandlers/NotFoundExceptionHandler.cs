using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ErrorsHandling.AspNetCore.Handlers;
using ExportZipManager.Domain.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.Api.RequestPipeline.ErrorsHandling.ExceptionHandlers;

internal sealed class NotFoundExceptionHandler : ApplicationExceptionHandler<NotFoundException>
{
    private readonly ILogger<NotFoundExceptionHandler> _logger;

    public NotFoundExceptionHandler(
        IProblemDetailsService problemDetailsService,
        ILogger<NotFoundExceptionHandler> logger)
        : base(problemDetailsService)
    {
        _logger = logger;
    }

    protected override int ResponseStatusCode => StatusCodes.Status404NotFound;

    protected override Task<ProblemDetails> HandleExceptionAsync(
        HttpContext httpContext,
        NotFoundException exception,
        CancellationToken cancellationToken)
    {
        _logger.LogNotFoundError(exception.Id, exception.ModelName);

        var problemDetails = new ProblemDetails
        {
            Type = ServerErrorCodes.NotFoundError,
            Title = ErrorMessages.NotFoundError
        };

        return Task.FromResult(problemDetails);
    }
}
