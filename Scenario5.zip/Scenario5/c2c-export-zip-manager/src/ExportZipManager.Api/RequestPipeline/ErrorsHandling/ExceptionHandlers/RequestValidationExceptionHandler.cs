using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ErrorsHandling.AspNetCore.Handlers;
using ExportZipManager.Core.Api.Validation;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.Api.RequestPipeline.ErrorsHandling.ExceptionHandlers;

internal sealed class RequestValidationExceptionHandler : ApplicationExceptionHandler<RequestValidationException>
{
    private readonly ILogger<RequestValidationExceptionHandler> _logger;

    public RequestValidationExceptionHandler(
        IProblemDetailsService problemDetailsService,
        ILogger<RequestValidationExceptionHandler> logger)
        : base(problemDetailsService)
    {
        _logger = logger;
    }

    protected override int ResponseStatusCode => StatusCodes.Status422UnprocessableEntity;

    protected override Task<ProblemDetails> HandleExceptionAsync(
        HttpContext httpContext,
        RequestValidationException exception,
        CancellationToken cancellationToken)
    {
        _logger.LogValidationError(exception.ValidationErrors);

        var problemDetails = new ValidationProblemDetails(exception.ValidationErrors)
        {
            Type = ServerErrorCodes.ValidationError,
            Title = ErrorMessages.ValidationError
        };

        return Task.FromResult<ProblemDetails>(problemDetails);
    }
}
