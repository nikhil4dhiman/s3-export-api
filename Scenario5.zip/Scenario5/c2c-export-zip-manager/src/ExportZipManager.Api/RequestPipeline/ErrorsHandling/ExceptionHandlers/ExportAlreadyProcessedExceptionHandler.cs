using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ErrorsHandling.AspNetCore.Handlers;
using ExportZipManager.Domain.Exceptions;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.Api.RequestPipeline.ErrorsHandling.ExceptionHandlers;

internal sealed class ExportAlreadyProcessedExceptionHandler : ApplicationExceptionHandler<ExportAlreadyProcessedException>
{
    private readonly ILogger<ExportAlreadyProcessedExceptionHandler> _logger;

    public ExportAlreadyProcessedExceptionHandler(
        IProblemDetailsService problemDetailsService,
        ILogger<ExportAlreadyProcessedExceptionHandler> logger)
        : base(problemDetailsService)
    {
        _logger = logger;
    }

    protected override int ResponseStatusCode => StatusCodes.Status409Conflict;

    protected override Task<ProblemDetails> HandleExceptionAsync(
        HttpContext httpContext,
        ExportAlreadyProcessedException exception,
        CancellationToken cancellationToken)
    {
        _logger.LogExportAlreadyProcessedError(exception.ExportId, exception.Status.ToString());

        var problemDetails = new ProblemDetails
        {
            Type = ServerErrorCodes.ExportAlreadyProcessedError,
            Title = ErrorMessages.ExportAlreadyProcessedError
        };

        return Task.FromResult(problemDetails);
    }
}
