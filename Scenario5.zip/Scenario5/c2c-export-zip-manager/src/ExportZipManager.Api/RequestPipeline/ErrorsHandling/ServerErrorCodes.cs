namespace ExportZipManager.Api.RequestPipeline.ErrorsHandling;

internal static class ServerErrorCodes
{
    public const string UnhandledError = "DT001";
    public const string NotFoundError = "DT002";
    public const string ValidationError = "DT003";
    public const string ExportAlreadyProcessedError = "DT004";
}
