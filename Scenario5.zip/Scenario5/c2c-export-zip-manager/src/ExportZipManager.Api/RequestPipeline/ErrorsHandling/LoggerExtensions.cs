using System.Collections.Generic;
using ExportZipManager.Api.RequestPipeline.ErrorsHandling.ExceptionHandlers;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.Api.RequestPipeline.ErrorsHandling;

internal static partial class LoggerExtensions
{
    [LoggerMessage(
        Level = LogLevel.Debug,
        Message = "Request did not pass validation. Errors={Errors}")]
    public static partial void LogValidationError(
        this ILogger<RequestValidationExceptionHandler> logger,
        IDictionary<string, string[]> errors);

    [LoggerMessage(
        Level = LogLevel.Debug,
        Message = "Resource was not found. Id={ModelId} ModelName={ModelName}")]
    public static partial void LogNotFoundError(
        this ILogger<NotFoundExceptionHandler> logger,
        string modelId,
        string modelName);

    [LoggerMessage(
        Level = LogLevel.Debug,
        Message = "Export was already processed. ExportId={ExportId} Status={Status}")]
    public static partial void LogExportAlreadyProcessedError(
        this ILogger<ExportAlreadyProcessedExceptionHandler> logger,
        string exportId,
        string status);

}

