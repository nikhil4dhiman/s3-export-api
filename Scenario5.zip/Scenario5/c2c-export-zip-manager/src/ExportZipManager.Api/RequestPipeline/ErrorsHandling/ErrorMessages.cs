namespace ExportZipManager.Api.RequestPipeline.ErrorsHandling;

internal static class ErrorMessages
{
    public const string UnhandledError = "An unexpected error has occurred.";

    public const string ValidationError = "Request did not pass validation.";

    public const string NotFoundError = "Resource was not found.";

    public const string ExportAlreadyProcessedError = "Export was already processed.";

}
