using System;

namespace ExportZipManager.Api.RequestPipeline.Tracing;

internal class TracingOptions
{
    public const string SectionName = "Tracing";

    public string ExporterEndpoint { get; init; } = null!;

    public string EnvironmentName { get; init; } = null!;

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(ExporterEndpoint))
        {
            throw new InvalidOperationException($"The '{SectionName}:{nameof(ExporterEndpoint)}' is required.");
        }

        if (string.IsNullOrWhiteSpace(EnvironmentName))
        {
            throw new InvalidOperationException($"The '{SectionName}:{nameof(EnvironmentName)}' is required.");
        }
    }
}
