using System;
using System.Diagnostics;
using System.Net.Http;
using Cove.Platform.Extensions.Communication.Constants.Http;
using Cove.Platform.Extensions.Configuration;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Npgsql;
using OpenTelemetry.Exporter;
using OpenTelemetry.Resources;
using OpenTelemetry.Trace;

namespace ExportZipManager.Api.RequestPipeline.Tracing;

internal static class OpenTelemetryServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddOpenTelemetryTracing(
            IHostEnvironment environment,
            IConfiguration configuration)
        {
            var managementPort = configuration.GetManagementPort();

            var tracingOptions = configuration.GetRequiredSection(TracingOptions.SectionName).Get<TracingOptions>()!;
            tracingOptions.Validate();

            services
                .AddOpenTelemetry()
                .ConfigureResource(resource => resource
                    .AddService(
                        serviceName: environment.ApplicationName,
                        serviceNamespace: "export-zip")
                    .AddAttributes(
                    [
                        new(AttributeKeys.DeploymentEnvironment, tracingOptions.EnvironmentName),
                        new(AttributeKeys.DeploymentEnvironmentName, tracingOptions.EnvironmentName)
                    ]))
                .WithTracing(tracing =>
                {
                    tracing
                        .AddAspNetCoreInstrumentation(options =>
                        {
                            options.Filter = httpContext => FilterIncomingHttpRequests(httpContext, managementPort);

                            options.EnrichWithHttpRequest = EnrichActivityWithHttpRequest;

                            options.EnrichWithHttpResponse = EnrichActivityWithHttpResponse;

                            options.RecordException = true;
                        })
                        .AddHttpClientInstrumentation(options =>
                        {
                            options.EnrichWithHttpRequestMessage = EnrichActivityWithHttpRequestMessage;

                            options.EnrichWithHttpResponseMessage = EnrichActivityWithHttpResponseMessage;

                            options.RecordException = true;
                        })
                        .AddSource("Cove.*")
                        .AddSource("ExportZipManager.*")
                        .AddNpgsql()
                        .SetErrorStatusOnException();

                    tracing.AddOtlpExporter(options =>
                    {
                        options.Endpoint = new Uri(tracingOptions.ExporterEndpoint);
                        options.Protocol = OtlpExportProtocol.Grpc;
                    });

                    if (environment.IsDevelopment())
                    {
                        tracing.AddConsoleExporter();
                    }
                });

            return services;
        }
    }

    private static bool FilterIncomingHttpRequests(HttpContext httpContext, int managementPort)
    {
        // don't instrument management port activities
        return httpContext.Request.Host.Port != managementPort;
    }

    private static void EnrichActivityWithHttpRequest(Activity activity, HttpRequest httpRequest)
    {
        if (httpRequest.Headers.TryGetValue(KnownHttpHeaders.UserId, out var userIdHeader)
            && !string.IsNullOrWhiteSpace(userIdHeader))
        {
            activity.SetTag(AttributeKeys.UserId, userIdHeader.ToString());
        }
    }

    private static void EnrichActivityWithHttpResponse(Activity activity, HttpResponse httpResponse)
    {
        var activityStatus = IsSuccessStatusCode(httpResponse)
            ? ActivityStatusCode.Ok
            : ActivityStatusCode.Error;

        activity.SetStatus(activityStatus);

        static bool IsSuccessStatusCode(HttpResponse httpResponse) => httpResponse.StatusCode is >= 200 and <= 299;
    }

    private static void EnrichActivityWithHttpRequestMessage(
        Activity activity,
        HttpRequestMessage httpRequestMessage)
    {
        activity.DisplayName = $"{httpRequestMessage.Method} {httpRequestMessage.RequestUri?.AbsolutePath}";
    }

    private static void EnrichActivityWithHttpResponseMessage(
        Activity activity,
        HttpResponseMessage httpResponseMessage)
    {
        var activityStatus = httpResponseMessage.IsSuccessStatusCode
            ? ActivityStatusCode.Ok
            : ActivityStatusCode.Error;

        activity.SetStatus(activityStatus);
    }
}
