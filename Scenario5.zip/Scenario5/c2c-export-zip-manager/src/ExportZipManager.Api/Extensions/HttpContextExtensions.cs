using System;
using System.Runtime.CompilerServices;
using ExportZipManager.Api.Validation;
using ExportZipManager.Core.Api.Validation;
using FluentValidation;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Api.Extensions;

internal static class HttpContextExtensions
{
    extension(HttpContext context)
    {
        public void ValidateAndThrowIfNotValid<TValidated>(TValidated model)
        {
            var validator = context.RequestServices.GetRequiredService<IValidator<TValidated>>();
            ValidateAndThrowIfNotValid(validator, model);
        }

        public void ValidateParameterValueAndThrowIfNotValid<TValidated>(
            TValidated parameter,
            [CallerArgumentExpression(nameof(parameter))]
            string parameterName = "")
        {
            var validator = new InlineValidator<TValidated>();
            validator
                .RuleFor(x => x)
                .Required()
                .OverridePropertyName(ToUpperFirstLetter(parameterName));

            ValidateAndThrowIfNotValid(validator, parameter);
        }

        public void ValidateContentLengthAndThrowIfNotValid(long maxSizeBytes)
        {
            var validator = new InlineValidator<HttpRequest>();
            validator
                .RuleFor(x => x.ContentLength)
                .Cascade(CascadeMode.Stop)
                .NotNull()
                .WithMessage(ValidationMessages.PropertyShouldNotBeNullOrEmpty)
                .Must(value => value >= 0 && value <= maxSizeBytes)
                .WithMessage($"{{PropertyName}} should be between 0 and {maxSizeBytes} bytes.");

            ValidateAndThrowIfNotValid(validator, context.Request);
        }
    }

    private static void ValidateAndThrowIfNotValid<TValidated>(
        IValidator<TValidated> validator,
        TValidated model)
    {
        var result = validator.Validate(model);
        if (result.IsValid)
        {
            return;
        }

        throw new RequestValidationException(result.ToDictionary());
    }

    private static string ToUpperFirstLetter(string str)
    {
        if (str.Length == 0 || char.IsUpper(str[0]))
        {
            return str;
        }

        return string.Create(str.Length, str, static (span, source) =>
        {
            source.AsSpan().CopyTo(span);
            span[0] = char.ToUpperInvariant(span[0]);
        });
    }
}
