using System;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Configuration;
using Cove.Platform.Extensions.ErrorsHandling.AspNetCore;
using Cove.Platform.Extensions.Logging.AspNetCore.HeadersLogging;
using Cove.Platform.Extensions.Logging.AspNetCore.LoggingScopes;
using Cove.Platform.Extensions.Logging.AspNetCore.Serilog;
using ExportZipManager.Api.Constants;
using ExportZipManager.Api.EndpointConfiguration;
using ExportZipManager.Api.IoC;
using ExportZipManager.Api.OpenApi;
using ExportZipManager.Api.RequestPipeline.HealthChecks;
using ExportZipManager.Api.RequestPipeline.Metrics;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Server.Kestrel.Core;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Prometheus;
using Serilog;

namespace ExportZipManager.Api;

#pragma warning disable CA1031 // catching a generic exception to write details in log properly and shut down the app

internal sealed class Program
{
    public static async Task Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        if (GenerateOpenApiEntryPoint.ShouldRun(builder))
        {
            await GenerateOpenApiEntryPoint.RunAsync(builder);

            return;
        }

        Log.Logger = SerilogLoggerFactory.Create(builder.Environment);

        var bootstrapLogger = Log.ForContext<Program>();

        try
        {
            bootstrapLogger.Information("Bootstrapping application");

            builder.Host.UseDefaultServiceProvider(options =>
            {
                options.ValidateScopes = true;
                options.ValidateOnBuild = true;
            });

            builder.WebHost.ConfigureKestrel(ConfigureKestrelLimits);

            builder.Services.RegisterApplicationDependencies(builder.Environment, builder.Configuration);
            builder.Host.UseSerilog();

            var app = builder.Build();

            var managementPort = app.Configuration.GetManagementPort();

            app.UseOpenApi(app.Environment);

            app.UseUnhandledErrorHandling(app.Environment)
                .UseHealthChecksPipeline(managementPort)
                .UseMetricsPipeline(managementPort)
                .UseLoggingScope()
                .UseHeadersLogging()
                .UseRouting()
                .UseHttpMetrics()
                .UseSerilogRequestLogging()
                .UseAuthentication()
                .UseAuthorization()
                .UseApplicationErrorHandling();

            app.RegisterEndpoints();

            bootstrapLogger.Information("Starting application");

            await app.RunAsync();
        }
        catch (Exception e)
        {
            bootstrapLogger.Fatal(e, "Application terminated unexpectedly");
        }
        finally
        {
            await Log.CloseAndFlushAsync();
        }
    }

    private static void ConfigureKestrelLimits(WebHostBuilderContext context, KestrelServerOptions options)
    {
        // The default Kestrel MaxRequestBodySize is ~30 MB (30 * 1024 * 1024).
        // Endpoints that accept large payloads override this per-request.
        var maxRequestBodySizeInMegabytes =
            context.Configuration.GetValue<int?>("Kestrel:Limits:MaxRequestBodySizeInMegabytes")
            ?? KestrelLimitsDefaults.DefaultMaxRequestBodySizeInMegabytes;

        options.Limits.MaxRequestBodySize = maxRequestBodySizeInMegabytes * SizeConstants.BytesPerMegabyte;
    }
}
