using System.Collections.Generic;

namespace ExportZipManager.Api.Models.Samples.Responses;

internal class GetSamplesResponse
{
    public IReadOnlyCollection<GetSampleResponse> Items { get; set; } = [];

    public int TotalCount { get; set; }
}
