namespace ExportZipManager.Api.Models.Samples.Responses;

internal class GetSampleResponse
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;
}
