namespace ExportZipManager.Api.Models.Samples.Requests;

internal class CreateSampleRequest
{
    public string? Name { get; set; }

    public bool SomeFlagFieldThatWillRequireDetails { get; set; }

    public CreateSampleRequestDetails? Details { get; set; }
}
