namespace ExportZipManager.Api.Models.Samples.Requests;

internal class GetSamplesRequestQuery
{
    public int? Take { get; set; }

    public int? Skip { get; set; }
}
