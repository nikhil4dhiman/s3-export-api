using Cove.Platform.Extensions.Communication.Constants.Http;
using Microsoft.AspNetCore.Mvc;

namespace ExportZipManager.Api.Models.Samples.Requests;

internal class CreateSampleRequestHeaders
{
    [FromHeader(Name = KnownHttpHeaders.UserId)]
    public string? UserId { get; set; }
}
