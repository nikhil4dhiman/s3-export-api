namespace ExportZipManager.Api.Models.Samples.Requests;

internal class CreateSampleRequestDetails
{
    public string? AdditionalDetails { get; set; }
}
