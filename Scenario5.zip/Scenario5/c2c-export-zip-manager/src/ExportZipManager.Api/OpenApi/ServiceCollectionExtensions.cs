using ExportZipManager.Api.Constants;
using ExportZipManager.Api.OpenApi.Documentation;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.OpenApi;

namespace ExportZipManager.Api.OpenApi;

internal static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddOpenApiServices()
        {
            return services.AddOpenApi(
                ApiVersions.Version1,
                options =>
                {
                    options.OpenApiVersion = OpenApiSpecVersion.OpenApi3_1;

                    options.AddSchemaTransformer<EnumValuesTransformer>();

                    options
                        .AddOperationTransformer<TraceContextHeadersTransformer>();

                    options
                        .AddDocumentTransformer<OpenApiDocumentInfoTransformer>()
                        .AddDocumentTransformer<BasicAuthSecuritySchemeTransformer>();
                });
        }
    }
}
