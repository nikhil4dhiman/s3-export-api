using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Hosting;

namespace ExportZipManager.Api.OpenApi;

internal static class EndpointRouteBuilderExtensions
{
    private const string OpenApiRoute = "/openapi/{documentName}.yaml";

    extension(IEndpointRouteBuilder routes)
    {
        public IEndpointRouteBuilder UseOpenApi(IHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                routes.MapOpenApi(OpenApiRoute);
            }

            return routes;
        }
    }
}
