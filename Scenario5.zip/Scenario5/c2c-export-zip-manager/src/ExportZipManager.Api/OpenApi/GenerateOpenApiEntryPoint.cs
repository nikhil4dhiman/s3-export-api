using System.Text.Json.Serialization;
using System.Threading.Tasks;
using ExportZipManager.Api.IoC;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

namespace ExportZipManager.Api.OpenApi;

internal static class GenerateOpenApiEntryPoint
{
    public static bool ShouldRun(WebApplicationBuilder builder)
    {
        return builder.Configuration.GetValue<bool>("GENERATE_OPENAPI_SPEC");
    }

    public static async Task RunAsync(WebApplicationBuilder builder)
    {
        builder.Host.UseDefaultServiceProvider(options =>
        {
            options.ValidateScopes = false;
            options.ValidateOnBuild = false;
        });

        builder.Services.ConfigureHttpJsonOptions(options =>
        {
            // use strict number handling to ensure numbers appear as numeric types (not strings) in the generated OpenAPI spec
            options.SerializerOptions.NumberHandling = JsonNumberHandling.Strict;
        });

        builder.Services.RegisterApplicationDependencies(builder.Environment, builder.Configuration);

        var app = builder.Build();

        await app.RunAsync();
    }
}
