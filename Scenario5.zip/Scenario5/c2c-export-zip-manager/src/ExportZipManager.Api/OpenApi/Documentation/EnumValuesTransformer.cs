using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace ExportZipManager.Api.OpenApi.Documentation;

internal class EnumValuesTransformer : IOpenApiSchemaTransformer
{
    private const string UnspecifiedValue = "Unspecified";

    public Task TransformAsync(
        OpenApiSchema schema,
        OpenApiSchemaTransformerContext context,
        CancellationToken cancellationToken)
    {
        if (!context.JsonTypeInfo.Type.IsEnum || schema.Enum is null)
        {
            return Task.CompletedTask;
        }

        schema.Enum = [.. schema.Enum.Where(value => value.GetValue<string>() != UnspecifiedValue)];

        return Task.CompletedTask;
    }
}
