using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace ExportZipManager.Api.OpenApi.Documentation;

internal class TraceContextHeadersTransformer : IOpenApiOperationTransformer
{
    public Task TransformAsync(
        OpenApiOperation operation,
        OpenApiOperationTransformerContext context,
        CancellationToken cancellationToken)
    {
        var traceParentParameter = new OpenApiParameter
        {
            Name = "traceparent",
            In = ParameterLocation.Header,
            Description = "W3C Trace Context header.",
            Schema = new OpenApiSchema
            {
                Type = JsonSchemaType.String
            },
            Example = "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01"
        };

        var traceStateParameter = new OpenApiParameter
        {
            Name = "tracestate",
            In = ParameterLocation.Header,
            Description = "Optional W3C Trace Context vendor-specific state.",
            Schema = new OpenApiSchema
            {
                Type = JsonSchemaType.String
            },
            Example = "rojo=00f067aa0ba902b7,congo=t61rcWkgMzE"
        };

        operation.Parameters ??= [];
        operation.Parameters.Add(traceParentParameter);
        operation.Parameters.Add(traceStateParameter);

        return Task.CompletedTask;
    }
}
