using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Api.Constants;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace ExportZipManager.Api.OpenApi.Documentation;

internal class OpenApiDocumentInfoTransformer : IOpenApiDocumentTransformer
{
    public Task TransformAsync(
        OpenApiDocument document,
        OpenApiDocumentTransformerContext context,
        CancellationToken cancellationToken)
    {
        document.Info.Title = "ExportZipManager.Api";
        document.Info.Description = "OpenApi specification for ExportZipManager.Api.";
        document.Info.Version = ApiVersions.Version1;

        return Task.CompletedTask;
    }
}
