using System.Threading;
using System.Threading.Tasks;
using Microsoft.AspNetCore.OpenApi;
using Microsoft.OpenApi;

namespace ExportZipManager.Api.OpenApi.Documentation;

/// <summary>
/// Adds a Basic Authentication security scheme to the OpenAPI document and applies it globally to all operations,
/// reflecting the <c>BasicAuthentication</c> configured in the application.
/// </summary>
internal class BasicAuthSecuritySchemeTransformer : IOpenApiDocumentTransformer
{
    private const string SchemeName = "basic";

    public Task TransformAsync(
        OpenApiDocument document,
        OpenApiDocumentTransformerContext context,
        CancellationToken cancellationToken)
    {
        var securityScheme = new OpenApiSecurityScheme
        {
            Type = SecuritySchemeType.Http,
            Scheme = SchemeName,
            Description = "Basic authentication using username and password."
        };

        document.AddComponent(SchemeName, securityScheme);

        document.Security ??= [];
        document.Security.Add(new OpenApiSecurityRequirement
        {
            [new OpenApiSecuritySchemeReference(SchemeName, document)] = []
        });

        return Task.CompletedTask;
    }
}
