using System.Diagnostics.CodeAnalysis;
using System.Security.Claims;
using idunno.Authentication.Basic;
using BasicAuthenticationOptions = ExportZipManager.Api.Configuration.BasicAuthenticationOptions;

namespace ExportZipManager.Api.Authentication;

internal class BasicAuthenticationCredentialsValidator
{
    private readonly BasicAuthenticationOptions _options;

    public BasicAuthenticationCredentialsValidator(BasicAuthenticationOptions options)
    {
        _options = options;
    }

    public bool TryValidate(
        string userName,
        string password,
        [NotNullWhen(true)] out ClaimsPrincipal? claimsPrincipal)
    {
        if (userName == _options.UserName && password == _options.Password)
        {
            Claim[] claims = [new(ClaimTypes.NameIdentifier, userName), new(ClaimTypes.Name, userName)];

            claimsPrincipal = new ClaimsPrincipal(
                new ClaimsIdentity(claims, BasicAuthenticationDefaults.AuthenticationScheme));

            return true;
        }

        claimsPrincipal = null;

        return false;
    }
}
