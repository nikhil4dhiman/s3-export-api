using ExportZipManager.Domain.Metrics;
using Prometheus;

namespace ExportZipManager.Api.Metrics;

internal class MetricsService : IMetricsService
{
    private const string ApplicationName = "c2c_export_zip_manager";

    // 1s to ~18h. The Prometheus defaults stop at 10s, which an export rarely finishes within.
    private static readonly double[] DurationBuckets = Histogram.ExponentialBuckets(start: 1, factor: 2, count: 17);

    private readonly Counter _zipGenerationEventsPublishedCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_zip_generation_events_published_total",
        "Number of published zip generation events",
        "result");

    private readonly Counter _zipGenerationResultEventsProcessedCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_zip_generation_result_events_processed_total",
        "Number of processed zip generation result events",
        "result");

    private readonly Counter _exportsStartedCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_exports_started_total",
        "Number of exports started");

    private readonly Counter _exportsCompletedCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_exports_completed_total",
        "Number of exports that reached a terminal result, by outcome",
        "result");

    private readonly Counter _exportsCancelledCounter = Prometheus.Metrics.CreateCounter(
        $"{ApplicationName}_exports_cancelled_total",
        "Number of exports cancelled");

    private readonly Histogram _exportDurationHistogram = Prometheus.Metrics.CreateHistogram(
        $"{ApplicationName}_export_duration_seconds",
        "Total export duration in seconds",
        new HistogramConfiguration { LabelNames = ["result"], Buckets = DurationBuckets });

    private readonly Histogram _exportZipProcessingDurationHistogram = Prometheus.Metrics.CreateHistogram(
        $"{ApplicationName}_export_zip_processing_duration_seconds",
        "Total export zip processing duration in seconds",
        new HistogramConfiguration { LabelNames = ["result"], Buckets = DurationBuckets });

    public void IncreaseNumberOfZipGenerationEventsPublished(string result)
    {
        _zipGenerationEventsPublishedCounter.WithLabels(result).Inc();
    }

    public void IncreaseNumberOfZipGenerationResultEventsProcessed(string result)
    {
        _zipGenerationResultEventsProcessedCounter.WithLabels(result).Inc();
    }

    public void IncreaseNumberOfExportsStarted()
    {
        _exportsStartedCounter.Inc();
    }

    public void IncreaseNumberOfExportsCompleted(string result)
    {
        _exportsCompletedCounter.WithLabels(result).Inc();
    }

    public void IncreaseNumberOfExportsCancelled()
    {
        _exportsCancelledCounter.Inc();
    }

    public void ObserveExportDuration(string result, double durationInSeconds)
    {
        _exportDurationHistogram.WithLabels(result).Observe(durationInSeconds);
    }

    public void ObserveExportZipProcessingDuration(string result, double durationInSeconds)
    {
        _exportZipProcessingDurationHistogram.WithLabels(result).Observe(durationInSeconds);
    }
}
