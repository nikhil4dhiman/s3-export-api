using System;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Communication.Constants.Http;
using Cove.Platform.Extensions.Configuration;
using Cove.Platform.Extensions.ErrorsHandling.AspNetCore;
using Cove.Platform.Extensions.Identifiers;
using Cove.Platform.Extensions.Logging.AspNetCore.HeadersLogging;
using Cove.Platform.Extensions.Logging.AspNetCore.HeadersLogging.Configuration;
using Cove.Platform.Extensions.Logging.AspNetCore.Serilog;
using ExportZipManager.Api.Authentication;
using ExportZipManager.Api.Configuration;
using ExportZipManager.Api.Constants;
using ExportZipManager.Api.EndpointConfiguration;
using ExportZipManager.Api.Metrics;
using ExportZipManager.Api.OpenApi;
using ExportZipManager.Api.RequestPipeline.ErrorsHandling.ExceptionHandlers;
using ExportZipManager.Api.RequestPipeline.HealthChecks;
using ExportZipManager.Api.RequestPipeline.Tracing;
using ExportZipManager.ApplicationServices;
using ExportZipManager.BackgroundServices.AwsSqs;
using ExportZipManager.Core.Api.Versioning;
using ExportZipManager.Data.DynamoDb;
using ExportZipManager.Data.PostgreSql;
using ExportZipManager.Data.S3;
using ExportZipManager.Data.SqsPublisher;
using ExportZipManager.Domain.Metrics;
using FluentValidation;
using idunno.Authentication.Basic;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using BasicAuthenticationOptions = ExportZipManager.Api.Configuration.BasicAuthenticationOptions;

namespace ExportZipManager.Api.IoC;

internal static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection RegisterApplicationDependencies(
            IHostEnvironment environment,
            IConfiguration configuration)
        {
            return services
                .AddSharedServices(environment, configuration)
                .AddApplicationServices()
                .AddDatabaseServices()
                .AddDynamoDbServices()
                .AddS3Services()
                .AddSqsServices()
                .AddSqsEventsProcessingPipeline()
                .AddApiServices(environment)
                .AddApplicationHealthChecks();
        }

        private IServiceCollection AddSharedServices(
            IHostEnvironment environment,
            IConfiguration configuration)
        {
            return services
                .AddOpenTelemetryTracing(environment, configuration)
                .AddIdGenerator()
                .AddSingleton<IMetricsService, MetricsService>()
                .AddSingleton(TimeProvider.System);
        }

        private IServiceCollection AddApiServices(IHostEnvironment environment)
        {
            services.AddValidatorsFromAssemblyContaining<Program>(includeInternalTypes: true);

            services.AddVersioningServices();

            services.AddHttpContextAccessor();

            services.AddEndpointsApiExplorer();
            services.AddEndpointsRegistrarsFromAssemblyContaining(typeof(ServiceCollectionExtensions));

            services.AddOpenApiServices();

            services.AddCustomizedProblemDetails();

            services.Configure<RouteOptions>(options => options.LowercaseUrls = true);
            services.ConfigureOptions<DefaultRequestLoggingOptionsConfigurator>();
            services.Configure<HeadersLoggingOptions>(options =>
            {
                options.Headers.Add(new LogHeader(KnownHttpHeaders.UserId, LogPropertyNames.UserId));
                options.Headers.Add(new LogHeader(KnownHttpHeaders.TraceParent, LogPropertyNames.TraceParent));
            });

            services.AddOptionsAndValidate<PagingOptions>();
            services.AddOptionsAndValidate<ExportUploadOptions>();

            services.AddApplicationExceptionHandlers();

            services.AddAuthentication(environment).AddAuthorization();

            return services;
        }

        private IServiceCollection AddApplicationExceptionHandlers()
        {
            return services
                .AddApplicationExceptionHandler<NotFoundExceptionHandler>()
                .AddApplicationExceptionHandler<ExportAlreadyProcessedExceptionHandler>()
                .AddApplicationExceptionHandler<RequestValidationExceptionHandler>();
        }

        private IServiceCollection AddAuthentication(IHostEnvironment environment)
        {
            services
                .AddOptionsAndValidate<BasicAuthenticationOptions>()
                .AddSingleton<BasicAuthenticationCredentialsValidator>();

            services.AddAuthentication(BasicAuthenticationDefaults.AuthenticationScheme)
                .AddBasic(options =>
                {
                    options.Realm = environment.ApplicationName;
                    options.AllowInsecureProtocol = true;
                    options.SuppressWWWAuthenticateHeader = true;
                    options.Events = new BasicAuthenticationEvents
                    {
                        OnValidateCredentials = context =>
                        {
                            var credentialsValidator = context.HttpContext.RequestServices
                                .GetRequiredService<BasicAuthenticationCredentialsValidator>();
                            if (credentialsValidator.TryValidate(
                                    context.Username,
                                    context.Password,
                                    out var principal))
                            {
                                context.Principal = principal;
                                context.Success();
                            }

                            return Task.CompletedTask;
                        }
                    };
                });

            return services;
        }
    }
}
