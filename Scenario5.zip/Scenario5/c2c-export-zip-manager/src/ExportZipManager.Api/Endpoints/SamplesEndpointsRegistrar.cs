using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Logging;
using ExportZipManager.Api.Configuration;
using ExportZipManager.Api.Constants;
using ExportZipManager.Api.EndpointConfiguration;
using ExportZipManager.Api.Extensions;
using ExportZipManager.Api.Mapping;
using ExportZipManager.Api.Models.Samples.Requests;
using ExportZipManager.Api.Models.Samples.Responses;
using ExportZipManager.ApplicationServices.Samples;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace ExportZipManager.Api.Endpoints;

internal class SamplesEndpointsRegistrar : IEndpointsGroupRegistrar
{
    private const string GetSampleByIdEndpointName = "GetSampleById";

    public PathString GroupName { get; } = new($"/{Routes.Samples}");

    public void RegisterEndpoints(RouteGroupBuilder builder)
    {
        builder.WithTags("Samples");

        builder.MapGet("/", GetSamplesAsync)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapGet("/{id}", GetSampleByIdAsync)
            .WithName(GetSampleByIdEndpointName)
            .ProducesProblem(StatusCodes.Status404NotFound)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapPost("/", CreateSampleAsync)
            .Produces<CreateSampleResponse>(StatusCodes.Status201Created)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);
    }

    private async Task<Ok<GetSamplesResponse>> GetSamplesAsync(
        [AsParameters] GetSamplesRequestQuery query,
        HttpContext httpContext,
        SamplesService samplesService,
        PagingOptions pagingOptions,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(query);

        var skip = query.Skip ?? 0;
        var take = query.Take ?? pagingOptions.DefaultPageSize;

        var samplesPage = await samplesService.GetSamplesPageAsync(skip, take, cancellationToken);
        var response = samplesPage.ToResponseModel();

        return TypedResults.Ok(response);
    }

    private async Task<Ok<GetSampleResponse>> GetSampleByIdAsync(
        string id,
        HttpContext httpContext,
        SamplesService samplesService,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateParameterValueAndThrowIfNotValid(id);

        var sample = await samplesService.GetSampleByIdAsync(id, cancellationToken);
        var response = sample.ToResponseModel();

        return TypedResults.Ok(response);
    }

    private async Task<CreatedAtRoute<CreateSampleResponse>> CreateSampleAsync(
        [AsParameters] CreateSampleRequestHeaders requestHeaders,
        CreateSampleRequest request,
        HttpContext httpContext,
        SamplesService samplesService,
        ILoggingScopeAccessor loggingScopeAccessor,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(requestHeaders);
        httpContext.ValidateAndThrowIfNotValid(request);

        EnrichLoggingScope(request, loggingScopeAccessor);

        var sampleToCreate = request.ToDomainModel();

        var createdSample = await samplesService.CreateSampleAsync(sampleToCreate, cancellationToken);
        var response = createdSample.ToCreateSampleResponse();

        return TypedResults.CreatedAtRoute(
            response,
            GetSampleByIdEndpointName,
            new { id = createdSample.Id });
    }

    private static void EnrichLoggingScope(CreateSampleRequest request, ILoggingScopeAccessor loggingScopeAccessor)
    {
        loggingScopeAccessor.LoggingScope!
            .Set(nameof(request.Name), request.Name!);
    }
}
