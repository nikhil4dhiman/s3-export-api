using System.Collections.Generic;

namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class CompleteMultipartFileRequest
{
    public string? FileName { get; init; }

    public string? UploadId { get; init; }

    public IReadOnlyCollection<CompleteMultipartFileRequestPart>? Parts { get; init; }
}
