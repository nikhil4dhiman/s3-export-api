namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class StartExportRequest
{
    public string? BackupId { get; init; }

    public string? SessionId { get; init; }

    public string? RunId { get; init; }

    public string? SourceId { get; init; }
}
