namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class UploadMultipartFilePartRequestQuery
{
    public string? FileName { get; set; }

    public string? UploadId { get; set; }

    public int? PartNumber { get; set; }
}
