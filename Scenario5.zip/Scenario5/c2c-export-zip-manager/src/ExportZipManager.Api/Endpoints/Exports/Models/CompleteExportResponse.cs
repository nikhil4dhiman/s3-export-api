namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class CompleteExportResponse
{
    public required string ExportId { get; init; }
}
