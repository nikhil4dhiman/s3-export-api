namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class UploadFileRequestQuery
{
    public string? FileName { get; set; }
}
