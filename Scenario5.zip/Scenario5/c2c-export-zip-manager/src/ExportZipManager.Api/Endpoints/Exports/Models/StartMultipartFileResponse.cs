namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class StartMultipartFileResponse
{
    public required string UploadId { get; init; }
}
