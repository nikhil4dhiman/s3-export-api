namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class GetExportStatusResponse
{
    public required string Status { get; init; }

    public string? FileId { get; init; }
}
