namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class UploadMultipartFilePartResponse
{
    public required string ETag { get; init; }
}
