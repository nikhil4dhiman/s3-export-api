using Cove.Platform.Extensions.Communication.Constants.Http;
using Microsoft.AspNetCore.Mvc;

namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class CompleteExportRequestHeaders
{
    [FromHeader(Name = KnownHttpHeaders.PartnerId)]
    public string? PartnerId { get; set; }
}
