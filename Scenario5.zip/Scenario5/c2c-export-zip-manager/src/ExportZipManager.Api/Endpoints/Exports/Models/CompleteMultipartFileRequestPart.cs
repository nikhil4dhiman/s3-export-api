namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class CompleteMultipartFileRequestPart
{
    public int? PartNumber { get; init; }

    public string? ETag { get; init; }
}
