using Microsoft.AspNetCore.Mvc;

namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class ExportRequestPath
{
    [FromRoute]
    public string? ExportId { get; set; }
}
