namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class StartExportResponse
{
    public required string ExportId { get; init; }
}
