using System.Text.Json.Serialization;
using ExportZipManager.Domain.Models.Exports;

namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class CompleteExportRequest
{
    public string? SourceName { get; init; }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public SourceType? SourceType { get; init; }
}
