namespace ExportZipManager.Api.Endpoints.Exports.Models;

internal class StartMultipartFileRequest
{
    public string? FileName { get; init; }
}
