using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class CompleteMultipartFileRequestPartValidator : AbstractValidator<CompleteMultipartFileRequestPart>
{
    private const int MinPartNumber = 1;
    private const int MaxPartNumber = 10000;

    public CompleteMultipartFileRequestPartValidator()
    {
        RuleFor(x => x.PartNumber)
            .Cascade(CascadeMode.Stop)
            .Required()
            .InclusiveBetweenWhenProvided(MinPartNumber, MaxPartNumber);

        RuleFor(x => x.ETag)
            .Required();
    }
}
