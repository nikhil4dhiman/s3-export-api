using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class UploadMultipartFilePartRequestQueryValidator : AbstractValidator<UploadMultipartFilePartRequestQuery>
{
    private const int MinPartNumber = 1;
    private const int MaxPartNumber = 10000;

    public UploadMultipartFilePartRequestQueryValidator()
    {
        RuleFor(x => x.FileName)
            .Cascade(CascadeMode.Stop)
            .Required()
            .ValidFileName();

        RuleFor(x => x.UploadId)
            .Required();

        RuleFor(x => x.PartNumber)
            .Cascade(CascadeMode.Stop)
            .Required()
            .InclusiveBetweenWhenProvided(MinPartNumber, MaxPartNumber);
    }
}
