using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class StartFileRequestValidator : AbstractValidator<StartMultipartFileRequest>
{
    public StartFileRequestValidator()
    {
        RuleFor(x => x.FileName)
            .Cascade(CascadeMode.Stop)
            .Required()
            .ValidFileName();
    }
}
