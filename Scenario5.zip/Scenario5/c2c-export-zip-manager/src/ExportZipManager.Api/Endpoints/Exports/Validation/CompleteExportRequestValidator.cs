using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class CompleteExportRequestValidator : AbstractValidator<CompleteExportRequest>
{
    private const int SourceNameMaxLength = 256;

    public CompleteExportRequestValidator()
    {
        RuleFor(x => x.SourceName)
            .Cascade(CascadeMode.Stop)
            .Required()
            .MaximumLength(SourceNameMaxLength);

        RuleFor(x => x.SourceType)
            .Cascade(CascadeMode.Stop)
            .NotNull()
            .WithMessage(ValidationMessages.PropertyShouldNotBeNullOrEmpty)
            .IsInEnum()
            .WithMessage(ValidationMessages.PropertyShouldBeAKnownValue);
    }
}
