using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class UploadFileRequestQueryValidator : AbstractValidator<UploadFileRequestQuery>
{
    public UploadFileRequestQueryValidator()
    {
        RuleFor(x => x.FileName)
            .Cascade(CascadeMode.Stop)
            .Required()
            .ValidFileName();
    }
}
