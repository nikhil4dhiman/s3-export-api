using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class CompleteMultipartFileRequestValidator : AbstractValidator<CompleteMultipartFileRequest>
{
    public CompleteMultipartFileRequestValidator()
    {
        RuleFor(x => x.FileName)
            .Cascade(CascadeMode.Stop)
            .Required()
            .ValidFileName();

        RuleFor(x => x.UploadId)
            .Required();

        RuleFor(x => x.Parts)
            .Required();

        RuleForEach(x => x.Parts)
            .SetValidator(new CompleteMultipartFileRequestPartValidator());
    }
}
