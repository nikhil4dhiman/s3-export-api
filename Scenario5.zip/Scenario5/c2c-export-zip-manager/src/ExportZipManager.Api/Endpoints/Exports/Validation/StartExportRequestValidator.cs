using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class StartExportRequestValidator : AbstractValidator<StartExportRequest>
{
    public StartExportRequestValidator()
    {
        RuleFor(x => x.BackupId)
            .Required();

        RuleFor(x => x.SessionId)
            .Required();

        RuleFor(x => x.RunId)
            .Required();

        RuleFor(x => x.SourceId)
            .Required();
    }
}
