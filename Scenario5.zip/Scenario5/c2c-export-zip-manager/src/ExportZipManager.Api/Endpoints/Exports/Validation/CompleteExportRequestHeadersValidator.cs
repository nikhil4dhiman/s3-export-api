using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class CompleteExportRequestHeadersValidator : AbstractValidator<CompleteExportRequestHeaders>
{
    public CompleteExportRequestHeadersValidator()
    {
        RuleFor(x => x.PartnerId)
            .Required();
    }
}
