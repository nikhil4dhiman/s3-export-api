using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Validation;
using FluentValidation;

namespace ExportZipManager.Api.Endpoints.Exports.Validation;

internal class ExportRequestPathValidator : AbstractValidator<ExportRequestPath>
{
    public ExportRequestPathValidator()
    {
        RuleFor(x => x.ExportId)
            .Required();
    }
}
