using System.IO;
using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Logging;
using ExportZipManager.Api.Configuration;
using ExportZipManager.Api.Constants;
using ExportZipManager.Api.EndpointConfiguration;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Api.Extensions;
using ExportZipManager.ApplicationServices.Exports;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;
using Microsoft.AspNetCore.WebUtilities;

namespace ExportZipManager.Api.Endpoints.Exports;

internal class ExportsEndpointsRegistrar : IEndpointsGroupRegistrar
{
    public PathString GroupName { get; } = new($"/{Routes.Exports}");

    public void RegisterEndpoints(RouteGroupBuilder builder)
    {
        builder.WithTags("Exports");

        builder.MapPost($"/{Routes.ExportStart}", StartExportAsync)
            .Produces<StartExportResponse>()
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapPost($"/{{exportId}}/{Routes.ExportMultipartFileStart}", StartMultipartFileAsync)
            .Produces<StartMultipartFileResponse>()
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapPost($"/{{exportId}}/{Routes.ExportMultipartFilePartUpload}", UploadMultipartFilePartAsync)
            .Produces<UploadMultipartFilePartResponse>()
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapPost($"/{{exportId}}/{Routes.ExportMultipartFileComplete}", CompleteMultipartFileAsync)
            .Produces(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapPost($"/{{exportId}}/{Routes.ExportCancel}", CancelExportAsync)
            .Produces(StatusCodes.Status204NoContent)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapPost($"/{{exportId}}/{Routes.ExportFileUpload}", UploadFileAsync)
            .Produces(StatusCodes.Status200OK)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapPost($"/{{exportId}}/{Routes.ExportComplete}", CompleteExportAsync)
            .Produces<CompleteExportResponse>(StatusCodes.Status202Accepted)
            .ProducesProblem(StatusCodes.Status409Conflict)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);

        builder.MapGet($"/{{exportId}}/{Routes.ExportStatus}", GetExportStatusAsync)
            .Produces<GetExportStatusResponse>()
            .ProducesProblem(StatusCodes.Status404NotFound)
            .ProducesProblem(StatusCodes.Status422UnprocessableEntity);
    }

    private async Task<Ok<StartExportResponse>> StartExportAsync(
        StartExportRequest request,
        HttpContext httpContext,
        ExportsService exportsService,
        ILoggingScopeAccessor loggingScopeAccessor,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(request);

        EnrichLoggingScope(request, loggingScopeAccessor);

        var exportId = await exportsService.StartExportAsync(request.ToDomainModel(), cancellationToken);

        return TypedResults.Ok(new StartExportResponse { ExportId = exportId });
    }

    private async Task<Ok<StartMultipartFileResponse>> StartMultipartFileAsync(
        [AsParameters] ExportRequestPath path,
        StartMultipartFileRequest request,
        HttpContext httpContext,
        ExportsService exportsService,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(path);
        httpContext.ValidateAndThrowIfNotValid(request);

        var uploadId = await exportsService.StartMultipartFileAsync(
            path.ExportId!,
            request.FileName!,
            cancellationToken);

        var response = new StartMultipartFileResponse { UploadId = uploadId };

        return TypedResults.Ok(response);
    }

    private async Task<Ok<UploadMultipartFilePartResponse>> UploadMultipartFilePartAsync(
        [AsParameters] ExportRequestPath path,
        [AsParameters] UploadMultipartFilePartRequestQuery query,
        HttpContext httpContext,
        ExportsService exportsService,
        ExportUploadOptions exportUploadOptions,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(path);
        httpContext.ValidateAndThrowIfNotValid(query);

        var contentLength = httpContext.Request.ContentLength.GetValueOrDefault();
        httpContext.ValidateContentLengthAndThrowIfNotValid(exportUploadOptions.MaxPartSizeInBytes);

        await using var body = new FileBufferingReadStream(
            httpContext.Request.Body,
            exportUploadOptions.MemoryBufferThresholdInBytes,
            bufferLimit: exportUploadOptions.MaxPartSizeInBytes,
            tempFileDirectoryAccessor: () => exportUploadOptions.TempFileDirectory);

        await body.DrainAsync(cancellationToken);
        body.Seek(0, SeekOrigin.Begin);

        var part = query.ToDomainModel(path.ExportId!, body, contentLength);

        var eTag = await exportsService.UploadMultipartFilePartAsync(part, cancellationToken);

        var response = new UploadMultipartFilePartResponse { ETag = eTag };

        return TypedResults.Ok(response);
    }

    private async Task<Ok> CompleteMultipartFileAsync(
        [AsParameters] ExportRequestPath path,
        CompleteMultipartFileRequest request,
        HttpContext httpContext,
        ExportsService exportsService,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(path);
        httpContext.ValidateAndThrowIfNotValid(request);

        var completionDetails = request.ToDomainModel(path.ExportId!);

        await exportsService.CompleteMultipartFileAsync(completionDetails, cancellationToken);

        return TypedResults.Ok();
    }

    private async Task<NoContent> CancelExportAsync(
        [AsParameters] ExportRequestPath path,
        HttpContext httpContext,
        ExportsService exportsService,
        ILoggingScopeAccessor loggingScopeAccessor,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(path);

        loggingScopeAccessor.LoggingScope!.Set("ExportId", path.ExportId!);

        await exportsService.CancelExportAsync(path.ExportId!, cancellationToken);

        return TypedResults.NoContent();
    }

    private async Task<Ok> UploadFileAsync(
        [AsParameters] ExportRequestPath path,
        [AsParameters] UploadFileRequestQuery query,
        HttpContext httpContext,
        ExportsService exportsService,
        ExportUploadOptions exportUploadOptions,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(path);
        httpContext.ValidateAndThrowIfNotValid(query);

        httpContext.ValidateContentLengthAndThrowIfNotValid(exportUploadOptions.MaxFileSizeInBytes);

        await using var body = new FileBufferingReadStream(
            httpContext.Request.Body,
            exportUploadOptions.MemoryBufferThresholdInBytes,
            bufferLimit: exportUploadOptions.MaxFileSizeInBytes,
            tempFileDirectoryAccessor: () => exportUploadOptions.TempFileDirectory);

        await body.DrainAsync(cancellationToken);
        body.Seek(0, SeekOrigin.Begin);

        var fileDetails = query.ToDomainModel(path.ExportId!, body);

        await exportsService.UploadFileAsync(fileDetails, cancellationToken);

        return TypedResults.Ok();
    }

    private async Task<Accepted<CompleteExportResponse>> CompleteExportAsync(
        [AsParameters] ExportRequestPath path,
        [AsParameters] CompleteExportRequestHeaders headers,
        CompleteExportRequest request,
        HttpContext httpContext,
        ExportsService exportsService,
        ILoggingScopeAccessor loggingScopeAccessor,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(path);
        httpContext.ValidateAndThrowIfNotValid(headers);
        httpContext.ValidateAndThrowIfNotValid(request);

        EnrichLoggingScope(path, headers, request, loggingScopeAccessor);

        await exportsService.CompleteExportAsync(
            path.ExportId!,
            headers.PartnerId!,
            request.SourceName!,
            request.SourceType!.Value,
            cancellationToken);

        return TypedResults.Accepted((string?)null, new CompleteExportResponse { ExportId = path.ExportId! });
    }

    private async Task<Ok<GetExportStatusResponse>> GetExportStatusAsync(
        [AsParameters] ExportRequestPath path,
        HttpContext httpContext,
        ExportsService exportsService,
        ILoggingScopeAccessor loggingScopeAccessor,
        CancellationToken cancellationToken)
    {
        httpContext.ValidateAndThrowIfNotValid(path);

        loggingScopeAccessor.LoggingScope!.Set(nameof(path.ExportId), path.ExportId!);

        var exportStatus = await exportsService.GetExportStatusAsync(path.ExportId!, cancellationToken);

        return TypedResults.Ok(exportStatus.ToResponse());
    }

    private static void EnrichLoggingScope(StartExportRequest request, ILoggingScopeAccessor loggingScopeAccessor)
    {
        loggingScopeAccessor.LoggingScope!
            .Set(nameof(request.BackupId), request.BackupId!)
            .Set(nameof(request.SessionId), request.SessionId!)
            .Set(nameof(request.RunId), request.RunId!)
            .Set(nameof(request.SourceId), request.SourceId!);
    }

    private static void EnrichLoggingScope(
        ExportRequestPath path,
        CompleteExportRequestHeaders headers,
        CompleteExportRequest request,
        ILoggingScopeAccessor loggingScopeAccessor)
    {
        loggingScopeAccessor.LoggingScope!
            .Set(nameof(path.ExportId), path.ExportId!)
            .Set(nameof(headers.PartnerId), headers.PartnerId!)
            .Set(nameof(request.SourceType), request.SourceType!.ToString()!);
    }
}
