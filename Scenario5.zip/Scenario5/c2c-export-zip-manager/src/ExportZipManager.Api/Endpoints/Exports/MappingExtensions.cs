using System.IO;
using ExportZipManager.Api.Endpoints.Exports.Models;
using ExportZipManager.Domain.Models.Exports;
using Riok.Mapperly.Abstractions;

namespace ExportZipManager.Api.Endpoints.Exports;

[Mapper(RequiredMappingStrategy = RequiredMappingStrategy.Target)]
internal static partial class MappingExtensions
{
    internal static partial ExportInfo ToDomainModel(this StartExportRequest startExportRequest);

    internal static partial MultipartFilePartDetails ToDomainModel(
        this UploadMultipartFilePartRequestQuery query,
        string exportId,
        Stream data,
        long dataSize);

    internal static partial FileDetails ToDomainModel(
        this UploadFileRequestQuery query,
        string exportId,
        Stream data);

    internal static partial MultipartFileCompletionDetails ToDomainModel(
        this CompleteMultipartFileRequest request,
        string exportId);

    internal static partial GetExportStatusResponse ToResponse(
        this ExportRecord exportRecord);

    private static partial CompletedFilePart ToDomainModel(this CompleteMultipartFileRequestPart part);
}
