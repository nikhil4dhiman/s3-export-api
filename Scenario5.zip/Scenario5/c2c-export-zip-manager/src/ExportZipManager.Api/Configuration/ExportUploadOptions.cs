using System.ComponentModel.DataAnnotations;
using ExportZipManager.Api.Constants;

namespace ExportZipManager.Api.Configuration;

internal class ExportUploadOptions
{
    [Required]
    public required string TempFileDirectory { get; init; }

    [Range(1, 1000)]
    public required int MemoryBufferThresholdInMegabytes { get; init; }

    [Range(1, 1000)]
    public required int MaxPartSizeInMegabytes { get; init; }

    [Range(1, 1000)]
    public required int MaxFileSizeInMegabytes { get; init; }

    public int MemoryBufferThresholdInBytes => MemoryBufferThresholdInMegabytes * SizeConstants.BytesPerMegabyte;

    public long MaxPartSizeInBytes => MaxPartSizeInMegabytes * SizeConstants.BytesPerMegabyte;

    public long MaxFileSizeInBytes => MaxFileSizeInMegabytes * SizeConstants.BytesPerMegabyte;
}
