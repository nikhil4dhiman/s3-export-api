using System.ComponentModel.DataAnnotations;

namespace ExportZipManager.Api.Configuration;

internal class PagingOptions
{
    [Range(1, int.MaxValue)]
    public int DefaultPageSize { get; set; }

    [Range(1, int.MaxValue)]
    public int MaxPageSize { get; set; }
}
