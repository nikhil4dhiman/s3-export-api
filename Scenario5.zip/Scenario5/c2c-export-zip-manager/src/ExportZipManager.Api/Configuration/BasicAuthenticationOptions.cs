using System.ComponentModel.DataAnnotations;

namespace ExportZipManager.Api.Configuration;

internal class BasicAuthenticationOptions
{
    [Required]
    public required string UserName { get; set; }

    [Required]
    public required string Password { get; set; }
}
