using ExportZipManager.Api.Models.Samples.Requests;
using ExportZipManager.Api.Models.Samples.Responses;
using ExportZipManager.Domain.Models;
using ExportZipManager.Domain.Models.Paging;
using Riok.Mapperly.Abstractions;

namespace ExportZipManager.Api.Mapping;

[Mapper(RequiredMappingStrategy = RequiredMappingStrategy.Target)]
internal static partial class MapperExtensions
{
    [MapperIgnoreTarget(nameof(Sample.Id))]
    public static partial Sample ToDomainModel(this CreateSampleRequest source);

    public static partial GetSampleResponse ToResponseModel(this Sample source);

    public static partial CreateSampleResponse ToCreateSampleResponse(this Sample source);

    public static partial GetSamplesResponse ToResponseModel(this Page<Sample> source);
}
