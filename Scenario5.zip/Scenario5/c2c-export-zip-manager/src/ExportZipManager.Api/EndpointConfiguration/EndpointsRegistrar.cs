using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Api.EndpointConfiguration;

internal class EndpointsRegistrar
{
    private readonly IEnumerable<IEndpointsGroupRegistrar> _registrars;
    private readonly IServiceProvider _serviceProvider;

    public EndpointsRegistrar(
        IEnumerable<IEndpointsGroupRegistrar> registrars,
        IServiceProvider serviceProvider)
    {
        _registrars = registrars;
        _serviceProvider = serviceProvider;
    }

    public void RegisterEndpoints(WebApplication app)
    {
        foreach (var registrar in _registrars)
        {
            var endpointsGroup = app
                .MapGroup(registrar.GroupName)
                .RequireAuthorization();

            registrar.RegisterEndpoints(endpointsGroup);

            var childRegistrars = _serviceProvider.GetKeyedServices<IEndpointsGroupRegistrar>(registrar.GetType());

            foreach (var childRegistrar in childRegistrars)
            {
                var childGroup = endpointsGroup.MapGroup(childRegistrar.GroupName);
                childRegistrar.RegisterEndpoints(childGroup);
            }
        }
    }
}
