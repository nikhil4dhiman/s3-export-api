using System;

namespace ExportZipManager.Api.EndpointConfiguration;

[AttributeUsage(AttributeTargets.Class)]
internal abstract class ParentRegistrarAttribute : Attribute
{
    protected ParentRegistrarAttribute(Type parentRegistrarType)
    {
        ParentRegistrarType = parentRegistrarType;
    }

    public Type ParentRegistrarType { get; }
}
