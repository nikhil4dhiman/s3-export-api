using System;

namespace ExportZipManager.Api.EndpointConfiguration;

[AttributeUsage(AttributeTargets.Class)]
internal sealed class ParentRegistrarAttribute<TRegistrar> : ParentRegistrarAttribute
{
    public ParentRegistrarAttribute()
        : base(typeof(TRegistrar))
    {
    }
}
