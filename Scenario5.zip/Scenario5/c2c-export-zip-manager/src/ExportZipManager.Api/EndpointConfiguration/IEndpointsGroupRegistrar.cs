using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;

namespace ExportZipManager.Api.EndpointConfiguration;

internal interface IEndpointsGroupRegistrar
{
    PathString GroupName { get; }

    void RegisterEndpoints(RouteGroupBuilder builder);
}
