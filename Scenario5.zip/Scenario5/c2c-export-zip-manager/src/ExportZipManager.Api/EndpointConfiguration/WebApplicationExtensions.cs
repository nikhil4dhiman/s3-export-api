using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Api.EndpointConfiguration;

internal static class WebApplicationExtensions
{
    extension(WebApplication application)
    {
        public WebApplication RegisterEndpoints()
        {
            var registrar = application.Services.GetRequiredService<EndpointsRegistrar>();
            registrar.RegisterEndpoints(application);

            return application;
        }
    }
}
