using System;
using System.Linq;
using System.Reflection;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.Api.EndpointConfiguration;

internal static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddEndpointsRegistrarsFromAssemblyContaining(Type type)
        {
            services.AddSingleton<EndpointsRegistrar>();

            var endpointRegistrars = type.Assembly
                .GetTypes()
                .Where(x => x.IsAssignableTo(typeof(IEndpointsGroupRegistrar)));

            foreach (var endpointRegistrar in endpointRegistrars)
            {
                var parentRegistrarAttribute = endpointRegistrar.GetCustomAttribute<ParentRegistrarAttribute>();

                if (parentRegistrarAttribute is not null)
                {
                    services.AddKeyedSingleton(
                        typeof(IEndpointsGroupRegistrar),
                        parentRegistrarAttribute.ParentRegistrarType,
                        endpointRegistrar);
                }
                else if (!endpointRegistrar.IsInterface)
                {
                    services.AddSingleton(typeof(IEndpointsGroupRegistrar), endpointRegistrar);
                }
            }

            return services;
        }
    }
}
