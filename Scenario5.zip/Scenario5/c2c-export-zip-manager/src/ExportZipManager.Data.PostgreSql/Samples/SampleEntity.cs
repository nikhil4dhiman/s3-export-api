using System;

namespace ExportZipManager.Data.PostgreSql.Samples;

internal class SampleEntity
{
    public string Id { get; set; } = null!;

    public string Name { get; set; } = null!;

    public DateTime CreatedAtUtc { get; set; }
}
