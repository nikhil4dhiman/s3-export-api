using System;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.Identifiers.DataGeneration;
using ExportZipManager.Data.PostgreSql.Mapping;
using ExportZipManager.Domain.Exceptions;
using ExportZipManager.Domain.Models;
using ExportZipManager.Domain.Models.Paging;
using ExportZipManager.Domain.Repositories;
using Microsoft.EntityFrameworkCore;

namespace ExportZipManager.Data.PostgreSql.Samples;

internal class SamplesRepository : ISamplesRepository
{
    private readonly ExportZipManagerDbContext _dbContext;
    private readonly IIdGenerator _idGenerator;
    private readonly TimeProvider _timeProvider;

    public SamplesRepository(
        ExportZipManagerDbContext dbContext,
        IIdGenerator idGenerator,
        TimeProvider timeProvider)
    {
        _dbContext = dbContext;
        _idGenerator = idGenerator;
        _timeProvider = timeProvider;

        // TODO: do not use in production, this is only for demo purposes.
        dbContext.Database.EnsureCreated();
    }

    public async Task<Page<Sample>> GetSamplesPageAsync(int skip, int take, CancellationToken cancellationToken)
    {
        var entities = await _dbContext.Samples
            .OrderBy(x => x.Name)
            .Skip(skip)
            .Take(take)
            .ToArrayAsync(cancellationToken);

        var totalCount = await _dbContext.Samples.CountAsync(cancellationToken);

        var samples = entities.ToDomainModels();

        return new Page<Sample>(samples, totalCount);
    }

    public async Task<Sample> GetSampleByIdAsync(string id, CancellationToken cancellationToken)
    {
        var entity = await _dbContext.Samples.SingleOrDefaultAsync(x => x.Id == id, cancellationToken);
        if (entity is null)
        {
            throw new NotFoundException(nameof(Sample), id);
        }

        return entity.ToDomainModel();
    }

    public async Task<Sample> CreateSampleAsync(Sample sample, CancellationToken cancellationToken)
    {
        var entity = sample.ToEntityModel();

        entity.Id = _idGenerator.GenerateOrderedId();
        entity.CreatedAtUtc = _timeProvider.GetUtcNow().UtcDateTime;

        await _dbContext.Samples.AddAsync(entity, cancellationToken);
        await _dbContext.SaveChangesAsync(cancellationToken);

        return entity.ToDomainModel();
    }
}
