using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace ExportZipManager.Data.PostgreSql.Samples;

internal class SampleEntityTypeConfiguration : IEntityTypeConfiguration<SampleEntity>
{
    public void Configure(EntityTypeBuilder<SampleEntity> builder)
    {
        builder.ToTable("sample");

        builder.HasKey(x => x.Id);

        builder
            .Property(x => x.Name)
            .IsRequired();

        builder
            .Property(x => x.CreatedAtUtc)
            .IsRequired()
            .HasConversion(to => to, from => DateTime.SpecifyKind(from, DateTimeKind.Utc));
    }
}
