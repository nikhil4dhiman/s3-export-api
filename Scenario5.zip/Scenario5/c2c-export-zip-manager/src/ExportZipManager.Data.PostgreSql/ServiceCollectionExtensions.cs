using Cove.Platform.Extensions.Configuration;
using EntityFramework.Exceptions.PostgreSQL;
using ExportZipManager.Data.PostgreSql.Configuration;
using ExportZipManager.Data.PostgreSql.Samples;
using ExportZipManager.Data.PostgreSql.Tracing;
using ExportZipManager.Domain.Repositories;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using Npgsql;

namespace ExportZipManager.Data.PostgreSql;

public static class ServiceCollectionExtensions
{
    extension(IServiceCollection services)
    {
        public IServiceCollection AddDatabaseServices()
        {
            return services
                .AddOptionsAndValidate<DatabaseOptions>()
                .AddSingleton(sp =>
                {
                    var databaseOptions = sp.GetRequiredService<DatabaseOptions>();

                    return new NpgsqlConnectionStringBuilder
                    {
                        Host = databaseOptions.Host,
                        Username = databaseOptions.UserName,
                        Password = databaseOptions.Password,
                        Database = databaseOptions.DatabaseName,
                        Port = databaseOptions.Port
                    };
                })
                .AddDbContext<ExportZipManagerDbContext>((sp, options) =>
                {
                    options.UseQueryTrackingBehavior(QueryTrackingBehavior.NoTracking);

                    var databaseOptions = sp.GetRequiredService<DatabaseOptions>();
                    var connectionStringBuilder = sp.GetRequiredService<NpgsqlConnectionStringBuilder>();

                    options
                        .UseNpgsql(
                            connectionStringBuilder.ConnectionString,
                            builder => builder
                                .EnableRetryOnFailure()
                                .CommandTimeout(databaseOptions.CommandTimeoutInSeconds))
                        .UseExceptionProcessor()
                        .UseSnakeCaseNamingConvention();
                })
                .AddScoped<ISamplesRepository, SamplesRepository>()
                .Decorate<ISamplesRepository, TracingSamplesRepository>();
        }
    }
}
