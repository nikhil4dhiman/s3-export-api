using System.Threading;
using System.Threading.Tasks;
using ExportZipManager.Domain.Models.Paging;
using ExportZipManager.Domain.Repositories;
using Sample = ExportZipManager.Domain.Models.Sample;

namespace ExportZipManager.Data.PostgreSql.Tracing;

internal class TracingSamplesRepository : ISamplesRepository
{
    private readonly ISamplesRepository _inner;

    public TracingSamplesRepository(ISamplesRepository inner)
    {
        _inner = inner;
    }

    public async Task<Page<Sample>> GetSamplesPageAsync(int skip, int take, CancellationToken cancellationToken)
    {
        using var _ = Tracer.ActivitySource.StartActivity("get samples page");

        return await _inner.GetSamplesPageAsync(skip, take, cancellationToken);
    }

    public async Task<Sample> GetSampleByIdAsync(string id, CancellationToken cancellationToken)
    {
        using var _ = Tracer.ActivitySource.StartActivity("get sample by id");

        return await _inner.GetSampleByIdAsync(id, cancellationToken);
    }

    public async Task<Sample> CreateSampleAsync(Sample sample, CancellationToken cancellationToken)
    {
        using var _ = Tracer.ActivitySource.StartActivity("create sample");

        return await _inner.CreateSampleAsync(sample, cancellationToken);
    }
}
