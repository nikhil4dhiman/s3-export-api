using System.Diagnostics;

namespace ExportZipManager.Data.PostgreSql.Tracing;

internal static class Tracer
{
    public static readonly ActivitySource ActivitySource = new("ExportZipManager.Data.PostgreSql");
}
