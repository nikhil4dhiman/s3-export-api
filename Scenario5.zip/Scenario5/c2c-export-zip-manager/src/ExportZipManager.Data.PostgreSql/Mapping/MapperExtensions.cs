using System.Collections.Generic;
using System.Linq;
using ExportZipManager.Data.PostgreSql.Samples;
using ExportZipManager.Domain.Models;
using Riok.Mapperly.Abstractions;

namespace ExportZipManager.Data.PostgreSql.Mapping;

[Mapper(RequiredMappingStrategy = RequiredMappingStrategy.Target)]
internal static partial class MapperExtensions
{
    [MapperIgnoreTarget(nameof(SampleEntity.CreatedAtUtc))]
    public static partial SampleEntity ToEntityModel(this Sample source);

    public static IReadOnlyCollection<SampleEntity> ToEntityModels(this IEnumerable<Sample> sources)
    {
        return [.. sources.Select(ToEntityModel)];
    }

    [MapperIgnoreTarget(nameof(Sample.Details))]
    public static partial Sample ToDomainModel(this SampleEntity source);

    public static IReadOnlyCollection<Sample> ToDomainModels(this IEnumerable<SampleEntity> sources)
    {
        return [.. sources.Select(ToDomainModel)];
    }
}
