using ExportZipManager.Data.PostgreSql.Samples;
using Microsoft.EntityFrameworkCore;

namespace ExportZipManager.Data.PostgreSql;

internal class ExportZipManagerDbContext : DbContext
{
    public DbSet<SampleEntity> Samples { get; init; } = null!;

    public ExportZipManagerDbContext(DbContextOptions<ExportZipManagerDbContext> options)
        : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfigurationsFromAssembly(typeof(ExportZipManagerDbContext).Assembly);

        base.OnModelCreating(modelBuilder);
    }
}
