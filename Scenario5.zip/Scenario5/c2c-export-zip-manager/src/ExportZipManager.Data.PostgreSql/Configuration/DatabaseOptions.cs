using System.ComponentModel.DataAnnotations;

namespace ExportZipManager.Data.PostgreSql.Configuration;

public class DatabaseOptions
{
    [Required]
    public string Host { get; init; } = null!;

    [Required]
    public int Port { get; init; }

    [Required]
    public string UserName { get; init; } = null!;

    [Required]
    public string Password { get; init; } = null!;

    [Required]
    public string DatabaseName { get; init; } = null!;

    [Range(1, 600)]
    public int CommandTimeoutInSeconds { get; init; }
}
