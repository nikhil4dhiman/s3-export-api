using System;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling.Results;
using Cove.Platform.Extensions.ProcessingPipeline.EventsHandling.CloudEvents;
using ExportZipManager.ApplicationServices.ExportResults;
using ExportZipManager.BackgroundServices.AwsSqs.Constants;
using ExportZipManager.BackgroundServices.AwsSqs.Exceptions;
using ExportZipManager.BackgroundServices.AwsSqs.Logging;
using ExportZipManager.BackgroundServices.AwsSqs.Models;
using ExportZipManager.Domain.Exceptions;
using ExportZipManager.Domain.Metrics;
using ExportZipManager.Domain.Models.Exports;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.BackgroundServices.AwsSqs.EventHandlers;

#pragma warning disable CA1711 // reserved naming of EventHandler is used here for better readability

internal class ZipGenerationResultEventHandler : ITypedCloudEventHandler<ZipGenerationResultEventPayload>
{
    private readonly IMetricsService _metricsService;
    private readonly ExportResultsService _exportResultsService;
    private readonly TimeProvider _timeProvider;
    private readonly ILogger<ZipGenerationResultEventHandler> _logger;

    public ZipGenerationResultEventHandler(
        IMetricsService metricsService,
        ExportResultsService exportResultsService,
        TimeProvider timeProvider,
        ILogger<ZipGenerationResultEventHandler> logger)
    {
        _metricsService = metricsService;
        _exportResultsService = exportResultsService;
        _timeProvider = timeProvider;
        _logger = logger;
    }

    public async Task HandleAsync(
        CloudEventContext<ZipGenerationResultEventPayload> context,
        CancellationToken cancellationToken)
    {
        try
        {
            var exportStatus = MapToExportStatus(context.Payload.State);

            string? fileId = null;
            if (context.Payload.State == ExportResultState.Completed)
            {
                fileId = GetRequiredFileId(context.Payload.ResultDetails);
            }

            // Read before updating: distinguishes a genuine completion from a redelivery of an
            // already-terminal export, and carries the timestamps the export duration is measured
            // from. It cannot alone rule out a concurrent cancellation racing this update -- the
            // update's own boolean result is checked below for that.
            var existingExportInfo = await _exportResultsService.GetExportInfoAsync(
                context.Payload.Id,
                cancellationToken);

            var completedAt = _timeProvider.GetUtcNow();

            var isUpdated = await _exportResultsService.UpdateExportStatusAsync(
                context.Payload.Id,
                exportStatus,
                fileId,
                completedAt,
                cancellationToken);

            if (isUpdated && existingExportInfo?.Status == ExportStatus.InProgress)
            {
                var result = exportStatus == ExportStatus.Completed
                    ? MetricLabelValues.Result.Completed
                    : MetricLabelValues.Result.Failed;

                _metricsService.IncreaseNumberOfExportsCompleted(result);

                ObserveExportDurations(existingExportInfo, completedAt, result);
            }

            _metricsService.IncreaseNumberOfZipGenerationResultEventsProcessed(MetricLabelValues.Result.Processed);

            context.ProcessingContext.SetProcessingResult(SuccessResult.Create());
        }
        catch (Exception e) when (e is NotFoundException or InvalidEventPayloadException)
        {
            _logger.LogZipGenerationResultEventHandlingError(context.Payload, e);

            _metricsService.IncreaseNumberOfZipGenerationResultEventsProcessed(MetricLabelValues.Result.Discarded);

            context.ProcessingContext.SetProcessingResult(DiscardEventResult.Create(e.Message));
        }
        catch (Exception e) when (e is not OperationCanceledException)
        {
            _logger.LogZipGenerationResultEventHandlingError(context.Payload, e);

            _metricsService.IncreaseNumberOfZipGenerationResultEventsProcessed(MetricLabelValues.Result.Failed);

            context.ProcessingContext.SetProcessingResult(SendEventToDlqResult.Create(e.Message));
        }
    }

    private static ExportStatus MapToExportStatus(ExportResultState state)
    {
        return state switch
        {
            ExportResultState.Completed => ExportStatus.Completed,
            ExportResultState.Failed => ExportStatus.Failed,
            _ => throw new InvalidEventPayloadException($"Unsupported export result state '{state}'.")
        };
    }

    private static string GetRequiredFileId(JsonNode? resultDetails)
    {
        var fileId = resultDetails is JsonObject details
            ? details[ResultDetailsPropertiesNames.FileId]?.ToString()
            : null;

        if (string.IsNullOrEmpty(fileId))
        {
            throw new InvalidEventPayloadException(
                $"Completed zip generation result event does not contain '{ResultDetailsPropertiesNames.FileId}' in the result details.");
        }

        return fileId;
    }

    // An export predating ZipRequestedAt being captured has none to measure from, and clocks that
    // disagree between the api and the worker can put the end before either start. Both would
    // otherwise contribute meaningless observations to the histograms.
    private void ObserveExportDurations(ExportRecord export, DateTimeOffset completedAt, string result)
    {
        if (completedAt >= export.StartedAt)
        {
            _metricsService.ObserveExportDuration(result, (completedAt - export.StartedAt).TotalSeconds);
        }

        if (export.ZipRequestedAt is { } zipRequestedAt && completedAt >= zipRequestedAt)
        {
            _metricsService.ObserveExportZipProcessingDuration(
                result,
                (completedAt - zipRequestedAt).TotalSeconds);
        }
    }
}
