using System;
using System.ComponentModel.DataAnnotations;

namespace ExportZipManager.BackgroundServices.AwsSqs.Configuration;

public class EventsProcessingOptions
{
    [Required]
    public required string QueueUrl { get; init; }

    [Required]
    public required string DeadLetterQueueUrl { get; init; }

    [Required]
    [Range(1, 10)]
    public required int MaxNumberOfMessages { get; init; }

    [Required]
    public required TimeSpan MessageProcessingTimeout { get; init; }
}
