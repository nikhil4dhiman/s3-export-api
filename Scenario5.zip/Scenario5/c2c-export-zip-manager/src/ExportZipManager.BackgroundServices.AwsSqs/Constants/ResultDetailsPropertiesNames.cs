namespace ExportZipManager.BackgroundServices.AwsSqs.Constants;

internal static class ResultDetailsPropertiesNames
{
    public const string FileId = "fileId";
}
