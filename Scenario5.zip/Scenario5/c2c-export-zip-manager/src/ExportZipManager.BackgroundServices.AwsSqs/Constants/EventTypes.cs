namespace ExportZipManager.BackgroundServices.AwsSqs.Constants;

internal static class EventTypes
{
    public const string ZipGenerationResult = "com.n-able.cove.events.c2c.export.zip.generation.result";
}
