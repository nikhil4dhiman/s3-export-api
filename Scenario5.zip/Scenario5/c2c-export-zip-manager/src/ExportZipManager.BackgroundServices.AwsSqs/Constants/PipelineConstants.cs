namespace ExportZipManager.BackgroundServices.AwsSqs.Constants;

internal static class PipelineConstants
{
    public const string EventsProcessingPipeline = "SqsEventsProcessingPipeline";
}
