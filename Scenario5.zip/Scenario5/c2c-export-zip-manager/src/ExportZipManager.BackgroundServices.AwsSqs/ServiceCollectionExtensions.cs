using System.Threading.Tasks;
using Cove.Platform.Extensions.Configuration;
using Cove.Platform.Extensions.ProcessingPipeline;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ProcessingStrategies;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling;
using Cove.Platform.Extensions.ProcessingPipeline.AmazonSqs.ResultHandling.Results;
using Cove.Platform.Extensions.ProcessingPipeline.EventsHandling.CloudEvents;
using ExportZipManager.BackgroundServices.AwsSqs.Configuration;
using ExportZipManager.BackgroundServices.AwsSqs.Constants;
using ExportZipManager.BackgroundServices.AwsSqs.EventHandlers;
using ExportZipManager.BackgroundServices.AwsSqs.Models;
using Microsoft.Extensions.DependencyInjection;

namespace ExportZipManager.BackgroundServices.AwsSqs;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddSqsEventsProcessingPipeline(this IServiceCollection services)
    {
        services
            .AddOptionsAndValidate<EventsProcessingOptions>()
            .AddProcessingPipelineServices(PipelineConstants.EventsProcessingPipeline)
            .AddAmazonSqs((options, sp) =>
            {
                var amazonOptions = sp.GetRequiredService<EventsProcessingOptions>();

                options.QueueUrl = amazonOptions.QueueUrl;
                options.DeadLetterQueueUrl = amazonOptions.DeadLetterQueueUrl;
                options.MaxNumberOfMessages = amazonOptions.MaxNumberOfMessages;
                options.MessageProcessingTimeout = amazonOptions.MessageProcessingTimeout;
                options.MessageIsForwardedFromAmazonSns = false;
                options.EventsProcessingStrategy = ParallelEventsProcessingStrategy.Instance;
            })
            .ConfigurePipeline(builder => builder
                .UseDefaultPipelineMiddlewares()
                .UseCloudEventHandling(mapping => mapping
                        .HandleEvent<ZipGenerationResultEventPayload>(
                            EventTypes.ZipGenerationResult,
                            pipeline => pipeline.HandleUsing<ZipGenerationResultEventHandler>())
                        .DiscardUnmappedEventTypes(ctx =>
                        {
                            ctx.ProcessingContext.SetProcessingResult(
                                DiscardEventResult.Create("EventTypeHandlerIsNotMapped"));

                            return Task.CompletedTask;
                        }),
                    options => options.UseDefaultAmazonSqsEventParser()));

        return services;
    }
}
