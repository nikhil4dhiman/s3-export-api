using System;
using System.Collections.Generic;
using ExportZipManager.BackgroundServices.AwsSqs.EventHandlers;
using ExportZipManager.BackgroundServices.AwsSqs.Models;
using Microsoft.Extensions.Logging;

namespace ExportZipManager.BackgroundServices.AwsSqs.Logging;

internal static partial class LoggerExtensions
{
    public const string ZipGenerationResultEventHandlingErrorMessage =
        "Unexpected error occurred while handling zip generation result event";

    public static void LogZipGenerationResultEventHandlingError(
        this ILogger<ZipGenerationResultEventHandler> logger,
        ZipGenerationResultEventPayload payload,
        Exception exception)
    {
        var scope = new Dictionary<string, object?>
        {
            [nameof(ZipGenerationResultEventPayload)] =
                new Dictionary<string, object?>
                {
                    [nameof(ZipGenerationResultEventPayload.Id)] = payload.Id,
                    [nameof(ZipGenerationResultEventPayload.State)] = payload.State,
                    [nameof(ZipGenerationResultEventPayload.ResultDetails)] = payload.ResultDetails?.ToJsonString()
                }
        };

        using var _ = logger.BeginScope(scope);

        logger.LogZipGenerationResultEventHandlingError(exception);
    }

    [LoggerMessage(
        Level = LogLevel.Error,
        Message = ZipGenerationResultEventHandlingErrorMessage)]
    private static partial void LogZipGenerationResultEventHandlingError(
        this ILogger<ZipGenerationResultEventHandler> logger,
        Exception exception);
}
