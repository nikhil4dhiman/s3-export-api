namespace ExportZipManager.BackgroundServices.AwsSqs.Models;

internal enum ExportResultState
{
    Unspecified,
    Completed,
    Failed
}
