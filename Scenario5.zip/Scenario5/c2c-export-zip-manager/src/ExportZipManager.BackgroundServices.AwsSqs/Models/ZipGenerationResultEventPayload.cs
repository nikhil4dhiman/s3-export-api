using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using ExportZipManager.Core.Api.Serialization;

namespace ExportZipManager.BackgroundServices.AwsSqs.Models;

internal class ZipGenerationResultEventPayload
{
    public required string Id { get; init; }

    [JsonConverter(typeof(JsonStringEnumConverter))]
    public required ExportResultState State { get; init; }

    [JsonConverter(typeof(StringToJsonNodeConverter))]
    public required JsonNode? ResultDetails { get; init; }
}
