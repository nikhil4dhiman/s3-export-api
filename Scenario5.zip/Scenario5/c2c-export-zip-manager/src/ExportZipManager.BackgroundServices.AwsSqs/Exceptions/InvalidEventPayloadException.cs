using System;

namespace ExportZipManager.BackgroundServices.AwsSqs.Exceptions;

/// <summary>
/// Indicates that an event payload is semantically invalid (poison message)
/// and must be discarded instead of being retried or sent to the dead letter queue.
/// </summary>
public class InvalidEventPayloadException : Exception
{
    public InvalidEventPayloadException(string message)
        : base(message)
    {
    }
}
