### Description

<!-- Short description of changes that were made -->

Jira-Ref: BST-XXXXX: <!-- Jira title -->

### Checklist before requesting a review
- [ ] I provided Jira-Ref
- [ ] I have performed a self-review of my code
- [ ] I tested my changes on the DEV environment (if applicable)
- [ ] I covered the changes with tests (if applicable)
- [ ] I updated the docs (if applicable)
