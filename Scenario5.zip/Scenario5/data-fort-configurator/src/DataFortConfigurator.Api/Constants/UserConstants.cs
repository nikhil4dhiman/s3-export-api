namespace DataFortConfigurator.Api.Constants;

internal static class UserConstants
{
    internal static class RoleNames
    {
        public const string SuperUser = "SuperUser";
    }

    internal static class PartnerIds
    {
        public const string Root = "1";
    }
}
