namespace DataFortConfigurator.Api.Constants;

internal static class RequestValuesConstants
{
    // 1 MB
    public const int MaxRequestBodySizeInBytes = 1 * 1024 * 1024;

    // 30 days
    public const long GracePeriodSecondsMax = 60 * 60 * 24 * 30;
}
