namespace DataFortConfigurator.Api.Constants;

internal static class SerializationConstants
{
    public const int MaxDepth = 8;
}
