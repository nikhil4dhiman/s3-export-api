namespace DataFortConfigurator.Api.Constants;

internal static class LogPropertyNames
{
    public const string UserId = "UserId";

    public const string TraceId = "X-Trace";
}
