using System;

namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class LockRepositoryResponse
{
    public required DateTime LockedToWriteAtUtc { get; init; }

    public required DateTime LockedToWriteUntilUtc { get; init; }
}
