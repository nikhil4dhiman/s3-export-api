namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class DeleteRepositoryRequest
{
    public string? RepositoryId { get; init; }
}
