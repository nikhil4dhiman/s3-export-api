namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class LockRepositoryRequest
{
    public string? RepositoryId { get; init; }
}
