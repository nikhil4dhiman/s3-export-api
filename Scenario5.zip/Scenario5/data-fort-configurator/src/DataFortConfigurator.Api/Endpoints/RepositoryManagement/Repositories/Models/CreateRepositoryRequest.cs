using System.Collections.Generic;

namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class CreateRepositoryRequest
{
    public string? Name { get; set; }

    public string? StorageClientName { get; set; }

    public string? KeyManagementMode { get; init; }

    public string? WriteKey { get; init; }

    public int? PartnerId { get; init; }

    public long? GracePeriodSeconds { get; init; }

    public IReadOnlyCollection<RepositoryRequestStorageItem>? Storages { get; set; }
}
