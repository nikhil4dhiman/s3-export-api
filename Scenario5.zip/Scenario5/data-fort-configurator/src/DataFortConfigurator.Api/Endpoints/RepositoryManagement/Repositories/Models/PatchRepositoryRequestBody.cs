using System.Collections.Generic;

namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class PatchRepositoryRequestBody
{
    public string? Name { get; set; }

    public IReadOnlyCollection<RepositoryRequestStorageItem>? Storages { get; set; }
}
