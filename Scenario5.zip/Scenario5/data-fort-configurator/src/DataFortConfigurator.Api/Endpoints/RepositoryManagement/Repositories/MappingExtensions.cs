using System;
using System.Collections.Generic;
using System.Linq;
using DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;
using DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Validation;
using DataFortConfigurator.Domain.Models.Repositories;
using Riok.Mapperly.Abstractions;

namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories;

[Mapper(RequiredMappingStrategy = RequiredMappingStrategy.Target)]
internal static partial class MappingExtensions
{
    [MapperIgnoreTarget(nameof(Repository.Id))]
    [MapperIgnoreTarget(nameof(Repository.KeyBundleId))]
    [MapperIgnoreTarget(nameof(Repository.LockedToWriteAtUtc))]
    [MapperIgnoreTarget(nameof(Repository.LockedToWriteUntilUtc))]
    [MapProperty(
        nameof(CreateRepositoryRequest.Storages),
        nameof(Repository.RepositoryInstances),
        Use = nameof(MapStoragesToInstances))]
    internal static partial Repository ToDomainModel(this CreateRepositoryRequest createRepositoryRequest);

    internal static RepositoryResponseStorageItem ToResponseModel(this RepositoryInstance model)
    {
        return new RepositoryResponseStorageItem
        {
            StorageId = model.StorageId.ToString(),
            ActualRole = model.ActualRole.ToCamelCaseString(),
            DesiredRole = model.DesiredRole.ToCamelCaseString()
        };
    }

    [MapProperty(nameof(Repository.RepositoryInstances), nameof(RepositoryResponse.Storages))]
    internal static partial RepositoryResponse ToResponseModel(this Repository model);

    internal static partial LockRepositoryResponse ToResponseModel(this RepositoryWriteLock model);

    [MapProperty(
        nameof(PatchRepositoryRequestBody.Storages),
        nameof(RepositoryPatch.RepositoryInstances),
        Use = nameof(MapStoragesToPatches))]
    internal static partial RepositoryPatch ToDomainModel(
        this PatchRepositoryRequestBody patchRepositoryRequest,
        Guid repositoryId);

    private static IReadOnlyCollection<RepositoryInstance> MapStoragesToInstances(
        IReadOnlyCollection<RepositoryRequestStorageItem>? storages)
    {
        return storages?.Select(s => s.ToDomainModel()).ToList() ?? [];
    }

    private static RepositoryInstance ToDomainModel(this RepositoryRequestStorageItem storageItem)
    {
        var instanceRole = storageItem.IsMain == true ? InstanceRole.Main : InstanceRole.Secondary;

        return new RepositoryInstance
        {
            StorageId = Guid.Parse(storageItem.StorageId!),
            ActualRole = instanceRole,
            DesiredRole = instanceRole
        };
    }

    private static IReadOnlyCollection<RepositoryInstancePatch>? MapStoragesToPatches(
        IReadOnlyCollection<RepositoryRequestStorageItem>? storages)
    {
        return storages?.Select(s => s.ToPatchModel()).ToList();
    }

    private static RepositoryInstancePatch ToPatchModel(this RepositoryRequestStorageItem storageItem)
    {
        return new RepositoryInstancePatch
        {
            StorageId = Guid.Parse(storageItem.StorageId!),
            IsMain = storageItem.IsMain == true
        };
    }

    internal static partial RepositoryTopologyPatch ToDomainModel(
        this PatchRepositoryTopologyRequestBody body,
        Guid repositoryId);

    [MapProperty(nameof(PatchRepositoryTopologyStorageEntry.ActualRole),
        nameof(TopologyPatchStorageEntry.ActualRole),
        Use = nameof(MapPatchEntryActualRole))]
    [MapProperty(nameof(PatchRepositoryTopologyStorageEntry.Deleted),
        nameof(TopologyPatchStorageEntry.Deleted),
        Use = nameof(MapNullableBoolean))]
    [MapProperty(nameof(PatchRepositoryTopologyStorageEntry.ShouldRetireCurrentMain),
        nameof(TopologyPatchStorageEntry.ShouldRetireCurrentMain),
        Use = nameof(MapNullableBoolean))]
    private static partial TopologyPatchStorageEntry ToTopologyStorageEntry(PatchRepositoryTopologyStorageEntry entry);

    private static InstanceRole? MapPatchEntryActualRole(string? actualRole)
    {
        if (string.IsNullOrWhiteSpace(actualRole))
        {
            return null;
        }

        return Enum.Parse<InstanceRole>(actualRole, ignoreCase: true);
    }

    private static bool MapNullableBoolean(bool? value)
    {
        return value ?? false;
    }
}
