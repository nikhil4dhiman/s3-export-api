namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class CreateRepositoryResponse
{
    public required string Id { get; init; }
}
