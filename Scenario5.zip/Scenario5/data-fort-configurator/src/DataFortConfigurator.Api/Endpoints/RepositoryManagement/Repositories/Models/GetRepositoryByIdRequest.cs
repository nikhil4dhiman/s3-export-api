namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class GetRepositoryByIdRequest
{
    public string? RepositoryId { get; init; }
}
