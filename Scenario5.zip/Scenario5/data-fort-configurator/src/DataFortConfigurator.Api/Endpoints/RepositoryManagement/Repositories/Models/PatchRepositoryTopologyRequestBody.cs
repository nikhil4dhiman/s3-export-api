using System.Collections.Generic;

namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class PatchRepositoryTopologyRequestBody
{
    public IReadOnlyCollection<PatchRepositoryTopologyStorageEntry>? Storages { get; set; }
}
