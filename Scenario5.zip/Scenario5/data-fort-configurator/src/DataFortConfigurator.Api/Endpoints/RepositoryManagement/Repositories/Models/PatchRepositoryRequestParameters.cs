namespace DataFortConfigurator.Api.Endpoints.RepositoryManagement.Repositories.Models;

internal class PatchRepositoryRequestParameters
{
    public string? RepositoryId { get; init; }
}
