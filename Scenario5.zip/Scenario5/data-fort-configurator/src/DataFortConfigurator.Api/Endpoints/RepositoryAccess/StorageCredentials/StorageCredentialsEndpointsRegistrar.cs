using System;
using System.Collections.Generic;
using System.Text.Json.Nodes;
using System.Threading;
using System.Threading.Tasks;
using DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Models;
using DataFortConfigurator.Api.Validation;
using DataFortConfigurator.ApplicationServices.StorageCredentials;
using DataFortConfigurator.Core.Api.Endpoints;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.Routing;

namespace DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials;

[ParentRegistrar<RepositoryAccessEndpointsRegistrar>]
internal class StorageCredentialsEndpointsRegistrar : IEndpointsGroupRegistrar
{
    public string GroupPath => "/repositories/{repositoryId}/credentials";

    public void RegisterEndpoints(RouteGroupBuilder builder)
    {
        builder
            .MapGet("/", GetAllCredentialsAsync)
            .Produces<IReadOnlyCollection<JsonNode>>()
            .Produces(StatusCodes.Status404NotFound)
            .Produces(StatusCodes.Status422UnprocessableEntity);

        builder
            .MapGet("/main", GetMainCredentialsAsync)
            .Produces<JsonNode>()
            .Produces(StatusCodes.Status404NotFound)
            .Produces(StatusCodes.Status422UnprocessableEntity);

        builder
            .MapGet("/{storageId}", GetCredentialByStorageIdAsync)
            .Produces<JsonNode>()
            .Produces(StatusCodes.Status404NotFound)
            .Produces(StatusCodes.Status422UnprocessableEntity);
    }

    private async Task<Ok<IReadOnlyCollection<JsonNode>>> GetAllCredentialsAsync(
        [AsParameters] GetAllCredentialsRequest request,
        HttpContext context,
        StorageCredentialsService storageCredentialsService,
        CancellationToken cancellationToken)
    {
        context.ValidateAndThrowIfNotValid(request);

        var credentials = await storageCredentialsService.GetAllCredentialsByRepositoryIdAsync(
            Guid.Parse(request.RepositoryId!),
            cancellationToken);

        return TypedResults.Ok(credentials);
    }

    private async Task<Ok<JsonNode>> GetMainCredentialsAsync(
        [AsParameters] GetMainCredentialRequest request,
        HttpContext context,
        StorageCredentialsService storageCredentialsService,
        CancellationToken cancellationToken)
    {
        context.ValidateAndThrowIfNotValid(request);

        var credential = await storageCredentialsService.GetMainCredentialByRepositoryIdAsync(
            Guid.Parse(request.RepositoryId!),
            cancellationToken);

        return TypedResults.Ok(credential);
    }

    private async Task<Ok<JsonNode>> GetCredentialByStorageIdAsync(
        [AsParameters] GetCredentialByStorageIdRequest request,
        HttpContext context,
        StorageCredentialsService storageCredentialsService,
        CancellationToken cancellationToken)
    {
        context.ValidateAndThrowIfNotValid(request);

        var credential = await storageCredentialsService.GetCredentialByRepositoryAndStorageIdAsync(
            Guid.Parse(request.RepositoryId!),
            Guid.Parse(request.StorageId!),
            cancellationToken);

        return TypedResults.Ok(credential);
    }
}
