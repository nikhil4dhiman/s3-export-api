using DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Models;
using DataFortConfigurator.Api.Validation;
using FluentValidation;

namespace DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Validation;

internal class GetCredentialByStorageIdRequestValidator : AbstractValidator<GetCredentialByStorageIdRequest>
{
    public GetCredentialByStorageIdRequestValidator()
    {
        RuleFor(x => x.RepositoryId)
            .Cascade(CascadeMode.Stop)
            .Required()
            .IsGuid();

        RuleFor(x => x.StorageId)
            .Cascade(CascadeMode.Stop)
            .Required()
            .IsGuid();
    }
}
