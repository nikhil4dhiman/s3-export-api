namespace DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Models;

internal class GetMainCredentialRequest
{
    public string? RepositoryId { get; init; }
}
