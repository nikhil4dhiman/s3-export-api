using DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Models;
using DataFortConfigurator.Api.Validation;
using FluentValidation;

namespace DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Validation;

internal class GetMainCredentialRequestValidator : AbstractValidator<GetMainCredentialRequest>
{
    public GetMainCredentialRequestValidator()
    {
        RuleFor(x => x.RepositoryId)
            .Cascade(CascadeMode.Stop)
            .Required()
            .IsGuid();
    }
}
