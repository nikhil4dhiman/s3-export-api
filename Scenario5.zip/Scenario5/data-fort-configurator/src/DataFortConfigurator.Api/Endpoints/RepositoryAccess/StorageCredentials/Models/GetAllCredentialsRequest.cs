namespace DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Models;

internal class GetAllCredentialsRequest
{
    public string? RepositoryId { get; init; }
}
