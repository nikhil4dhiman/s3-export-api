namespace DataFortConfigurator.Api.Endpoints.RepositoryAccess.StorageCredentials.Models;

internal class GetCredentialByStorageIdRequest
{
    public string? RepositoryId { get; init; }

    public string? StorageId { get; init; }
}
