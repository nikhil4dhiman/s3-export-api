using DataFortConfigurator.Core.Api.Endpoints;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Routing;

namespace DataFortConfigurator.Api.Endpoints.RepositoryAccess;

internal class RepositoryAccessEndpointsRegistrar : IEndpointsGroupRegistrar
{
    public string GroupPath => "/repo-access/";

    public void RegisterEndpoints(RouteGroupBuilder builder)
    {
        builder.WithGroupName(GroupPath);
    }
}
