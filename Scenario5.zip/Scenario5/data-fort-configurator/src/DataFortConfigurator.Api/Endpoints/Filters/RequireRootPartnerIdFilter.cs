using System.Threading.Tasks;
using Cove.Platform.Extensions.Communication.Constants.Http;
using DataFortConfigurator.Api.Constants;
using DataFortConfigurator.ApplicationServices.Metrics;
using DataFortConfigurator.Domain.Metrics;
using Microsoft.AspNetCore.Http;

namespace DataFortConfigurator.Api.Endpoints.Filters;

internal class RequireRootPartnerIdFilter : IEndpointFilter
{
    private readonly IMetricsService _metricsService;

    public RequireRootPartnerIdFilter(IMetricsService metricsService)
    {
        _metricsService = metricsService;
    }

    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        if (!context.HttpContext.Request.Headers.TryGetValue(KnownHttpHeaders.PartnerId, out var partnerId))
        {
            _metricsService.IncreaseNumberOfUnauthorizedAdminAccesses(
                MetricLabelValues.UnauthorizedAdminAccessReasons.MissingRootPartnerId);

            return TypedResults.Forbid();
        }

        if (partnerId != UserConstants.PartnerIds.Root)
        {
            _metricsService.IncreaseNumberOfUnauthorizedAdminAccesses(
                MetricLabelValues.UnauthorizedAdminAccessReasons.InvalidPartnerId);

            return TypedResults.Forbid();
        }

        return await next(context);
    }
}
