using System.Threading.Tasks;
using Cove.Platform.Extensions.Communication.Constants.Http;
using DataFortConfigurator.Api.Constants;
using DataFortConfigurator.ApplicationServices.Metrics;
using DataFortConfigurator.Domain.Metrics;
using Microsoft.AspNetCore.Http;

namespace DataFortConfigurator.Api.Endpoints.Filters;

internal class RequireSuperUserRoleFilter : IEndpointFilter
{
    private readonly IMetricsService _metricsService;

    public RequireSuperUserRoleFilter(IMetricsService metricsService)
    {
        _metricsService = metricsService;
    }

    public async ValueTask<object?> InvokeAsync(EndpointFilterInvocationContext context, EndpointFilterDelegate next)
    {
        if (!context.HttpContext.Request.Headers.TryGetValue(KnownHttpHeaders.RoleName, out var userRole))
        {
            _metricsService.IncreaseNumberOfUnauthorizedAdminAccesses(
                MetricLabelValues.UnauthorizedAdminAccessReasons.MissingRole);

            return TypedResults.Forbid();
        }

        if (userRole != UserConstants.RoleNames.SuperUser)
        {
            _metricsService.IncreaseNumberOfUnauthorizedAdminAccesses(
                MetricLabelValues.UnauthorizedAdminAccessReasons.InvalidRole);

            return TypedResults.Forbid();
        }

        return await next(context);
    }
}
