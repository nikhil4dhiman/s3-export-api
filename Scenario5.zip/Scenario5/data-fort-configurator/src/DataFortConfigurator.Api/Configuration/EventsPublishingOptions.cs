using System.ComponentModel.DataAnnotations;

namespace DataFortConfigurator.Api.Configuration;

internal class EventsPublishingOptions
{
    [Required]
    public required string TopicArn { get; init; }
}
