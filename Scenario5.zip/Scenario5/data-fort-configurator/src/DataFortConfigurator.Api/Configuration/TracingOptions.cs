using System;

namespace DataFortConfigurator.Api.Configuration;

internal class TracingOptions
{
    public const string SectionName = "Tracing";

    public string CollectorEndpoint { get; set; } = null!;

    public string EnvironmentName { get; set; } = null!;

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(CollectorEndpoint))
        {
            throw new InvalidOperationException($"The '{SectionName}:{nameof(CollectorEndpoint)}' is required.");
        }

        if (string.IsNullOrWhiteSpace(EnvironmentName))
        {
            throw new InvalidOperationException($"The '{SectionName}:{nameof(EnvironmentName)}' is required.");
        }
    }
}
