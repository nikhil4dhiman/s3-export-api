using System.ComponentModel.DataAnnotations;

namespace DataFortConfigurator.Api.Configuration;

internal class RepositoryCreationOptions
{
    [Required]
    [Range(1, long.MaxValue)]
    public required long GracePeriodSeconds { get; init; }
}
