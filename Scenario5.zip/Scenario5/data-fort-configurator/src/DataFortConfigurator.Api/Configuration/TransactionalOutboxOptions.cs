namespace DataFortConfigurator.Api.Configuration;

internal class TransactionalOutboxOptions
{
    public int DefaultPollingIntervalSeconds { get; set; }

    public int PollingIntervalInCaseOfEmptyBatchSeconds { get; set; }

    public int PollingIntervalInCaseOfLockIsBusySeconds { get; set; }

    public int EntryProcessingAttemptsCount { get; set; }

    public int CleanupPollingIntervalMinutes { get; set; }

    public int PublishedRecordsCleanupIntervalMinutes { get; set; }
}
