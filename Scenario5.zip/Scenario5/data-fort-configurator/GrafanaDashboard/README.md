## Grafana Dashboards

This directory contains files which represent DataFort Configurator Grafana dashboards in JSON format.
They are stored here for the reference, and not uploaded automatically to Grafana. If they are not present,
you can upload these files manually or ask DevOps team to do that.
