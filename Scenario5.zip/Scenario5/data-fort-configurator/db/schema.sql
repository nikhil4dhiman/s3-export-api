\restrict UERh3A04sxs5btpNy57B0BlORfrRuYPm4lpkwdl3kspZdgpc0D9pNczEPZ5bJV7

-- Dumped from database version 18.0
-- Dumped by pg_dump version 18.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: migration; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA migration;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: schema_migrations; Type: TABLE; Schema: migration; Owner: -
--

CREATE TABLE migration.schema_migrations (
    version character varying NOT NULL
);


--
-- Name: outbox; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox (
    id text NOT NULL,
    type text NOT NULL,
    payload text NOT NULL,
    transport_parameters text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    created_at_utc timestamp(6) with time zone NOT NULL,
    updated_at_utc timestamp(6) with time zone NOT NULL,
    published_at_utc timestamp(6) with time zone,
    last_failed_at_utc timestamp(6) with time zone,
    failure_count integer,
    trace_parent text
);


--
-- Name: region; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.region (
    name text NOT NULL
);


--
-- Name: repository; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repository (
    id text NOT NULL,
    storage_client_name text CONSTRAINT repository_storage_client_not_null NOT NULL,
    name text NOT NULL,
    created_at_utc timestamp(6) with time zone NOT NULL,
    updated_at_utc timestamp(6) with time zone NOT NULL,
    retired_at_utc timestamp(6) with time zone,
    key_bundle_id text NOT NULL,
    locked_to_write_at_utc timestamp(6) with time zone,
    locked_to_write_until_utc timestamp(6) with time zone,
    grace_period_seconds bigint DEFAULT 2592000 NOT NULL
);


--
-- Name: repository_instance; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.repository_instance (
    id text NOT NULL,
    storage_id text NOT NULL,
    repository_id text NOT NULL,
    created_at_utc timestamp(6) with time zone NOT NULL,
    updated_at_utc timestamp(6) with time zone NOT NULL,
    retired_at_utc timestamp(6) with time zone,
    actual_role text DEFAULT 'secondary'::text NOT NULL,
    desired_role text DEFAULT 'secondary'::text NOT NULL,
    terminated_at_utc timestamp(6) with time zone
);


--
-- Name: storage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage (
    id text NOT NULL,
    region text NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at_utc timestamp(6) with time zone NOT NULL,
    updated_at_utc timestamp(6) with time zone NOT NULL,
    deleted_at_utc timestamp(6) with time zone
);


--
-- Name: storage_client; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_client (
    name text NOT NULL
);


--
-- Name: storage_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.storage_credentials (
    storage_id text NOT NULL,
    storage_client_name text CONSTRAINT storage_credentials_storage_client_not_null NOT NULL
);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: migration; Owner: -
--

ALTER TABLE ONLY migration.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- Name: outbox outbox_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox
    ADD CONSTRAINT outbox_pkey PRIMARY KEY (id);


--
-- Name: region region_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.region
    ADD CONSTRAINT region_pkey PRIMARY KEY (name);


--
-- Name: repository_instance repository_instance_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repository_instance
    ADD CONSTRAINT repository_instance_pkey PRIMARY KEY (id);


--
-- Name: repository repository_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repository
    ADD CONSTRAINT repository_pkey PRIMARY KEY (id);


--
-- Name: storage_client storage_client_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_client
    ADD CONSTRAINT storage_client_pkey PRIMARY KEY (name);


--
-- Name: storage_credentials storage_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_credentials
    ADD CONSTRAINT storage_credentials_pkey PRIMARY KEY (storage_id, storage_client_name);


--
-- Name: storage storage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage
    ADD CONSTRAINT storage_pkey PRIMARY KEY (id);


--
-- Name: idx_outbox_pending_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_outbox_pending_created_at ON public.outbox USING btree (created_at_utc) WHERE (status = 'pending'::text);


--
-- Name: idx_repo_instance_actual_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_repo_instance_actual_role ON public.repository_instance USING btree (repository_id, actual_role, storage_id);


--
-- Name: idx_repository_instance_repo_storage_active_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_repository_instance_repo_storage_active_unique ON public.repository_instance USING btree (repository_id, storage_id) WHERE (actual_role <> 'retired'::text);


--
-- Name: idx_repository_instance_repository_id_actual_role_main_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_repository_instance_repository_id_actual_role_main_unique ON public.repository_instance USING btree (repository_id) WHERE (actual_role = 'main'::text);


--
-- Name: idx_repository_instance_repository_id_desired_role_main_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_repository_instance_repository_id_desired_role_main_unique ON public.repository_instance USING btree (repository_id) WHERE (desired_role = 'main'::text);


--
-- Name: idx_storage_creds_storage_client_name; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_storage_creds_storage_client_name ON public.storage_credentials USING btree (storage_id, storage_client_name);


--
-- Name: idx_storage_region_is_default_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_storage_region_is_default_unique ON public.storage USING btree (region) WHERE (is_default = true);


--
-- Name: repository_instance repository_instance_repository_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repository_instance
    ADD CONSTRAINT repository_instance_repository_id_fkey FOREIGN KEY (repository_id) REFERENCES public.repository(id);


--
-- Name: repository_instance repository_instance_storage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repository_instance
    ADD CONSTRAINT repository_instance_storage_id_fkey FOREIGN KEY (storage_id) REFERENCES public.storage(id);


--
-- Name: repository repository_storage_client_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.repository
    ADD CONSTRAINT repository_storage_client_fkey FOREIGN KEY (storage_client_name) REFERENCES public.storage_client(name);


--
-- Name: storage_credentials storage_credentials_storage_client_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_credentials
    ADD CONSTRAINT storage_credentials_storage_client_fkey FOREIGN KEY (storage_client_name) REFERENCES public.storage_client(name);


--
-- Name: storage_credentials storage_credentials_storage_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage_credentials
    ADD CONSTRAINT storage_credentials_storage_id_fkey FOREIGN KEY (storage_id) REFERENCES public.storage(id);


--
-- Name: storage storage_region_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.storage
    ADD CONSTRAINT storage_region_fkey FOREIGN KEY (region) REFERENCES public.region(name);


--
-- PostgreSQL database dump complete
--

\unrestrict UERh3A04sxs5btpNy57B0BlORfrRuYPm4lpkwdl3kspZdgpc0D9pNczEPZ5bJV7


--
-- Dbmate schema migrations
--

INSERT INTO migration.schema_migrations (version) VALUES
    ('20251027073116'),
    ('20251106085058'),
    ('20251119132248'),
    ('20251121203847'),
    ('20251124154611'),
    ('20251217092757'),
    ('20260416094000'),
    ('20260427095849'),
    ('20260428074110'),
    ('20260505123826'),
    ('20260505125616'),
    ('20260518114000'),
    ('20260525155452'),
    ('20260624100946');
