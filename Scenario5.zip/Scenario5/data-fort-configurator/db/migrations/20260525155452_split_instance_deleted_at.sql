-- migrate:up
ALTER TABLE repository RENAME COLUMN deleted_at_utc TO retired_at_utc;
ALTER TABLE repository_instance RENAME COLUMN deleted_at_utc TO retired_at_utc;
ALTER TABLE repository_instance ADD COLUMN terminated_at_utc timestamp(6) with time zone;

-- migrate:down
ALTER TABLE repository_instance DROP COLUMN terminated_at_utc;
ALTER TABLE repository_instance RENAME COLUMN retired_at_utc TO deleted_at_utc;
ALTER TABLE repository RENAME COLUMN retired_at_utc TO deleted_at_utc;

