-- migrate:up
ALTER TABLE storage_credentials DROP COLUMN IF EXISTS credentials;

-- migrate:down
ALTER TABLE storage_credentials ADD COLUMN credentials text;
