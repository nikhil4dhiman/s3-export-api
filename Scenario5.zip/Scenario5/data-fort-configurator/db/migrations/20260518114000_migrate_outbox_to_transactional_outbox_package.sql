-- migrate:up

DROP INDEX IF EXISTS idx_outbox_created_occurred_at;
DROP TABLE IF EXISTS outbox;

CREATE TABLE outbox
(
    id                   text                        PRIMARY KEY,
    type                 text                        NOT NULL,
    payload              text                        NOT NULL,
    transport_parameters text                        NOT NULL,
    status               text                        NOT NULL DEFAULT 'pending',
    created_at_utc       timestamp(6) with time zone NOT NULL,
    updated_at_utc       timestamp(6) with time zone NOT NULL,
    published_at_utc     timestamp(6) with time zone,
    last_failed_at_utc   timestamp(6) with time zone,
    failure_count        integer,
    trace_parent         text
);

CREATE INDEX IF NOT EXISTS idx_outbox_pending_created_at
    ON outbox (created_at_utc)
    WHERE status = 'pending';

-- migrate:down

DROP INDEX IF EXISTS idx_outbox_pending_created_at;
DROP TABLE IF EXISTS outbox;

CREATE TABLE outbox
(
    id               text                        PRIMARY KEY,
    event_type       text                        NOT NULL,
    payload          text                        NOT NULL,
    status           text                        NOT NULL DEFAULT 'created',
    occurred_at_utc  timestamp(6) with time zone NOT NULL,
    processed_at_utc timestamp(6) with time zone
);

CREATE INDEX IF NOT EXISTS idx_outbox_created_occurred_at
    ON outbox (occurred_at_utc)
    WHERE status = 'created';
