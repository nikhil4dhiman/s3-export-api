-- migrate:up

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, UPDATE, INSERT, DELETE ON TABLES TO "data-fort-config-application-user";

-- migrate:down

ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE SELECT, UPDATE, INSERT, DELETE ON TABLES FROM "data-fort-config-application-user";
