-- migrate:up
ALTER TABLE storage_credentials RENAME COLUMN storage_client TO storage_client_name;
ALTER TABLE repository RENAME COLUMN storage_client TO storage_client_name;
ALTER INDEX idx_storage_creds_storage_client RENAME TO idx_storage_creds_storage_client_name;

-- migrate:down
ALTER TABLE storage_credentials RENAME COLUMN storage_client_name TO storage_client;
ALTER TABLE repository RENAME COLUMN storage_client_name TO storage_client;
ALTER INDEX idx_storage_creds_storage_client_name RENAME TO idx_storage_creds_storage_client;
