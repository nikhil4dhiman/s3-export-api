-- migrate:up
CREATE UNIQUE INDEX idx_repository_instance_repository_id_desired_role_main_unique
    ON repository_instance (repository_id)
    WHERE desired_role = 'main';

-- migrate:down
DROP INDEX IF EXISTS idx_repository_instance_repository_id_desired_role_main_unique;
