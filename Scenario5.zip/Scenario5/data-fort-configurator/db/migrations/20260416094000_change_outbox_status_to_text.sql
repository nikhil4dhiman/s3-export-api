-- migrate:up

ALTER TABLE outbox
    ALTER COLUMN status DROP DEFAULT;

ALTER TABLE outbox
    ALTER COLUMN status TYPE text
    USING status::text;

ALTER TABLE outbox
    ALTER COLUMN status SET DEFAULT 'created';

DROP TYPE IF EXISTS outbox_status;

CREATE INDEX IF NOT EXISTS idx_outbox_created_occurred_at
    ON outbox (occurred_at_utc)
    WHERE status = 'created';

-- migrate:down

DROP INDEX IF EXISTS idx_outbox_created_occurred_at;

CREATE TYPE outbox_status AS ENUM ('created', 'sent', 'failed');

ALTER TABLE outbox
    ALTER COLUMN status DROP DEFAULT;

ALTER TABLE outbox
    ALTER COLUMN status TYPE outbox_status
    USING status::outbox_status;

ALTER TABLE outbox
    ALTER COLUMN status SET DEFAULT 'created';
