-- migrate:up
ALTER TABLE repository_instance
    ADD COLUMN IF NOT EXISTS actual_role text NOT NULL DEFAULT 'secondary',
    ADD COLUMN IF NOT EXISTS desired_role text NOT NULL DEFAULT 'secondary';

CREATE UNIQUE INDEX IF NOT EXISTS idx_repository_instance_repository_id_actual_role_main_unique
    ON repository_instance (repository_id)
    WHERE actual_role = 'main';

CREATE UNIQUE INDEX IF NOT EXISTS idx_repository_instance_repo_storage_active_unique
    ON repository_instance(repository_id, storage_id)
    WHERE actual_role <> 'retired';

ALTER TABLE repository
    ADD COLUMN IF NOT EXISTS locked_to_write_at_utc timestamp(6) with time zone,
    ADD COLUMN IF NOT EXISTS locked_to_write_until_utc timestamp(6) with time zone;

CREATE INDEX IF NOT EXISTS idx_repo_instance_actual_role
    ON repository_instance (repository_id, actual_role, storage_id);


-- migrate:down
DROP INDEX IF EXISTS idx_repo_instance_actual_role;
DROP INDEX IF EXISTS idx_repository_instance_repo_storage_active_unique;
DROP INDEX IF EXISTS idx_repository_instance_repository_id_actual_role_main_unique;

ALTER TABLE repository
    DROP COLUMN IF EXISTS locked_to_write_until_utc,
    DROP COLUMN IF EXISTS locked_to_write_at_utc;

ALTER TABLE repository_instance
    DROP COLUMN IF EXISTS desired_role,
    DROP COLUMN IF EXISTS actual_role;
