-- migrate:up
CREATE TABLE region
(
    name text PRIMARY KEY
);

CREATE TABLE storage_client
(
    name text PRIMARY KEY
);

CREATE TABLE storage
(
    id             text                        PRIMARY KEY,
    region         text                        NOT NULL REFERENCES region (name),
    name           text                        NOT NULL,
    is_default     boolean                     NOT NULL DEFAULT false,
    created_at_utc timestamp(6) with time zone NOT NULL,
    updated_at_utc timestamp(6) with time zone NOT NULL,
    deleted_at_utc timestamp(6) with time zone
);

CREATE TABLE storage_credentials
(
    storage_id     text NOT NULL REFERENCES storage (id),
    storage_client text NOT NULL REFERENCES storage_client (name),
    credentials    text NOT NULL,
    PRIMARY KEY (storage_id, storage_client)
);

CREATE TABLE repository
(
    id             text                        PRIMARY KEY,
    storage_client text                        NOT NULL REFERENCES storage_client (name),
    name           text                        NOT NULL,
    created_at_utc timestamp(6) with time zone NOT NULL,
    updated_at_utc timestamp(6) with time zone NOT NULL,
    deleted_at_utc timestamp(6) with time zone
);

CREATE TABLE repository_instance
(
    id             text                        PRIMARY KEY,
    storage_id     text                        NOT NULL REFERENCES storage (id),
    repository_id  text                        NOT NULL REFERENCES repository (id),
    is_main        boolean                     NOT NULL DEFAULT false,
    created_at_utc timestamp(6) with time zone NOT NULL,
    updated_at_utc timestamp(6) with time zone NOT NULL,
    deleted_at_utc timestamp(6) with time zone
);

CREATE TYPE outbox_status AS ENUM ('created', 'sent', 'failed');

CREATE TABLE outbox
(
    id               text                        PRIMARY KEY,
    event_type       text                        NOT NULL,
    payload          text                        NOT NULL,
    status           outbox_status               NOT NULL DEFAULT 'created',
    occurred_at_utc  timestamp(6) with time zone NOT NULL,
    processed_at_utc timestamp(6) with time zone
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_storage_region_is_default_unique
    ON storage (region)
    WHERE is_default = true;

CREATE UNIQUE INDEX IF NOT EXISTS idx_repository_instance_repository_id_is_main_unique
    ON repository_instance (repository_id)
    WHERE is_main = true;

CREATE INDEX IF NOT EXISTS idx_storage_creds_storage_client
    ON storage_credentials (storage_id, storage_client);


CREATE INDEX IF NOT EXISTS idx_repo_instance_main
    ON repository_instance (repository_id, is_main, storage_id);

-- migrate:down
DROP INDEX IF EXISTS idx_repo_instance_main;
DROP INDEX IF EXISTS idx_storage_creds_storage_client;
DROP INDEX IF EXISTS idx_storage_region_is_default_unique;
DROP INDEX IF EXISTS idx_repository_instance_repository_id_is_main_unique;

DROP TABLE IF EXISTS outbox;
DROP TYPE IF EXISTS outbox_status;
DROP TABLE IF EXISTS repository_instance;
DROP TABLE IF EXISTS repository;
DROP TABLE IF EXISTS storage_credentials;
DROP TABLE IF EXISTS storage;
DROP TABLE IF EXISTS storage_client;
DROP TABLE IF EXISTS region;
