-- migrate:up
DROP INDEX IF EXISTS idx_repo_instance_main;
DROP INDEX IF EXISTS idx_repository_instance_repository_id_is_main_unique;
ALTER TABLE repository_instance DROP COLUMN IF EXISTS is_main;

-- migrate:down
ALTER TABLE repository_instance ADD COLUMN IF NOT EXISTS is_main boolean NOT NULL DEFAULT false;
UPDATE repository_instance SET is_main = true WHERE actual_role = 'main';
CREATE INDEX IF NOT EXISTS idx_repo_instance_main
    ON repository_instance (repository_id, is_main, storage_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_repository_instance_repository_id_is_main_unique
    ON repository_instance (repository_id)
    WHERE is_main = true;
