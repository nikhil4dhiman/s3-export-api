-- migrate:up
UPDATE repository_instance SET actual_role = 'main', desired_role = 'main' WHERE is_main = true;
UPDATE repository_instance SET actual_role = 'retired', desired_role = 'retired' WHERE deleted_at_utc IS NOT NULL;

-- migrate:down
UPDATE repository_instance SET actual_role = 'secondary', desired_role = 'secondary' WHERE is_main = true;
UPDATE repository_instance SET actual_role = 'secondary', desired_role = 'secondary' WHERE deleted_at_utc IS NOT NULL;

