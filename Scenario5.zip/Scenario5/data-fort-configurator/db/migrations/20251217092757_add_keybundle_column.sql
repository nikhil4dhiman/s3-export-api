-- migrate:up
TRUNCATE TABLE repository_instance, repository;
ALTER TABLE repository ADD COLUMN IF NOT EXISTS key_bundle_id TEXT NOT NULL;

-- migrate:down
-- No rollback possible for TRUNCATE TABLE
ALTER TABLE repository DROP COLUMN IF EXISTS key_bundle_id;
