-- migrate:up

INSERT INTO region (name) VALUES ('au');
INSERT INTO region (name) VALUES ('be');
INSERT INTO region (name) VALUES ('br');
INSERT INTO region (name) VALUES ('ca');
INSERT INTO region (name) VALUES ('ch');
INSERT INTO region (name) VALUES ('de');
INSERT INTO region (name) VALUES ('dk');
INSERT INTO region (name) VALUES ('es');
INSERT INTO region (name) VALUES ('fr');
INSERT INTO region (name) VALUES ('it');
INSERT INTO region (name) VALUES ('nl');
INSERT INTO region (name) VALUES ('no');
INSERT INTO region (name) VALUES ('se');
INSERT INTO region (name) VALUES ('uk');
INSERT INTO region (name) VALUES ('us');
INSERT INTO region (name) VALUES ('za');

-- migrate:down

DELETE FROM region WHERE name IN (
     'au', 'be', 'br', 'ca', 'ch', 'de', 'dk', 'es', 'fr', 'it', 'nl', 'no', 'se', 'uk', 'us', 'za'
    );
