-- migrate:up
ALTER TABLE repository
    ADD COLUMN IF NOT EXISTS grace_period_seconds bigint NOT NULL DEFAULT 2592000; -- 60*60*24*30

-- migrate:down
ALTER TABLE repository
    DROP COLUMN IF EXISTS grace_period_seconds;

