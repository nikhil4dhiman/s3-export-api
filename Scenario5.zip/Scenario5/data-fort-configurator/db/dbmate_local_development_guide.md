## dbmate Local Development Guide

This guide explains how to use `dbmate` for database migrations in this project. It is intended for developers new to the tool or setting up their local environment.

### What is dbmate?
`dbmate` is a simple database migration tool. Migration files are stored in `./db/migrations` and named with a timestamp prefix. The current schema is always dumped to `db/schema.sql`.

---

## 1. Installation

* **dbmate:** Follow the [official dbmate installation guide](https://github.com/amacneil/dbmate?tab=readme-ov-file#dbmate).
    * Verify installation with:
        ```bash
         # dbmate --version
        ```
* **PostgreSQL:** Download from [postgresql.org/download](https://www.postgresql.org/download/).

---

## 2. Local Setup

### Connect to db:
To connect to local DB:
* Create a `.env` file in the project root with your database connection string:
    ```
    DATABASE_URL=postgres://<user>:<password>@localhost:5432/<db-name>?sslmode=disable
    DBMATE_MIGRATIONS_TABLE="migration.schema_migrations"
    ```
    * Replace `<db-name>` with name of database you want to create
    * Default for `<user>` is `postgres`
    * Default for `<password>` is what user provided during postgres installation
    * `DBMATE_MIGRATIONS_TABLE` is here to save migrations table in other than `public` folder in the db

* run `dbmate status` to check if connection is established.

* (`DATABASE_URL` and `DBMATE_MIGRATIONS_TABLE` values can be also added via environment variables as described in [dbmate docs](https://github.com/amacneil/dbmate?tab=readme-ov-file#connecting-to-the-database))
---

* To finish set up run:
    ```
    $ dbmate up
    ```
    This creates the database (if needed) and applies all existing migrations.

---

## 3. Basic Operations

* **Create a new migration:**
    ```
    $ dbmate new <migration-name>
    ```
    This creates a new migration file in `db/migrations/`.

* **Apply migrations:**
    ```
    $ dbmate migrate
    ```
    This applies all pending migrations to your database.

* **Rollback migrations:**
    ```
    $ dbmate rollback
    ```
    This rollbacks **last** migration using `migrate:down` section from migration file,

* **Dump schema:**
    ```
    $ dbmate dump
    ```
    Always run this before pushing changes, so `db/schema.sql` stays up to date.

---

## 4. Migration File Structure

Each migration file has two sections:

- `-- migrate:up` — SQL to apply the migration (e.g., create table)
- `-- migrate:down` — SQL to revert the migration (e.g., drop table)

Example:
```sql
-- migrate:up
CREATE TABLE example (...);

-- migrate:down
DROP TABLE example;
```

---

## 5. More

* Full command list: [dbmate commands](https://github.com/amacneil/dbmate?tab=readme-ov-file#commands)

---