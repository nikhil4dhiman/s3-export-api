# DataFort Configurator DB

The scripts for schema migration are located in the `/db` folder and are run automatically by the deployment pipeline.

## Initial setup

Before applications can be deployed to the cluster for the first time, some actions **must be performed manually on each environment**.
Thus, all needed DB users should be created and corresponding permissions should be granted.

### Create DB users for applications

DB migrations runs not under a root user, but under a separate user with a limited set of permissions. The same rule applies to other applications that use the DB - they should use DB users that have a limited set of permissions.

1. **[DevOps or RMT]** Generate a secure password for a new DB migration user.
2. **[DevOps or RMT]** Put the password to the vault using the information below
    - Path: `vault:backup/data/services/data-fort/db-updater/<env_name>#data-fort-config-migration-user-password`
        - Replace `<env_name>` with the corresponding environment name: `coll`, `stg` or `prd`.
3. **[DevOps or RMT]** Generate a secure password for a new application user with read/write permissions.
4. **[DevOps or RMT]** Put the password to the vault using the information below
    - Path: `vault:backup/data/services/data-fort/configurator/<env_name>#data-fort-config-application-user-password`
        - Replace `<env_name>` with the corresponding environment name: `coll`, `stg` or `prd`.
5. **[DevOps or RMT]** Copy the [setup-scripts/create-database.sql](./setup-scripts/create-database.sql) script locally and replace `DatabaseNamePlaceholder` placeholder in the script.
    - Replace `DatabaseNamePlaceholder` with the corresponding database name.
6. **[DevOps or RMT]** Run the script with replaced placeholder on the cluster using a user with elevated permissions (i.e. `root`).
7. **[DevOps or RMT]** Copy the [setup-scripts/create-migration-schema-and-users.sql](./setup-scripts/create-migration-schema-and-users.sql) script locally and replace password placeholders in the script with the passwords from the Vault.
    - Replace `ApplicationUserPasswordPlaceholder` with the password for the application read/write user (from `vault:backup/data/services/data-fort/configurator/<env_name>#data-fort-config-application-user-password`)
    - Replace `DbMigrationsUserPasswordPlaceholder` with the password for the DB migration user (from `vault:backup/data/services/data-fort/db-updater/<env_name>#data-fort-config-migration-user-password`)
8. **[DevOps or RMT]** Connect to the new database from **step 6**.
9. **[DevOps or RMT]** Run the script with connection to the new database from **step 6** with replaced placeholders on the cluster using a user with elevated permissions (i.e. `root`).

## Guidelines

1. Make sure all the scripts have migration up and migration down parts.
2. Use all-lower naming style for a database name.
3. Database name should have a db postfix, e.g. someapplicationdb.
    For dev environments, database name should have a `dev` prefix and a `db<dev_env_name>` postfix, e.g. devsomeapplicationdbgaps.
4. Use snake case naming style in singular form for table names, e.g. `user_configuration`.
5. Use snake case naming style for column names.
