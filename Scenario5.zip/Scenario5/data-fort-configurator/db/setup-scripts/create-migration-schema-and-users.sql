/*
    Purpose:
        Creates schema `migration` for dbmate and users for the DataFort Configurator application and DB migrations.
    Placeholders:
        - ApplicationUserPasswordPlaceholder: The password for the application user.
        - DbMigrationsUserPasswordPlaceholder: The password for the DB migrations user.
    Notes:
        Run with CREATE SCHEMA, CREATE USER and GRANT permissions, e.g. root user can be used.
*/

-- Run this script only after connection to the database from the previous step

CREATE USER "data-fort-config-application-user" WITH PASSWORD 'ApplicationUserPasswordPlaceholder';

GRANT USAGE ON SCHEMA public TO "data-fort-config-application-user";
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO "data-fort-config-application-user";
GRANT SELECT, UPDATE, INSERT, DELETE ON ALL TABLES IN SCHEMA public TO "data-fort-config-application-user";

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, UPDATE, INSERT, DELETE ON TABLES TO "data-fort-config-application-user";
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO "data-fort-config-application-user";

CREATE SCHEMA IF NOT EXISTS migration;

CREATE USER "data-fort-config-migration-user" WITH PASSWORD 'DbMigrationsUserPasswordPlaceholder';

GRANT USAGE, CREATE ON SCHEMA public TO "data-fort-config-migration-user";
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO "data-fort-config-migration-user";
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO "data-fort-config-migration-user";

ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON TABLES TO "data-fort-config-migration-user";
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT ALL PRIVILEGES ON SEQUENCES TO "data-fort-config-migration-user";

GRANT USAGE, CREATE ON SCHEMA migration TO "data-fort-config-migration-user";
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA migration TO "data-fort-config-migration-user";
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA migration TO "data-fort-config-migration-user";

ALTER DEFAULT PRIVILEGES IN SCHEMA migration GRANT ALL PRIVILEGES ON TABLES TO "data-fort-config-migration-user";
ALTER DEFAULT PRIVILEGES IN SCHEMA migration GRANT ALL PRIVILEGES ON SEQUENCES TO "data-fort-config-migration-user";
