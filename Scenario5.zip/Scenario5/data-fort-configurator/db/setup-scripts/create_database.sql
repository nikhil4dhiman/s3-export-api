/*
    Purpose:
        Creates the database for the DataFort Configurator application.
    Placeholders:
        - DatabaseNamePlaceholder: The name of the database to create.
    Notes:
        Run with CREATE DATABASE, e.g. root user can be used.
*/

-- Create database
CREATE DATABASE DatabaseNamePlaceholder;
