# DataFort Configurator Documentation

## System

[DataFort Configurator on GitHub](system/content/index.md)  
[DataFort Configurator on Backstage](https://portal.n-able.dev/catalog/cove/system/data-fort-configurator)

## Components

### DataFort Configurator API

[DataFort Configurator API on GitHub](components/api/content/index.md)  
[DataFort Configurator API on Backstage](https://portal.n-able.dev/catalog/cove/component/data-fort-configurator-api)
