# Application card for the DataFort Configurator

### Urls

DataFort Configurator is not publicly accessible. The only way to access DataFort Configurator is via [apigatewayrouter](https://github.com/nable-backup/apigatewayrouter).
See [router configuration](https://github.com/nable-backup/backup-manager/blob/develop/Integration/IaC/router/containers/nginx/nginx.conf.tpl#data-fort-configurator) for more details.

* Dev - http://router-service.dev-router-ENV.svc.cluster.local/data-fort-configurator
* Coll - http://router-service.coll-router.svc.cluster.local/data-fort-configurator
* Stg - http://router-service.stg-router.svc.cluster.local/data-fort-configurator
* Prd - http://router-service.prd-router.svc.cluster.local/data-fort-configurator

See [Notes](#notes) to check supported `ENV` values.

### Logging

Url: https://n-able.splunkcloud.com/en-US/app/search/search

|       | Dev                                                                                                                                                                                                                                                                                                   | Coll                                                                                                                                                                                                                                                                                                | Stg                                                                                                                                                                                                                                                                                               | Prd                                                                                                                                                                                                                                                                                               |
|-------|-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------|
| Index | p-backup-dev (default in Splunk)                                                                                                                                                                                                                                                                      | p-backup-stg                                                                                                                                                                                                                                                                                        | p-backup-stg                                                                                                                                                                                                                                                                                      | p-backup-prd                                                                                                                                                                                                                                                                                      |
| Query | `index="p-backup-dev" container_name="data-fort-configurator" namespace="dev-data-fort-ENV"`                                                                                                                                                                                                          | `index="p-backup-stg" container_name="data-fort-configurator" namespace="coll-data-fort"`                                                                                                                                                                                                           | `index="p-backup-stg" container_name="data-fort-configurator" namespace="stg-data-fort"`                                                                                                                                                                                                          | `index="p-backup-prd" container_name="data-fort-configurator" namespace="prd-data-fort"`                                                                                                                                                                                                          |
| Link  | [Dev](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-dev%22%20container_name%3D%22data-fort-configurator%22%20namespace%3D%22dev-data-fort-ENV%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823898.1831930)  | [Coll](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-stg%22%20container_name%3D%22data-fort-configurator%22%20namespace%3D%22coll-data-fort%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823974.1832233)  | [Stg](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-stg%22%20container_name%3D%22data-fort-configurator%22%20namespace%3D%22stg-data-fort%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823947.1832094)  | [Prd](https://n-able.splunkcloud.com/en-US/app/search/search?q=search%20index%3D%22p-backup-prd%22%20container_name%3D%22data-fort-configurator%22%20namespace%3D%22prd-data-fort%22&display.page.search.mode=smart&dispatch.sample_ratio=1&earliest=-30m%40m&latest=now&sid=1719823993.1832296)  |

See [Notes](#notes) to check supported `ENV` values.

### Grafana

#### DataFort Configurator dashboard

* [Dev](https://grafana.cloudbackup.management/d/df4ph7gwfol4wd/data-fort-configurator?orgId=1&var-env=dev&var-namespace=dev-data-fort-autopanda&var-pod=All)
* [Coll](https://grafana.cloudbackup.management/d/df4ph7gwfol4wd/data-fort-configurator?orgId=1&var-env=stg&var-namespace=coll-data-fort&var-pod=All)
* [Stg](https://grafana.cloudbackup.management/d/df4ph7gwfol4wd/data-fort-configurator?orgId=1&var-env=stg&var-namespace=stg-data-fort&var-pod=All)
* [Prd](https://grafana.cloudbackup.management/d/df4ph7gwfol4wd/data-fort-configurator?orgId=1&var-env=prd&var-namespace=prd-data-fort&var-pod=All)

### CI/CD Server

* [NextStage Dev](https://backup.build.n-able.dev/job/BACKUP/job/cove/job/data-fort/job/dev/)
* [NextStage Coll](https://backup.build.n-able.dev/job/BACKUP/job/cove/job/data-fort/job/coll/job/data-fort-configurator-deploy-coll/)
* [NextStage Stg](https://backup.build.n-able.dev/job/BACKUP/job/cove/job/data-fort/job/stg/job/data-fort-configurator-deploy-stg/)
* [NextStage Prd](https://backup.build.n-able.dev/job/BACKUP/job/cove/job/data-fort/job/prd/job/data-fort-configurator-deploy-prd/)

### Repository

Url: https://github.com/nable-backup/data-fort-configurator

### Secrets server

HashiCorp Vault.

* [Dev UI](https://vault.dev.bckp.io/ui/vault/secrets/backup/kv/list/services/data-fort/configurator/)
* [Coll and Stg UI](https://vault.stg.bckp.io/ui/vault/secrets/backup/kv/list/services/data-fort/configurator/)
* [Prd UI](https://vault.prd.bckp.io/ui/vault/secrets/backup/kv/list/services/data-fort/configurator/)

HashiCorp Vault storage credentials:

* [Dev UI](https://vault.dev.bckp.io/ui/vault/secrets/data-fort-configurator-storage-credentials/kv/list/)
* [Coll and Stg UI](https://vault.stg.bckp.io/ui/vault/secrets/data-fort-configurator-storage-credentials/kv/list/)
* [Prd UI](https://vault.prd.bckp.io/ui/vault/secrets/data-fort-configurator-storage-credentials/kv/list/)

### Container images storage

[Amazon ECR Index](https://ecrindex.n-able.dev/#cove-platform-prd-data-fort-configurator)

### Notes

Supported dev environments are listed [here](https://github.com/nable-backup/data-fort-configurator/tree/develop/deployment/environments).
