# Environment variables

| Name                                                           | Description                                                                                                            |
|----------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------|
| ASPNETCORE_URLS                                                | Indicates the IP addresses or host addresses with ports and protocols that the server should listen on for requests.   |
| ASPNETCORE_ENVIRONMENT                                         | Defines current runtime environment.                                                                                   |
| ManagementPort                                                 | A port on which health checks and metrics endpoints are exposed.                                                       |
| Database__Host                                                 | A Database host cluster.                                                                                               |
| Database__Port                                                 | A Database port.                                                                                                       |
| Database__UserName                                             | A Database user name.                                                                                                  |
| Database__Password                                             | A Database password.                                                                                                   |
| Database__DatabaseName                                         | A Database name.                                                                                                       |
| Database__CommandTimeoutInSeconds                              | A Database command timeout in seconds.                                                                                 |
| HashiCorpVaultApi__BaseUrl                                     | The base URL of the HashiCorp Vault server used for storing and retrieving secrets.                                    |
| HashiCorpVaultApi__SecretsEnginePath                           | The path to the KV v2 secrets engine in Vault.                                                                         |
| HashiCorpVaultApi__EnvironmentName                             | The environment name used for Vault configuration (e.g., dev, staging, production).                                    |
| HashiCorpVaultApi__KubernetesAuthRole                          | The Kubernetes authentication role name for Vault authentication.                                                      |
| Tracing__CollectorEndpoint                                     | An endpoint URL to the OpenTelemetry collector.                                                                        |
| Tracing__EnvironmentName                                       | An environment attribute value.                                                                                        |
| DataFortCryptApi__BaseUrl                                      | Base URL for the DataFort Crypt API via API Gateway Router.                                                            |
| CloudManagementServiceClient__EndpointUrl                      | The endpoint URL for the Cloud Management Service API.                                                                 |
| CloudManagementServiceClient__Visa                             | The Visa value used for authenticating with the Cloud Management Service API.                                          |
| RepositoryCreation__GracePeriodSeconds                         | Default grace period value in seconds.                                                                                 |
| EventsPublishing__TopicArn                                     | The AWS SNS topic ARN used by the transactional outbox publisher for repository events.                                |
| TransactionalOutbox__DefaultPollingIntervalSeconds             | Default interval in seconds between outbox polling attempts.                                                           |
| TransactionalOutbox__PollingIntervalInCaseOfEmptyBatchSeconds  | Interval in seconds used when an outbox polling batch is empty.                                                        |
| TransactionalOutbox__PollingIntervalInCaseOfLockIsBusySeconds  | Interval in seconds used when outbox processing cannot acquire a lock.                                                 |
| TransactionalOutbox__EntryProcessingAttemptsCount              | Number of processing attempts before an outbox entry is treated as failed.                                             |
| TransactionalOutbox__CleanupPollingIntervalMinutes             | Interval in minutes between cleanup job executions for the transactional outbox.                                       |
| TransactionalOutbox__PublishedRecordsCleanupIntervalMinutes    | Age threshold in minutes for cleaning up published outbox records.                                                     |
