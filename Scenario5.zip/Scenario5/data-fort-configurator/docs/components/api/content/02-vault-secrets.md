# Vault secrets

## Location
vault:backup/data/services/data-fort-configurator/api/<env_name>, where <env_name> is one of the following values: dev, coll, stg, prd

## Values

| Key Name                         | Description                                                                            | Environment variable name                     |
|----------------------------------|----------------------------------------------------------------------------------------|-----------------------------------------------|
| db-password                      | Password to connect to database.                                                       | Database__Password                            |
| vaultconfiguration-url           | Vault url.                                                                             | VaultConfiguration__Url                       |
