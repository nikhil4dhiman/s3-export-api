# Setup integration tests

#### Create file `secrets.json`:

```json
{
  "Database:ConnectionString": "<integration-tests database connection string>"
}
```

The whole file with populated example values you can find in Vault by the path `vault:backup/data/services/data-fort/configurator/tests#secrets-for-local-run`.  

Real secrets can be found in Vault. Here are examples on where to find these values:

* `Database:ConnectionString`: `vault:backup/data/services/data-fort/configurator/ENV#db-connection-string`
  * By default, we tend to use autopanda env resources (where it's possible to use them without interference with deployed services)
    for CI tests, so, if you want to run them locally, please use `devdatafortconfiguratordbautopanda`
  * To connect to a remote database from the local machine, you need to set up an SSH tunnel.
    Then take a secret from the Vault and replace the `server` and `port` values with `localhost` and `33070` correspondingly.

#### To set user secrets, run the following command:

```sh
cat secrets.json | dotnet user-secrets --project tests/DataFortConfigurator.Api.IntegrationTests/DataFortConfigurator.Api.IntegrationTests.csproj set
```

#### To set up an SSH tunnel, replace the placeholder and run the following command (under VPN):

```sh
ssh -Nn -L localhost:33070:DB_HOST:DB_PORT dev@bastion-eks.dev.bckp.io -i ~/.ssh/YOUR_SECRET_FILENAME
```

#### To run integration tests, run the following command:

```sh
dotnet test tests/DataFortConfigurator.Api.IntegrationTests/DataFortConfigurator.Api.IntegrationTests.csproj
```
