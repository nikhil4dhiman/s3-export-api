# DataFort Configurator System

DataFort Configurator System is one of the systems that make up DataFort Storage Platform, particularly responsible for management of storages, access to the storage, data repositories flow and ownership.

## Requirements

See [Requirements](requirements/storage-configuration.md).

## Domain Model

See [Domain Model](https://github.com/nable-backup/backup-docs/blob/master/storage/domain-model/storage-management.md).

## Architecture Overview

See [Architecture Overview](architecture/index.md).
