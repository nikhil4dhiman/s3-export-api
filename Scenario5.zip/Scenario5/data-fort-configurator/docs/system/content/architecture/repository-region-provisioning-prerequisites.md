# Repository Region Provisioning — Prerequisites

## Problem

Create a repository in the right region **automatically**, based on the location the customer
selected when the customer was created (the partner's CMS Location — an explicit choice, made once
at customer creation and stored as a partner entity property). Today that resolution is a
hardcoded switch — the partner's CMS location `"United States"` → `us` and **anything else** →
`uk`, silently. This design replaces the hardcode with **data-driven resolution**, so that adding
a new location or region is a data change, never a core-logic change (the research item's
requirement). The entire placement logic lives in the Configurator.

The core idea: **regions are named exactly like CMS locations** (`United States`,
`United Kingdom`, `Canada`, …), one region row per location — so no translation layer is needed.
Each region row has a nullable **fallback region ID** saying where repositories for that location
actually land: a self-reference means "this region serves itself" (it has storage); another ID
points at a serving region; `null` stops automatic routing for that location. Selection then has
two server-side levels:

1. **Location → target region:** find the region by the partner's CMS Location name; its
   `fallback_region_id` points at the target (on the `region` row, managed through the region admin
   API).
2. **Target region → concrete storage:** the existing storage-picking algorithm, **unchanged** —
   credentialed storages in the target region, the designated default preferred, otherwise any
   credentialed one — behind a proposed seam (`IStorageSelector`) so a capacity-aware choice
   could replace it later. Capacity-aware selection is out of scope; if ever needed, capacity is
   solved *within* a region (several storages, pick by free space), not by changing region. This
   design upgrades only region picking.

**Implementation proposal — `IStorageSelector`:** an optional abstraction for choosing an
existing storage given a resolved target region and storage client name. It does not create
storage or change the target region. The initial implementation would preserve the current
in-region selection rules; whether an interface is useful is decided during implementation.

Read top-to-bottom — each section only uses what earlier sections already defined:
**Region Model → Region Fallback → Automatic Selection → Region Rollout.**

## Region Model

A region today is a single text column: `region.name` (PK), referenced by `storage.region` (FK
`storage_region_fkey` in `db/schema.sql`). Sixteen rows are seeded with short codes (`us`, `uk`,
`au`, …); `us` and `uk` carry the real customer storages, and `es` carries one production storage
named "Post-delivery Check Test" — the post-deployment verification fixture (confirmed by the
production pre-step run); the other 13 have nothing behind them.

**The `region` table gains a UUID primary key and a nullable self-reference.** `name` remains
unique and matches the CMS location name byte-for-byte; this preserves unambiguous lookup by
partner location. `storage.region` migrates from a text FK to a UUID FK to `region.id`. The
unreleased storage admin API changes with it: storage registration accepts `regionId` instead of
a region name, and storage admin read models expose `regionId` instead of `region`. Extend the
existing regions list with IDs so the Admin UI can obtain the value to submit. This is an
intentional breaking change for the storage admin API and requires a coordinated Admin UI update;
the repository-create API is unchanged. The migrations must preserve storage associations and
apply up and down in every environment:

- [ ] **Rename migration — region names become the CMS location names**, byte-for-byte equal to
  the `Name` values CMS returns (`GetLocationInfo`): `us` → `United States`, `uk` →
  `United Kingdom`, `es` → `Spain` (it keeps the test fixture storage). While `region.name` is the
  FK target of `storage.region`, each rename updates both in **one transaction**; the UUID FK
  migration retains those links. The rename is cheap because nothing else consumes the names:
  they appear in no API request, are never
  customer-visible, and the compiled constants that used them (`KnownRegions`) are deleted by this
  feature. Before merging: grep this repo and the sibling services for `'us'`/`'uk'` as region
  values — expected hits only in migrations and tests.
- [ ] **Reconciliation migration — one region row per CMS location.** Delete the 13 unreferenced
  placeholder rows (guarded: only short-code regions not referenced by any storage — safe in dev
  environments, which are known to have storages in extra regions) and insert a row for every CMS
  location that doesn't have one yet. The location list is generated once from
  `ILocationsApi.EnumerateLocationsAsync()` (CMS SDK) — a one-time seed input, deliberately
  **not** a runtime sync. Most of these rows have no storage — they exist to carry a fallback
  pointer (next section).
  - **Naming rule going forward:** a region is always named exactly like its CMS location; when
    CMS gains a location, the matching region row is added via the admin API.

## Region Fallback

The flexible replacement for the hardcoded switch. Today
`StorageSelectionService.MapLocationToStorageRegion` maps the
CMS location name `"United States"` to `us` and **everything else** to `uk`, via compiled
constants. Every new location or region is a code change — the exact thing the research item
forbids.

- [ ] **Extend `region` (no separate fallback table):**

  | Column | Type | Nullable | Purpose |
  |---|---|---|---|
  | `id` (PK) | uuid | no | Stable region identifier |
  | `name` (unique) | text | no | CMS Location name used for partner-location lookup |
  | `fallback_region_id` (FK → `region.id`) | uuid | yes | Target for automatic placement; **self-reference means "serves itself"**, `null` disables automatic routing |
  | `created_at_utc` / `updated_at_utc` | timestamptz | no | Standard audit timestamps (house convention) |

  Example content after implementation:

  | name | fallback_region_id (target shown by name) | |
  |---|---|---|
  | United States | United States | ← self: has storage, serves itself |
  | United Kingdom | United Kingdom | ← self |
  | Spain | United Kingdom | ← carries only the test fixture; partners route to UK |
  | Canada | United Kingdom | ← no storage yet; flipped to self at go-live |
  | Germany | United Kingdom | |

  - **Resolution always follows the pointer — exactly one hop, no chains.** The target is
    `fallback_region_id`, full stop: a self-reference lands locally, another region ID lands at
    its target, and if the *target* cannot serve the request it is a named 422 (never a second hop).
    A missing region or `null` fallback is also a named 422, never a silent default. This rule is
    also what keeps a new region safely dark: registering storage under `Canada` changes nothing
    until its row is deliberately flipped to self — storage existence never routes traffic by
    itself.
  - **Seeded to reproduce today's behavior exactly** (this release is behavior-preserving, not
    breaking): `United States → self`, every other region → `United Kingdom` (including the UK
    region pointing to itself). Seed UUIDs and fallback FKs after reconciling the region rows.
  - **No region or `null` fallback → clear, named error** — never a silent default. A location
    added to CMS after the seed routes nowhere until its region row is deliberately added and
    configured through the admin API.
  - **The nullable column is the routing switch.** Go-live for a new region = point it at itself;
    incident response = point it back at a serving region; stop routing a location = set its
    fallback to `null`. All through the same API, no migration, no deployment.
- [ ] **Admin CRUD API** — region rows and their fallback IDs are maintained by DevOps / the
  DataFort Admin UI, not by migrations (the initial seed is the only migration-managed content).
  Extend the existing `/storage-mgmt/regions` resource; new writes use the admin guards
  (superuser + root-partner filters, same as the storages/credentials endpoints), while the
  existing GET keeps its access behavior:
  - `GET /storage-mgmt/regions` — existing list, extended with `id` (alongside the storage admin
    contract change) and `fallbackRegionId`.
  - `POST /storage-mgmt/regions` — create a row with `name` and optional nullable
    `fallbackRegionId`, for example `{ "name": "Canada", "fallbackRegionId": "<uk-region-uuid>" }`.
    Omitted or `null` leaves the region unrouted; a non-null ID must reference an existing region.
    Return the generated UUID; duplicate/empty name or unknown fallback ID → named `422`.
    To point a newly created region at itself, first `POST`, then `PUT` with the returned ID.
  - `PUT /storage-mgmt/regions/{regionId}` — **update only** an existing row's fallback
    (`{ "fallbackRegionId": "<target-region-uuid>" }`); self-reference is allowed, `null` stops
    automatic routing. Unknown region/target or invalid body → named `422`; never upsert.
  - `DELETE /storage-mgmt/regions/{regionId}` — allowed only when no active storage or **other**
    region's fallback references it (its own self-reference does not block deletion) — `422` with
    a named error otherwise. Use `PUT` with `null` to stop automatic routing for this location,
    or with another region's ID to redirect new repositories without deleting the region.
  - OpenAPI documented; Istio unchanged (policies are per-service).
- [ ] **Storage admin contract + Admin UI:** update `POST /storage-mgmt/storages` to accept
  `{ "name": "Canada Storage", "regionId": "<canada-region-uuid>", "isDefault": true }` instead
  of `region`, and expose `regionId` in the storage admin GET responses. Update the OpenAPI
  schemas and admin component tests; a separate DataFort Admin UI ticket updates storage
  registration and display to use the IDs from `GET /storage-mgmt/regions`. Release both sides
  together; the explicit-`storages` repository-create path still accepts storage IDs unchanged.

**Granularity notes (acknowledged, not solved here):** the CMS Location is **per-partner**, while
the domain model's Location Policy (`backup-docs`, `domain-model/data-management.md`) is
**per-repository** — this design accepts partner-level granularity for creation; per-repository
placement is the repatriation/policy-layer scope (BST-1550). And with regions named 1:1 by
location, a country has exactly one region — multiple physical sites in one country would be
multiple storages *within* its region, selected behind the proposed `IStorageSelector` seam.

## Automatic Selection

Repository creation is one endpoint, `POST /repo-mgmt/repositories`, and **its contract does not
change** — no new fields, no removed fields, no breaking change, no SDK or consumer coordination.
The request's optional `storages` field keeps supporting explicit storage IDs for
infrastructure-aware internal callers (exactly one `isMain: true` — enforced by
`RepositoryRequestStoragesCollectionValidator`). When `storages` is omitted — the normal path via
the Google Workspace integration — the server selects automatically:

- [ ] **Replace the hardcoded resolution with data-driven resolution.** Given
  `(partnerId, storageClientName)`:
  1. Partner → CMS Location name (existing lookup, kept —
     `ICloudManagementServiceApiClient.GetPartnerLocationAsync`; CMS failure remains an error as
     today).
  2. Location name → `region` row with that unique name — no row or `null` fallback → named 422,
     never a silent default. Its `fallback_region_id` identifies the **target region** (self =
     the location's own region).
  3. Target region → concrete storage: **the existing algorithm, kept as is**, behind
     **`IStorageSelector`** (implementation proposal) — non-deleted storages in the target
     region with credentials for the client; the designated default preferred, otherwise the
     first credentialed one.
     Exactly one hop, no chains.
  4. Only the **error shapes** change in the storage step: no storage can serve the client →
     named 422 instead of a thrown 500 (fixed by adding the missing credentials — one `PUT` on
     the existing admin endpoint — or by repointing the region's fallback ID; both deliberate
     operations);
     and a region whose storages have no default → clear domain error instead of an unhandled crash.
- [ ] **Delete the hardcode:** `MapLocationToStorageRegion`, `KnownLocations`, `KnownRegions`.
  Goal: zero region/location literals left in application code — grep hits only migrations and
  tests (a one-time acceptance criterion of the implementation; the implementing ticket covers the
  test-infrastructure consumers of the deleted constants).
**Proposed `IStorageSelector` seam:** if useful during implementation, the current default-storage
selection is its only implementation now. Capacity-aware selection is **out of scope** for this
feature; if ever needed (Cove Object Storage: free space via the Cloud service; AWS assumed
unlimited), it could be implemented behind that interface — capacity is solved *within* a region,
not by changing region.

`partnerId` stays required and load-bearing — it feeds the CMS lookup, as today. Existing
component tests around the location-based selection (`RepositoriesApi_PostEndpoint_*_Should`,
case source `StoragePickingTestCases`) are **migrated, not deleted**: same scenarios, now driven
by fallback IDs seeded in the region test fixtures instead of compiled constants.

The end-state create flow:

```mermaid
sequenceDiagram
    participant GWI as GWI backend<br/>(allow-listed principal)
    participant Int as Internal caller<br/>(acceptance test, integrations)
    participant Cfg as Configurator
    participant CMS
    participant DB as Configurator DB

    GWI->>Cfg: POST /repo-mgmt/repositories { partnerId, storageClientName, ... }
    Note over GWI,Cfg: contract unchanged - customer UI never reaches Configurator,<br/>only backend principals pass the mesh allow-list
    Cfg->>CMS: partner location name (existing lookup, kept)
    Cfg->>DB: region lookup by CMS location name and read fallback_region_id

    alt region found + fallback set + target has an eligible storage
        Cfg->>DB: target region → eligible storage, default preferred (IStorageSelector)
        Cfg->>DB: create repository + main instance (same transaction + outbox as today)
        Cfg-->>GWI: 201 - main instance on the target region's storage
    else no region / null fallback / target cannot serve the client
        Cfg-->>GWI: 422 - named reason, never a silent default, never a second hop
    end

    Int->>Cfg: POST /repo-mgmt/repositories { storages:[{ storageId, isMain:true }] }
    Note over Int,Cfg: explicit placement for internal callers - unchanged, as today<br/>(this is also how the rollout's acceptance test creates)
    Cfg-->>Int: 201 / 422
```

**No validation changes.** `RepositoryDependenciesValidator` stays untouched — the fallback ID is
the only routing switch, and the explicit-`storages` path keeps today's behavior exactly.
**No customer-facing region catalogue and no SDK changes** — with automatic selection there is no
picker; the client SDK's `CreateRepositoryRequest` already carries exactly what the flow needs.
The Google Workspace integration requires zero changes.

## Region Rollout

Proposed region rollout protocol:
1. **The region row already exists** - one per CMS location, seeded. If an additional region is
   needed, create it with `POST /storage-mgmt/regions` (optionally pointing at an existing serving
   region); a self-reference needs a subsequent `PUT` using the generated ID.
2. DevOps create a new bucket in the desired region. Then register storage using the rollout
   region's ID from `GET /storage-mgmt/regions`:
   `POST /storage-mgmt/storages { name, regionId, isDefault: true }`, and configure credentials
   pointing to the new bucket.
3. Then they run Acceptance Test for the new storage.
4. **Go-live (DevOps/Admin UI, PM-decided, only after step 3 is green):** flip the `fallbackRegion` to self. new repositories will be forwarded to the new fallback that points to the newly created storage. Existing repositories do not move —   that is repatriation (BST-1550). Emergency stop: point the row back at `United Kingdom` — the same API.
**Verification :** not needed in prod rollout procedure, logic behind PUT endpoint should be already tested by QA during task implementation.

## Out of scope (and where it lives instead)

- **Customer-facing region choice at repository creation** — the customer's location choice
  happens once, at customer creation (the partner's CMS Location property); this design honors it.
- **Moving existing repositories between regions** — BST-1550 (repatriation):
  Lock/Synchronization/Promotion/Relocation in `repository-repatriation-prerequisites.md`.
  Fallback changes affect **new** repositories only.
- **Capacity-aware storage selection & Location Policy ownership** — behind the
  proposed `IStorageSelector` seam if useful; the resolved region at creation is the natural input
  for a repository-level Location Policy (`backup-docs`, `data-management.md` — repo-level
  granularity, persistence location open).

## Implementation breakdown

| # | Ticket | Scope in one line |
|---|---|---|
| 1 | CMS-named regions + fallback ID on `region` (schema + data) | Rename migrations (`uk` → `United Kingdom`, `us` → `United States`, `es` → `Spain`), UUID PK and storage FK, one region row per CMS location, nullable self-FK + behavior-preserving seed, lookup repository; extend region GET with IDs, change storage admin API to `regionId` |
| 2 | Data-driven automatic region selection | The resolution funnel (CMS location → fallback target → existing storage-picking, unchanged), delete the hardcode (`MapLocationToStorageRegion`, `KnownLocations`, `KnownRegions`), proposed `IStorageSelector` seam, error-shape fixes (`First(IsDefault)` crash, zero-credentials 500 → named 422), legacy tests migrated |
| 3 | Admin CRUD API for regions | Extend `GET /storage-mgmt/regions`; `POST /storage-mgmt/regions`, update-only `PUT /storage-mgmt/regions/{regionId}`, `DELETE /storage-mgmt/regions/{regionId}`, superuser-gated writes, OpenAPI |
| 4 | New region go-live (e.g. Canada) — the zero-code proof | Runbook agreed with DevOps/QA, storage + credentials, acceptance test, go-live self-flip via the API — zero deployments, zero migrations |
| 5 | Admin UI: storage region IDs | Update storage registration to submit `regionId` from region GET; display storage regions using IDs returned by storage admin GET; update UI models and tests, deploy with Ticket 1's API change |

Tickets 2 and 3 are independent of each other and can run in parallel after Ticket 1. Ticket 5
can start once Ticket 1's API contract is agreed, but must ship with that breaking admin change.
