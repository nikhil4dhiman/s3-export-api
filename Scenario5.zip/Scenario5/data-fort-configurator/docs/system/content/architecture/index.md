# DataFort Configurator Architecture

## High-Level Architecture

![High-Level Architecture](high-level-architecture.drawio.svg)

## Physical Topology

![Deployment Diagram](deployment.drawio.svg)

## Capacity Model

Capacity model provides assumptions for required storage capacity, number of requests and network traffic for DataFort Config components.

Model simplifications:

* Storage and storage client entities and operations on them are neglected due to their low number and infrequent requests.
* Repository creations and modifications are neglected due to infrequent requests.

### Input parameters

* N<sub>repo</sub> - number of actively used repositories
* T<sub>repo</sub> - periodicity of credentials request per repository (seconds)

### Constants

Repository object size is assumed as follows:

* S<sub>repo</sub> = 200 (bytes)

Storage and network protocol overheads are assumed as follows:

* O<sub>stg</sub> = 100 (bytes)
* O<sub>net</sub> = 100 (bytes)

### Outcomes

* RPS = N<sub>repo</sub> / T<sub>repo</sub>
* Storage = N<sub>repo</sub> * (S<sub>repo</sub> + O<sub>stg</sub>)
* Traffic = RPS * (S<sub>repo</sub> + O<sub>net</sub>)

### Example

For N<sub>repo</sub> = 1000, T<sub>repo</sub> = 600 (10 min):

* RPS = 1.67
* Storage = 1000 * (200 + 100) (bytes) = 293 (KiB)
* Traffic = 1.67 * (200 + 100) (bytes / sec) = 1.2 (GiB / month)
