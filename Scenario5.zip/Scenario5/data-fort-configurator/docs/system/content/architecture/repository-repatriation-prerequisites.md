# Repository Repatriation — Prerequisites

## Problem

Move a repository's `main` replica back to the partner's desired region when it currently lives
elsewhere, but only once a `storage` in that region actually has credentials for the repository's
`storage_client`.

Read top-to-bottom — each section only uses what earlier sections already defined:
**Lock → Synchronization → Promotion → Relocation.** Repatriation itself — the policy layer that
decides *which* repositories move, *where*, and *when* — is intentionally out of scope here and will be documented separately.

## Lock

Design already accepted, not repatriation-specific: [Main Instance Credential Lock During Relocation](https://n-able.atlassian.net/wiki/spaces/CD/pages/61694181767/Main+Instance+Credential+Lock+During+Relocation).
None of it is implemented yet (checked — no `/lock` route anywhere in the codebase).

- [ ] **`POST /repo-mgmt/repositories/{id}/lock`.** EF mapping + endpoint in one task.
  - Map `locked_to_write_at_utc`/`locked_to_write_until_utc` onto `RepositoryEntity` + EF config
    (columns exist in the DB already, currently unused).
  - Idempotent while still actively locked: returns the existing `lockedToWriteAtUtc`/
    `lockedToWriteUntilUtc` unchanged rather than recomputing them, so a retried/duplicate call can't
    silently extend the lock. If the previous lock has already expired, this is a fresh lock — compute
    and persist new values from `now`. Returns `{ lockedToWriteUntilUtc, lockedToWriteAtUtc }` either way.
  - Expose the existing `credential_ttl` config to the lock computation:
    `lockedToWriteAtUtc = now + credential_ttl`, `lockedToWriteUntilUtc = now + credential_ttl + lock_ttl` —
    `lock_ttl` is just the buffer *on top of* `credential_ttl`, not inclusive of it — e.g.
    `lock_ttl = 1 hour` (should comfortably fit a delta sync).
  - `credential_ttl` and `lock_ttl` must be configurable per environment — exact values live
    in each env's config, not hardcoded, same pattern as other per-env settings under
    `deployment/environments/{env-prefix}`.
  - `404 Not Found` if no repository exists with `{id}` (or it's soft-deleted).

  Example response, given `now = 2026-09-07T14:30:00Z`, `credential_ttl = 15m`, `lock_ttl = 1h`:

  ```jsonc
  // 200 OK
  {
    "lockedToWriteAtUtc": "2026-09-07T14:45:00Z",
    "lockedToWriteUntilUtc": "2026-09-07T15:45:00Z"
  }
  ```
- [ ] **`DELETE /repo-mgmt/repositories/{id}/lock`.** Depends on the task above.
  - `404 Not Found` if no repository exists with `{id}` (or it's soft-deleted).
  - Sets both `locked_to_write_at_utc` and `locked_to_write_until_utc` to `NULL` — unlocking clears the
    lock's state entirely rather than leaving a past timestamp behind, so "is this repository locked"
    is always just `locked_to_write_until_utc IS NOT NULL AND locked_to_write_until_utc > now`, with no
    separate "was it ever locked before" residue to reason about.
  - Idempotent unlock: no-op on an already-unlocked repository (both columns already `NULL`).
- [ ] **Enforce the lock on credential issuance.** Depends on the `POST /lock` task.
  - `GET /repo-access/repositories/{repositoryId}/credentials/main` returns `423` + `Retry-After`
    (remaining lock duration) while locked, normal `200` otherwise.
  - **On `200`, add a `credentialsEffectiveUntilUtc` field to the response** — `now + credential_ttl`,
    computed at response time, but `min(now + credential_ttl, locked_to_write_at_utc)` if
    `locked_to_write_at_utc` is set: a lock can already be requested (effective in the future) while
    the repository is still unlocked right now, and the credential handed out in that window must not
    claim to be usable any later than the lock's own effective time.

    Today `GetMainCredentialByRepositoryIdAsync` returns the raw credential
    `JsonNode` enriched only with `storageId`/`storageName` (`CredentialEnrichedFieldNames`, shared with
    the other two credential-lookup endpoints via `FetchAndEnrichCredentialAsync`); this field is
    `/main`-specific (it depends on the repository's lock state, not just the storage), so it can't
    live in that shared enrichment helper — add it directly in `GetMainCredentialByRepositoryIdAsync`.
    Gives Vault an explicit, per-response expiry to respect instead of relying only on its own
    `ConfiguratorCacheConfig.ttl` being clamped correctly out-of-band (see the Vault task below).
- [ ] **Enforce the lock on the main-storage swap.** Depends on the `POST /lock` task.
  - `PATCH /repo-mgmt/repositories/{id}/topology` (swap main) checks the repository is currently locked
    (`locked_to_write_until_utc` in the future) before executing the swap — reject with `409` if
    not locked. Without this check the swap could run past the lock's expiry with no guarantee
    credentials were actually drained.
  - This is also what makes an expired lock a normal, re-armable condition for Promotion's retry
    loop (see Promotion) rather than a silent race.
- [ ] **Vault: respect `credentialsEffectiveUntilUtc`.** Cross-repo (`data-fort-vault`), blocks the
      whole drain guarantee otherwise. Today Vault caches main-storage credentials with its own TTL,
      decoupled from Configurator — it can keep writing with stale cached credentials past
      `lockedToWriteAtUtc`, the exact race Lock is meant to prevent. Cap the cache entry's lifetime to
      the new `credentialsEffectiveUntilUtc` field from the credentials response instead. Capping the
      cache alone only stops Vault from *starting* a new write with a stale credential — each
      individual storage write operation also needs its own max-duration guard bounded by the
      remaining time to `credentialsEffectiveUntilUtc`, so an already in-flight write can't keep
      running past it. Worth checking with the storage backends themselves (CoS in particular)
      whether they already offer a mechanism for this before building it purely on Vault's side.
- [ ] **Research: hard expiry enforcement on the credential itself.** `credentialsEffectiveUntilUtc`
      is only a contract Vault is expected to honor — nothing stops a raw storage credential from
      being reused past that time, by a buggy client or otherwise. Look into wrapping the issued
      credential in something the storage backend itself rejects once expired, instead of trusting the
      caller to stop using it — e.g. AWS STS temporary credentials (`AssumeRole` with
      `DurationSeconds`) for AWS storages, and whatever equivalent STS-style support CoS offers.
      Whether this is even feasible for every storage kind Repatriation needs to support is the
      open question — if not, `credentialsEffectiveUntilUtc` stays the only enforcement there is.

Reuses existing, currently **unused** columns (added in
`db/migrations/20260427095849_add_role_and_lock_columns.sql` alongside `actual_role`/`desired_role`,
never mapped in `RepositoryEntityTypeConfiguration`/`RepositoryEntity`, never enforced anywhere):

```sql
repository.locked_to_write_at_utc     -- when the lock becomes effective (writes must stop)
repository.locked_to_write_until_utc  -- lock expiry (safety net if promote never happens)
```

Clock skew between Configurator and Vault isn't a separate concern: both run on EC2-backed EKS
nodes, each syncing locally via AWS Time Sync Service (`169.254.169.123`, backed by AWS's own
reference clocks) — accurate to low single-digit milliseconds regardless of node, cluster, region, or
account, since it's not a shared server either side connects to over the network. Negligible next to
the `credential_ttl` → `lock_ttl` margin above; not something to enforce separately.

## Synchronization

No replica sync mechanism exists today — there's no ongoing sync between `repository_instance`s at
all. Proposed solution below is scoped strictly to repatriation, not a general-purpose sync feature.
The event contract (bulk/delta sync requested/completed, below) is the same regardless of what kind
of storage is on either end — how Maintenance actually moves the bytes for a given storage pair is
Maintenance's own internal concern, not something Governor or Configurator need to know about.

**On-demand S3 Batch Replication**, kicked off by Maintenance, not continuous bucket replication —
this is the mechanism for AWS ⇄ AWS pairs specifically; see the research task at the end for other
storage kinds.

Naive approach — lock writes to `main` for the entire sync — is unacceptable for large repositories
(sync can take long). Instead, two S3 Batch Replication passes: a **bulk** pass while `main` stays
writable, then a short **delta** pass covering only what changed during the bulk pass, with the write
lock (see Lock section) held from the delta pass through the swap, not for the entire sync. A single
delta pass can itself still take a while if enough data changed during a long bulk pass — running
several unlocked delta passes first, locking only for the last (shrinking) one, is already tracked as
a low-priority enhancement in Promotion's task list.

`Filter.CreatedAfter`/`CreatedBefore` (used for the delta pass) is a documented
`JobManifestGeneratorFilter` field, not a workaround:

> "If provided, the generated manifest includes only source bucket objects that were created after
> this time." — [`JobManifestGeneratorFilter`, Amazon S3 API Reference](https://docs.aws.amazon.com/AmazonS3/latest/API/API_control_JobManifestGeneratorFilter.html)

S3 objects are immutable — a `PutObject` on an existing key creates a new object/version with a new
timestamp — so `CreatedAfter=T1` correctly catches both new keys and overwrites made after T1.

Bulk and delta each get their own `requested`/`completed` event pair — four events total, so
`createdAfter` is either always present (delta) or always absent (bulk), never optional on the same
event type. Same `com.n-able.cove.events.data-fort.repository.replica.*` naming, same outbox/SNS/SQS
transport as existing lifecycle events:

| Event | Source | Queue | Payload |
|---|---|---|---|
| `repository.replica.synchronization.bulk.requested` | governor-dispatch | maintenance-processing | `repositoryId`, `storageId` |
| `repository.replica.synchronization.bulk.completed` | maintenance-events | governor-processing | `repositoryId`, `storageId`, `syncStartedAtUtc` — becomes `createdAfter` for the delta request |
| `repository.replica.synchronization.delta.requested` | governor-dispatch | maintenance-processing | `repositoryId`, `storageId`, `createdAfter` |
| `repository.replica.synchronization.delta.completed` | maintenance-events | governor-processing | `repositoryId`, `storageId`, `syncStartedAtUtc` — becomes `createdAfter` if a retry needs another delta pass |

- [ ] **Maintenance: consume `repository.replica.synchronization.bulk.requested`/`.delta.requested`,
      create the S3 Batch Operations job.**
  - Resolve the repo's object key prefix and source/target bucket from `repositoryId`/`storageId`.
  - `S3Control.CreateJob`: `Operation.S3ReplicateObject`, `ManifestGenerator.S3JobManifestGenerator`
    with `KeyNameConstraint.MatchAnyPrefix=[repoPrefix]`; set `Filter.CreatedAfter` from the event's
    `createdAfter` on the delta path, omit it on the bulk path.
  - Provision the IAM `RoleArn` Batch Operations assumes to run the job (`s3:ReplicateObject`,
    `s3:GetReplicationConfiguration`, `s3:GetObjectVersionForReplication`, etc.).
- [ ] **Maintenance: poll the job to completion, publish the matching `.completed` event**
      (`synchronization.bulk.completed` for a bulk job, `synchronization.delta.completed` for a delta job).
  - `DescribeJob` until `Complete`/`Failed`/`Cancelled`; on `Complete`, publish with
    `syncStartedAtUtc` = job creation time.
  - `Failed`/`Cancelled` → retry rather than propagate as a hard failure.
- [ ] **Governor: consume `repository.replica.synchronization.bulk.completed`.** Triggers
      `POST /lock` and creates the "delta sync" deferred task (`not_before_utc=lockedToWriteAtUtc`)
      — see Promotion. Testable independently of Maintenance: hand-place the event on
      `governor-processing` and assert the resulting lock call + deferred task.
- [ ] **Governor: consume `repository.replica.synchronization.delta.completed`.** Clears
      `blocked_by=sync` on the "promoted" deferred task — see Promotion. Same testing approach:
      hand-place the event on the queue, no real Maintenance job needed.
- [ ] **Research: sync mechanism for non-standard storage pairs.**
  - AWS -> AWS: `S3ReplicateObject` requires a pre-existing replication rule on the source bucket —
    doesn't accept an ad-hoc destination per job. Repatriation needs arbitrary storage pairs: full
    mesh of rules, or create/tear down a scoped rule per repatriation?
  - AWS -> COS: Cove Object Storage isn't reachable via `S3Control` at all — needs its own
    mechanism, or explicit exclusion from candidacy until one exists.

## Promotion

Orchestrates Lock + Synchronization into a safe main-storage swap for one repository. Governor's own
`deferred_task` bookkeeping ties them together: the "promoted" task (`P`) is created immediately but
held `blocked_by=sync` until a delta sync actually lands after the lock is effective; the `PATCH`
swap itself fails if the lock has meanwhile expired, which just re-arms the whole lock+delta-sync
cycle rather than being a special case:

```mermaid
sequenceDiagram
    participant Cfg as Configurator
    participant Gov as Governor
    participant Maint as Maintenance

    Cfg->>Gov: repository.replica.promoted
    Gov->>Gov: create deferred_task "promoted" (id=P)
    Gov->>Maint: repository.replica.synchronization.bulk.requested
    Gov->>Gov: block P: blocked_by = sync
    Maint->>Maint: run bulk S3 Batch job (KeyNameConstraint.MatchAnyPrefix=[repoPrefix])
    Note over Maint: main stays writable - no lock yet
    Maint->>Gov: repository.replica.synchronization.bulk.completed (syncStartedAtUtc=T1)

    rect rgb(255, 244, 214)
        Note over Gov,Maint: Enhancement candidate: don't lock right away - based on how long the bulk<br/>pass took, run one or more extra delta passes first (still unlocked) to shrink what's<br/>left, only locking once a delta pass would comfortably fit inside lock_ttl. Minimizes<br/>lock time, and avoids a useless lock when the initial bulk was too large for a single<br/>delta pass to fit before lock_ttl runs out.
    end

    Gov->>Cfg: POST /repo-mgmt/repositories/{id}/lock
    Cfg-->>Gov: { lockedToWriteAtUtc, lockedToWriteUntilUtc }
    Gov->>Gov: create deferred_task "delta sync" (id=D, not_before_utc=lockedToWriteAtUtc)

    loop until swap succeeds
        Note over Gov: D becomes due (lock now effective - credentials drained)
        Gov->>Maint: repository.replica.synchronization.delta.requested (createdAfter=last syncStartedAtUtc)
        Maint->>Maint: run delta S3 Batch job (same prefix, Filter.CreatedAfter=createdAfter)
        Maint->>Gov: repository.replica.synchronization.delta.completed (syncStartedAtUtc=now)
        Gov->>Gov: unblock P: clear blocked_by

        Note over Gov: P becomes due
        Gov->>Cfg: PATCH /repo-mgmt/repositories/{id}/topology - swap main
        Cfg->>Cfg: swap allowed only while repository is locked, else fail

        alt still locked
            Cfg-->>Gov: 200 OK - swap done
            Cfg-->>Gov: repository.replica.retired (old main, via outbox)
            Gov->>Cfg: DELETE /repo-mgmt/repositories/{id}/lock
            Gov->>Gov: delete deferred_task P - done
        else lock expired before swap executed
            Cfg-->>Gov: 409 - swap rejected, not locked
            Gov->>Cfg: POST /repo-mgmt/repositories/{id}/lock (retry)
            Cfg-->>Gov: { lockedToWriteAtUtc, lockedToWriteUntilUtc }
            Gov->>Gov: reschedule deferred_task D' (not_before_utc=lockedToWriteAtUtc), re-block P
        end
    end
```

- [ ] **Governor: consume `repository.replica.promoted`.** Creates deferred_task "promoted" (`P`,
      `blocked_by=sync`), dispatches `repository.replica.synchronization.bulk.requested`.
- [ ] **Governor: process deferred_task `P` once unblocked and due.** `PATCH .../topology` swap
      main; on `200`, `DELETE /lock` and delete `P`; on `409` (lock expired), re-`POST /lock`,
      reschedule the delta-sync deferred task, re-block `P`.
- [ ] **Low priority: pre-lock delta synchronization enhancement.** See the rect block in the diagram
      above — run extra unlocked delta passes before ever taking the lock, sized by how long the bulk
      pass took, instead of locking immediately on `bulk.completed`.

## Relocation

The reusable primitive: move one repository's `main` from wherever it is now to a specific target
storage.

1. Create a secondary `repository_instance` in the target storage, `desired_role='main'` — publishes
   `repository.replica.created`.
2. Immediately publish `repository.replica.promoted` — the intent signal that kicks off Promotion
   (Lock + Synchronization) from the sections above.
3. Once Promotion's swap succeeds, the old main gets retired (`repository.replica.retired`, emitted
   as part of the swap — see Promotion).

No new tasks here — steps 1 and 2 are the existing `PATCH /repo-mgmt/repositories/{id}` instances
patch (already creates/promotes and already publishes `created`/`promoted`), step 3 is the existing
`PATCH /repo-mgmt/repositories/{id}/topology` swap (already publishes `retired`) that Promotion's
task list already covers. Relocation works once Lock + Synchronization + Promotion are implemented —
it doesn't add anything of its own.
