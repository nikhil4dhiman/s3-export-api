# AWS SNS as Outbound Message Queue

## Info

**Date:** 2025-11-01  
**Author:** Roman Beleshev  
**Approved by:** Yakau Shtykau

## Status
<!-- Draft, Proposed | Accepted | Rejected | Deprecated | Superseded by ADR-XX -->
`Accepted`

## Context

DataFort Config requires outbound messaging service to notify DataFort Governor about repositories lifecycle changes. Messages are not considered to be used outside of DataFort platform. Number of messages is expected to be very low.

## Decision

Due to lack of outstanding performance and functional requirements decision was made in favor of widely adopted AWS SNS.

## Consequences

* No notable consequences.
