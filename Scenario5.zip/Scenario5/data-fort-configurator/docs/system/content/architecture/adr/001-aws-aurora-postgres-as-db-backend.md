# AWS Aurora Postgres as DB backend

## Info

**Date:** 2025-11-01  
**Author:** Roman Beleshev  
**Approved by:** Yakau Shtykau

## Status
<!-- Draft, Proposed | Accepted | Rejected | Deprecated | Superseded by ADR-XX -->
`Accepted`

## Context

DataFort Config requires database backend store to keep metadata about storages, storage clients, storage credentials and repositories which perfectly fit relational model. All of those entities are small objects (usually less than 1 KiB). Number of repositories is on the order of millions, other entities are significantly less numerous.

## Decision

Due to lack of outstanding performance and functional requirements decision was made in favor of widely adopted AWS Aurora Postgres.

## Consequences

* No notable consequences.
