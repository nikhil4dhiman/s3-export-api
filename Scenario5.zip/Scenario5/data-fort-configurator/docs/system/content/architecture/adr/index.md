# DataFort Config Architectural Decision Records

* [001: AWS Aurora Postgres as DB backend](001-aws-aurora-postgres-as-db-backend.md)
* [002: Hashicorp Vault as Secret Store](002-hashicorp-vault-as-secret-store.md)
* [003: AWS SNS as Outbound Message Queue](003-aws-sns-as-outbound-message-queue.md)
