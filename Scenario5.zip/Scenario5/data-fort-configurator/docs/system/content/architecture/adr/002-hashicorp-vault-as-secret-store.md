# Hashicorp Vault as Secret Store

## Info

**Date:** 2025-11-01  
**Author:** Roman Beleshev  
**Approved by:** Yakau Shtykau

## Status
<!-- Draft, Proposed | Accepted | Rejected | Deprecated | Superseded by ADR-XX -->
`Accepted`

## Context

DataFort Config requires secret store in order to keep storage credentials for every storage clients. Number of storages and clients is in order of tens.

## Decision

Due to lack of outstanding performance and functional requirements decision was made in favor of widely adopted HashiCorp Vault.

## Consequences

* No notable consequences.
