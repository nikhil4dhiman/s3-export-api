# Requirements for storage configuration

## Document Purpose

This document outlines the subset of [high-level requirements](https://github.com/nable-backup/backup-docs/blob/master/storage/requirements/high-level-requirements.md) that is specific to storage configuration. Requirements are described in more detail.

## Requirements

| Requirement | Description |
|-|-|
| Storage clients administration | System MUST provide means to register storage clients. |
| Storage administration | System MUST provide reasonable CRUD operations on storage entities. |
| Data residency | System MUST provide list of available storages and their regions for specific storage client. |
| Access control | All storage clients MUST be authenticated. Storage clients MUST have different credentials per storage. |
| Data isolation | System MUST provide CRUD operations on repository entities as per domain model. System MUST enforce storage client ownership over its repos. System MUST be able to infer repo credentials by storage client request. |
| Data relocation | System MUST produce an event when repository storage list is changed |
| Cross-storage redundancy | System MUST produce an event when repository storage list is changed |
| Data purge | System MUST produce an event when repository is deleted/undeleted |
