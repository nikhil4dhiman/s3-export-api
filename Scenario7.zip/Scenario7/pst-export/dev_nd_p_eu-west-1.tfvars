region                          = "eu-west-1"
flag                            = "ah_p"
target_availability_zone_name_a = "eu-west-1a"
target_availability_zone_name_b = "eu-west-1b"
trigger_to_deploy_host_zone_a   = true
trigger_to_deploy_host_zone_b   = true
trigger_to_deploy_s3            = true
s3_target_bucket_name           = null
