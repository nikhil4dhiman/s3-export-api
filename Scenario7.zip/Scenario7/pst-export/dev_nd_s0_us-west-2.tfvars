region                          = "us-west-2"
flag                            = "ah_s0"
target_availability_zone_name_a = "us-west-2a"
target_availability_zone_name_b = "us-west-2b"
trigger_to_deploy_host_zone_a   = true
trigger_to_deploy_host_zone_b   = true
trigger_to_deploy_s3            = false
s3_target_bucket_name           = "pst-export-agent-dev-ah-p-storage"
