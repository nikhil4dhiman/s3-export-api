# Dev Environment, Nikhil Dhiman [dev_nd] configuration

## Primary region

- kind: `primary`
- configuration file: `dev_nd_p_eu-west-1.tfvars`
- region: `eu-west-1`
- s3 bucket storage: `exists`
- availability zones: 2, `a` and `b`

### initialize

```bash
terraform init \
    -backend-config="bucket=pst-export-agent-nonprod-backend" \
    -backend-config="key=resources_state_dev_nd_p_eu-west-1.tfstate" \
    -backend-config="region=eu-west-1" \
    -backend-config="use_lockfile=true" \
    -reconfigure
```

### apply

```bash
terraform plan -var-file=../environments/dev_nd_common.tfvars -var-file=../environments/dev_nd_p_eu-west-1.tfvars -out=dev_nd_p_eu-west-1.apply.tfplan
terraform apply "dev_nd_p_eu-west-1.apply.tfplan"
```

### destroy

```bash
terraform plan -var-file=../environments/dev_nd_common.tfvars -var-file=../environments/dev_nd_p_eu-west-1.tfvars -destroy -out=dev_nd_p_eu-west-1.destroy.tfplan
terraform apply "dev_nd_p_eu-west-1.destroy.tfplan"
```

## Secondary 0

- kind: `secondary`
- configuration file: `dev_nd_s0_us-west-2.tfvars`
- region: `us-west-2`
- s3 bucket storage: reference to `primary region`
- availability zones: 1, `b`

### initialize

```bash
terraform init \
    -backend-config="bucket=pst-export-agent-nonprod-backend" \
    -backend-config="key=resources_state_dev_nd_s0_us-west-2.tfstate" \
    -backend-config="region=eu-west-1" \
    -backend-config="use_lockfile=true" \
    -reconfigure
```

### apply

```bash
terraform plan -var-file=../environments/dev_nd_common.tfvars -var-file=../environments/dev_nd_s0_us-west-2.tfvars -out=dev_nd_s0_us-west-2.apply.tfplan
terraform apply "dev_nd_s0_us-west-2.apply.tfplan"
```

### destroy

```bash
terraform plan -var-file=../environments/dev_nd_common.tfvars -var-file=../environments/dev_nd_s0_us-west-2.tfvars -destroy -out=dev_nd_s0_us-west-2.destroy.tfplan
terraform apply "dev_nd_s0_us-west-2.destroy.tfplan"
```
